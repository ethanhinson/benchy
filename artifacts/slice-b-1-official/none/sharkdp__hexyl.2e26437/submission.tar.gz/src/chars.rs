use crate::colors::is_ascii_whitespace;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CharacterTable {
    Default,
    Ascii,
    Codepage1047,
    Codepage437,
    Braille,
}

pub fn map_byte(byte: u8, table: CharacterTable) -> char {
    match table {
        CharacterTable::Default => default_char(byte),
        CharacterTable::Ascii => ascii_char(byte),
        CharacterTable::Codepage1047 => codepage1047_char(byte),
        CharacterTable::Codepage437 => codepage437_char(byte),
        CharacterTable::Braille => braille_char(byte),
    }
}

fn default_char(byte: u8) -> char {
    if byte == 0 {
        '⋄'
    } else if (0x21..=0x7e).contains(&byte) {
        byte as char
    } else if is_ascii_whitespace(byte) {
        if byte == 0x20 { ' ' } else { '_' }
    } else if byte < 0x80 {
        '•'
    } else {
        '×'
    }
}

fn ascii_char(byte: u8) -> char {
    if byte == 0x20 || (0x21..=0x7e).contains(&byte) {
        byte as char
    } else {
        '.'
    }
}

fn codepage1047_char(byte: u8) -> char {
    // EBCDIC code page 1047: show printable EBCDIC, '.' for everything else
    if byte == 0x40 {
        ' '
    } else if matches!(byte, 0x4a..=0x51 | 0x54..=0x59 | 0x62..=0x69 | 0x6c..=0x71 | 0x74..=0x79 | 0x81..=0x89 | 0x91..=0x99 | 0xa2..=0xa9) {
        ebcdic_to_ascii(byte)
    } else {
        '.'
    }
}

fn ebcdic_to_ascii(byte: u8) -> char {
    const TABLE: [u8; 256] = {
        let mut t = [b'.'; 256];
        t[0x40] = b' ';
        t[0x4a] = b'[';
        t[0x4b] = b'.';
        t[0x4c] = b'<';
        t[0x4d] = b'(';
        t[0x4e] = b'+';
        t[0x4f] = b'|';
        t[0x50] = b'&';
        t[0x51] = b'!';
        t[0x54] = b'$';
        t[0x55] = b'*';
        t[0x56] = b')';
        t[0x57] = b';';
        t[0x58] = b'^';
        t[0x59] = b'-';
        t[0x5a] = b'/';
        t[0x62] = b',';
        t[0x63] = b'%';
        t[0x64] = b'_';
        t[0x65] = b'>';
        t[0x66] = b'?';
        t[0x67] = b'`';
        t[0x68] = b':';
        t[0x69] = b'#';
        t[0x6c] = b'@';
        t[0x6d] = b'\'';
        t[0x6e] = b'=';
        t[0x6f] = b'"';
        t[0x70] = b'o';
        t[0x71] = b'a';
        t[0x72] = b'b';
        t[0x73] = b'c';
        t[0x74] = b'd';
        t[0x75] = b'e';
        t[0x76] = b'f';
        t[0x77] = b'g';
        t[0x78] = b'h';
        t[0x79] = b'i';
        t[0x81] = b'j';
        t[0x82] = b'k';
        t[0x83] = b'l';
        t[0x84] = b'm';
        t[0x85] = b'n';
        t[0x86] = b'o';
        t[0x87] = b'p';
        t[0x88] = b'q';
        t[0x89] = b'r';
        t[0x91] = b's';
        t[0x92] = b't';
        t[0x93] = b'u';
        t[0x94] = b'v';
        t[0x95] = b'w';
        t[0x96] = b'x';
        t[0x97] = b'y';
        t[0x98] = b'z';
        t[0xa2] = b'A';
        t[0xa3] = b'B';
        t[0xa4] = b'C';
        t[0xa5] = b'D';
        t[0xa6] = b'E';
        t[0xa7] = b'F';
        t[0xa8] = b'G';
        t[0xa9] = b'H';
        t
    };
    TABLE[byte as usize] as char
}

fn codepage437_char(byte: u8) -> char {
    if byte == 0 {
        '⋄'
    } else if (0x20..=0x7e).contains(&byte) {
        byte as char
    } else {
        CP437[byte as usize]
    }
}

const CP437: [char; 256] = [
    '\0', '☺', '☻', '♥', '♦', '♣', '♠', '•', '◘', '○', '◙', '♂', '♀', '♪', '♫', '☼',
    '►', '◄', '↕', '‼', '¶', '§', '▬', '↨', '↑', '↓', '→', '←', '∟', '↔', '▲', '▼',
    ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?',
    '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
    'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_',
    '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
    'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '⌂',
    'Ç', 'ü', 'é', 'â', 'ä', 'à', 'å', 'ç', 'ê', 'ë', 'è', 'ï', 'î', 'ì', 'Ä', 'Å',
    'É', 'æ', 'Æ', 'ô', 'ö', 'ò', 'û', 'ù', 'ÿ', 'Ö', 'Ü', '¢', '£', '¥', '₧', 'ƒ',
    'á', 'í', 'ó', 'ú', 'ñ', 'Ñ', 'ª', 'º', '¿', '⌐', '¬', '½', '¼', '¡', '«', '»',
    '░', '▒', '▓', '│', '┤', '╡', '╢', '╖', '╕', '╣', '║', '╗', '╝', '╜', '╛', '┐',
    '└', '┴', '┬', '├', '─', '┼', '╞', '╟', '╚', '╔', '╩', '╦', '╠', '═', '╬', '╧',
    '╨', '╤', '╥', '╙', '╘', '╒', '╓', '╫', '╪', '┘', '┌', '█', '▄', '▌', '▐', '▀',
    'α', 'ß', 'Γ', 'π', 'Σ', 'σ', 'µ', 'τ', 'Φ', 'Θ', 'Ω', 'δ', '∞', 'φ', 'ε', '∩',
    '≡', '±', '≥', '≤', '⌠', '⌡', '÷', '≈', '°', '∙', '·', '√', 'ⁿ', '²', '■', ' ',
];

fn braille_char(byte: u8) -> char {
    if byte == 0 {
        '⋄'
    } else if byte == 0x20 || (0x21..=0x7e).contains(&byte) {
        byte as char
    } else {
        char::from_u32(0x2800 + (byte as u32)).unwrap_or('×')
    }
}
