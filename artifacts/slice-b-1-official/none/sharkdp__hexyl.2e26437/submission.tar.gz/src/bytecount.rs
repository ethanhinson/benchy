use anyhow::{anyhow, bail, Context, Result};
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ByteCount(pub u64);

impl ByteCount {
    pub fn parse(s: &str, block_size: u64, allow_negative: bool) -> Result<i64> {
        let s = s.trim();
        if s.is_empty() {
            bail!("empty byte count");
        }

        let (negative, rest) = if let Some(rest) = s.strip_prefix('-') {
            if !allow_negative {
                bail!(
                    "negative offset specified, but only positive offsets (counts) are accepted in this context"
                );
            }
            (true, rest)
        } else {
            (false, s)
        };

        let value = parse_positive(rest, block_size)?;
        Ok(if negative { -(value as i64) } else { value as i64 })
    }

    pub fn parse_positive(s: &str, block_size: u64) -> Result<u64> {
        parse_positive(s, block_size)
    }
}

fn parse_positive(s: &str, block_size: u64) -> Result<u64> {
    let s = s.trim();
    if s.is_empty() {
        bail!("empty byte count");
    }

    if let Some(rest) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        let value = u64::from_str_radix(rest, 16)
            .with_context(|| format!("failed to parse `{s}` as byte count"))?;
        return Ok(value);
    }

    let lower = s.to_ascii_lowercase();

    let (num_part, unit) = if lower.ends_with("block") {
        (&s[..s.len() - 5], Some("block"))
    } else if lower.ends_with("kib") {
        (&s[..s.len() - 3], Some("kib"))
    } else if lower.ends_with("mib") {
        (&s[..s.len() - 3], Some("mib"))
    } else if lower.ends_with("gib") {
        (&s[..s.len() - 3], Some("gib"))
    } else if lower.ends_with("tib") {
        (&s[..s.len() - 3], Some("tib"))
    } else if lower.ends_with("kb") {
        (&s[..s.len() - 2], Some("kb"))
    } else if lower.ends_with("mb") {
        (&s[..s.len() - 2], Some("mb"))
    } else if lower.ends_with("gb") {
        (&s[..s.len() - 2], Some("gb"))
    } else if lower.ends_with("tb") {
        (&s[..s.len() - 2], Some("tb"))
    } else {
        (s, None)
    };

    let base: f64 = num_part.parse().map_err(|_| {
        anyhow!(
            "\"{num_part}\" is not of the expected form <pos-integer>[<unit>]"
        )
    })?;

    let multiplier = match unit {
        None => 1.0,
        Some("block") => block_size as f64,
        Some("kib") => 1024.0,
        Some("mib") => 1024.0 * 1024.0,
        Some("gib") => 1024.0 * 1024.0 * 1024.0,
        Some("tib") => 1024.0 * 1024.0 * 1024.0 * 1024.0,
        Some("kb") => 1000.0,
        Some("mb") => 1_000_000.0,
        Some("gb") => 1_000_000_000.0,
        Some("tb") => 1_000_000_000_000.0,
        Some(_) => unreachable!(),
    };

    let value = (base * multiplier).round() as u64;
    if value as f64 != base * multiplier && unit.is_none() && num_part.contains('.') {
        return Err(anyhow!("failed to parse `{s}` as byte count"));
    }
    Ok(value)
}
