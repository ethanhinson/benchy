use std::env;
use std::io::{self, IsTerminal, Write};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorMode {
    Always,
    Auto,
    Never,
    Force,
}

#[derive(Debug, Clone)]
pub struct ColorPalette {
    pub null: String,
    pub ascii_printable: String,
    pub ascii_whitespace: String,
    pub ascii_other: String,
    pub non_ascii: String,
    pub offset: String,
    pub reset: String,
}

impl ColorPalette {
    pub fn from_env(use_color: bool) -> Self {
        if !use_color {
            return Self::disabled();
        }

        Self {
            null: env_color("HEXYL_COLOR_NULL").unwrap_or_else(|| ansi_bright("black")),
            ascii_printable: env_color("HEXYL_COLOR_ASCII_PRINTABLE")
                .unwrap_or_else(|| ansi_basic("cyan")),
            ascii_whitespace: env_color("HEXYL_COLOR_ASCII_WHITESPACE")
                .unwrap_or_else(|| ansi_basic("green")),
            ascii_other: env_color("HEXYL_COLOR_ASCII_OTHER").unwrap_or_else(|| ansi_basic("green")),
            non_ascii: env_color("HEXYL_COLOR_NONASCII").unwrap_or_else(|| ansi_basic("yellow")),
            offset: env_color("HEXYL_COLOR_OFFSET").unwrap_or_default(),
            reset: "\x1b[39m".to_string(),
        }
    }

    pub fn disabled() -> Self {
        Self {
            null: String::new(),
            ascii_printable: String::new(),
            ascii_whitespace: String::new(),
            ascii_other: String::new(),
            non_ascii: String::new(),
            offset: String::new(),
            reset: String::new(),
        }
    }

    pub fn wrap_byte(&self, byte: u8, text: &str, gradient: bool) -> String {
        if self.reset.is_empty() {
            return text.to_string();
        }

        let color = if gradient {
            gradient_color(byte)
        } else {
            self.classic_color(byte).to_string()
        };

        format!("{color}{text}{}", self.reset)
    }

    fn classic_color(&self, byte: u8) -> &str {
        if byte == 0 {
            &self.null
        } else if byte >= 0x80 {
            &self.non_ascii
        } else if is_ascii_whitespace(byte) {
            &self.ascii_whitespace
        } else if (0x21..=0x7e).contains(&byte) {
            &self.ascii_printable
        } else {
            &self.ascii_other
        }
    }
}

pub fn should_use_color(mode: ColorMode, stdout: bool) -> bool {
    let is_tty = if stdout {
        io::stdout().is_terminal()
    } else {
        io::stderr().is_terminal()
    };

    match mode {
        ColorMode::Never => false,
        ColorMode::Always | ColorMode::Force => true,
        ColorMode::Auto => is_tty,
    }
}

pub fn print_color_table(use_color: bool) -> io::Result<()> {
    let palette = ColorPalette::from_env(use_color);
    let mut out = io::stdout().lock();
    writeln!(out, "hexyl color reference:")?;
    writeln!(out)?;
    write!(out, "{}⋄ NULL bytes (0x00)\n", palette.null)?;
    write!(
        out,
        "{}{}a ASCII printable characters (0x20 - 0x7E)\n",
        palette.reset, palette.ascii_printable
    )?;
    write!(
        out,
        "{}{}_ ASCII whitespace (0x09 - 0x0D, 0x20)\n",
        palette.reset, palette.ascii_whitespace
    )?;
    write!(
        out,
        "{}{}• ASCII control characters (except NULL and whitespace)\n",
        palette.reset, palette.ascii_other
    )?;
    write!(
        out,
        "{}{}× Non-ASCII bytes (0x80 - 0xFF)\n",
        palette.reset, palette.non_ascii
    )?;
    write!(out, "{}", palette.reset)?;
    Ok(())
}

fn env_color(name: &str) -> Option<String> {
    env::var(name).ok().map(|value| parse_color(&value))
}

fn parse_color(name: &str) -> String {
    let trimmed = name.trim();
    if trimmed.starts_with('#') && trimmed.len() == 7 {
        let r = u8::from_str_radix(&trimmed[1..3], 16).unwrap_or(0);
        let g = u8::from_str_radix(&trimmed[3..5], 16).unwrap_or(0);
        let b = u8::from_str_radix(&trimmed[5..7], 16).unwrap_or(0);
        return format!("\x1b[38;2;{r};{g};{b}m");
    }

    let lower = trimmed.to_ascii_lowercase();
    let bright = lower.starts_with("bright ");
    let base = if bright { &lower[7..] } else { &lower };

    let code = match base {
        "black" => 0,
        "red" => 1,
        "green" => 2,
        "yellow" => 3,
        "blue" => 4,
        "magenta" => 5,
        "cyan" => 6,
        "white" => 7,
        _ => 7,
    };

    if bright {
        format!("\x1b[9{code}m")
    } else {
        format!("\x1b[3{code}m")
    }
}

fn ansi_basic(name: &str) -> String {
    parse_color(name)
}

fn ansi_bright(name: &str) -> String {
    parse_color(&format!("bright {name}"))
}

pub fn is_ascii_whitespace(byte: u8) -> bool {
    matches!(byte, 0x09 | 0x0a | 0x0c | 0x0d | 0x20)
}

fn gradient_color(byte: u8) -> String {
    if byte == 0 {
        return ansi_bright("black");
    }
    if (0x21..=0x7e).contains(&byte) {
        return ansi_basic("cyan");
    }
    if byte < 0x80 {
        let t = byte as f32 / 127.0;
        let r = lerp(255.0, 127.0, t) as u8;
        let g = lerp(127.0, 0.0, t) as u8;
        let b = lerp(153.0, 255.0, t) as u8;
        return format!("\x1b[38;2;{r};{g};{b}m");
    }

    let t = (byte - 0x80) as f32 / 127.0;
    let (r, g, b) = if t < 0.5 {
        let t2 = t * 2.0;
        (lerp(255.0, 255.0, t2) as u8, lerp(0.0, 255.0, t2) as u8, 0)
    } else {
        let t2 = (t - 0.5) * 2.0;
        (255, lerp(255.0, 255.0, t2) as u8, lerp(0.0, 255.0, t2) as u8)
    };
    format!("\x1b[38;2;{r};{g};{b}m")
}

fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}
