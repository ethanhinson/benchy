use crate::bytecount::ByteCount;
use crate::chars::{map_byte, CharacterTable};
use crate::colors::{ColorMode, ColorPalette};
use anyhow::{anyhow, Context, Result};
use std::io::{self, Write};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BorderStyle {
    Unicode,
    Ascii,
    None,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Base {
    Binary,
    Octal,
    Decimal,
    Hexadecimal,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Endianness {
    Little,
    Big,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorScheme {
    Default,
    Gradient,
}

pub struct Config {
    pub no_squeezing: bool,
    pub color_mode: ColorMode,
    pub border: BorderStyle,
    pub show_characters: bool,
    pub character_table: CharacterTable,
    pub color_scheme: ColorScheme,
    pub show_position: bool,
    pub data_offset: u64,
    pub panels: PanelCount,
    pub group_size: u8,
    pub endianness: Endianness,
    pub base: Base,
    pub terminal_width: Option<u16>,
    pub include_style: bool,
    pub filename: Option<String>,
}

#[derive(Debug, Clone, Copy)]
pub enum PanelCount {
    Fixed(u8),
    Auto,
}

impl Config {
    pub fn effective_panels(&self) -> u8 {
        if self.base != Base::Hexadecimal {
            return 1;
        }
        if let Some(width) = self.terminal_width {
            return panels_for_width(width, self.show_position, self.show_characters);
        }
        match self.panels {
            PanelCount::Fixed(n) => n,
            PanelCount::Auto => {
                if let Some((width, _)) = terminal_size::terminal_size() {
                    panels_for_width(width.0, self.show_position, self.show_characters)
                } else {
                    2
                }
            }
        }
    }

    pub fn bytes_per_line(&self) -> usize {
        if self.base != Base::Hexadecimal {
            8
        } else {
            (self.effective_panels() as usize) * 8
        }
    }
}

fn panels_for_width(width: u16, show_position: bool, show_characters: bool) -> u8 {
    let mut remaining = width as i32;
    if show_position {
        remaining -= 10;
    }
    if show_characters {
        remaining -= 9;
    }
    let panel_width = 25;
    ((remaining + panel_width - 1) / panel_width).max(1).min(2) as u8
}

struct Layout {
    line_width: usize,
    hex_start: usize,
    panel_sep: usize,
    char_start: Option<usize>,
}

impl Layout {
    fn for_config(config: &Config) -> Self {
        let panels = config.effective_panels() as usize;
        let show_pos = config.show_position;
        let show_char = config.show_characters;
        let gs = config.group_size.max(1) as usize;

        let hex_start = if show_pos { 11 } else { 2 };
        let panel_width = hex_panel_width(config.base, gs);
        let panel_sep = if config.base == Base::Hexadecimal && panels > 1 {
            3
        } else {
            1
        };

        let hex_total = panels * panel_width + (panels.saturating_sub(1)) * panel_sep;

        let char_start = if show_char {
            Some(match (config.base, panels, gs, show_pos) {
                (Base::Hexadecimal, 2, 1, true) => 62,
                (Base::Hexadecimal, 2, 2, true) => 54,
                (Base::Hexadecimal, 2, 4, true) => 50,
                (Base::Hexadecimal, 1, 1, true) => 36,
                (Base::Hexadecimal, 2, 1, false) => 53,
                (Base::Hexadecimal, 1, 1, false) => 27,
                (Base::Binary, _, _, true) => 84,
                (Base::Binary, _, _, false) => 75,
                (Base::Octal | Base::Decimal, _, _, true) => 44,
                (Base::Octal | Base::Decimal, _, _, false) => 35,
                _ => hex_start + hex_total + 1,
            })
        } else {
            None
        };

        let line_width = if config.border != BorderStyle::None {
            0
        } else {
            match (show_pos, show_char, config.base, panels, gs) {
                (true, true, Base::Hexadecimal, 2, 1) => 80,
                (true, true, Base::Hexadecimal, 2, 2) => 72,
                (true, true, Base::Hexadecimal, 2, 4) => 68,
                (true, true, Base::Hexadecimal, 1, 1) => 45,
                (false, true, Base::Hexadecimal, 2, 1) => 71,
                (false, true, Base::Hexadecimal, 1, 1) => 36,
                (true, false, Base::Hexadecimal, 2, 1) => 62,
                (false, false, Base::Hexadecimal, 2, 1) => 53,
                (true, false, Base::Hexadecimal, 1, 1) => 35,
                (true, true, Base::Binary, _, _) => 93,
                (false, true, Base::Binary, _, _) => 84,
                (true, true, Base::Octal | Base::Decimal, _, _) => 53,
                (false, true, Base::Octal | Base::Decimal, _, _) => 44,
                (true, false, _, _, _) => char_start.unwrap_or(hex_start + hex_total) + 1,
                (false, false, _, _, _) => hex_start + hex_total,
                _ => char_start.map(|c| c + 18).unwrap_or(hex_start + hex_total + 5),
            }
        };

        Self {
            line_width,
            hex_start,
            panel_sep,
            char_start,
        }
    }
}

fn hex_panel_width(base: Base, group_size: usize) -> usize {
    match base {
        Base::Hexadecimal if group_size == 1 => 23,
        Base::Hexadecimal if group_size == 2 => 19,
        Base::Hexadecimal if group_size == 4 => 17,
        Base::Hexadecimal if group_size == 8 => 17,
        Base::Binary => 71,
        Base::Octal => 31,
        Base::Decimal => 31,
        _ => 23,
    }
}

pub fn print_include(data: &[u8], filename: Option<&str>, out: &mut dyn Write) -> io::Result<()> {
    let name = filename
        .map(sanitize_filename)
        .unwrap_or_else(|| "stdin".to_string());

    writeln!(out, "unsigned char {name}[] = {{")?;
    write!(out, "  ")?;
    for (i, byte) in data.iter().enumerate() {
        if i > 0 {
            write!(out, ", ")?;
        }
        write!(out, "0x{byte:02x}")?;
    }
    writeln!(out)?;
    writeln!(out, "}};")?;
    writeln!(out, "unsigned int {name}_len = {};", data.len())?;
    Ok(())
}

fn sanitize_filename(path: &str) -> String {
    let base = std::path::Path::new(path)
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("data");
    base.chars()
        .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' })
        .collect()
}

pub struct Printer<'a> {
    pub config: &'a Config,
    pub palette: ColorPalette,
    pub use_color: bool,
}

impl<'a> Printer<'a> {
    pub fn print(&self, data: &[u8], out: &mut dyn Write) -> io::Result<()> {
        if self.config.include_style {
            return print_include(data, self.config.filename.as_deref(), out);
        }

        let bytes_per_line = self.config.bytes_per_line();
        let lines: Vec<Vec<u8>> = data.chunks(bytes_per_line).map(<[u8]>::to_vec).collect();
        if lines.is_empty() {
            return Ok(());
        }

        let layout = Layout::for_config(self.config);
        let squeeze = !self.config.no_squeezing;

        if matches!(self.config.border, BorderStyle::Ascii | BorderStyle::Unicode) {
            self.print_border_top(out)?;
        }

        let mut i = 0;
        while i < lines.len() {
            let run_end = if squeeze {
                find_squeezable_run(&lines, i)
            } else {
                i + 1
            };

            if squeeze && run_end > i + 2 {
                let address = self.config.data_offset + i as u64 * bytes_per_line as u64;
                self.print_data_line(&lines[i], address, &layout, out)?;
                self.print_squeeze_marker(&layout, out)?;
                let end_offset = self.config.data_offset + run_end as u64 * bytes_per_line as u64;
                self.print_end_offset(end_offset, &layout, out)?;
                i = run_end;
                continue;
            }

            for (j, line) in lines[i..run_end].iter().enumerate() {
                let line_idx = i + j;
                let address =
                    self.config.data_offset + line_idx as u64 * bytes_per_line as u64;
                self.print_data_line(line, address, &layout, out)?;
            }
            i = run_end;
        }

        if matches!(self.config.border, BorderStyle::Ascii | BorderStyle::Unicode) {
            self.print_border_bottom(out)?;
        }

        Ok(())
    }

    fn print_squeeze_marker(&self, layout: &Layout, out: &mut dyn Write) -> io::Result<()> {
        match self.config.border {
            BorderStyle::None => {
                let mut line = String::new();
                line.push(' ');
                line.push('*');
                pad_line(&mut line, layout.line_width);
                writeln!(out, "{line}")
            }
            BorderStyle::Ascii => writeln!(
                out,
                "|*                                                                      |"
            ),
            BorderStyle::Unicode => writeln!(
                out,
                "│*                                                                      │"
            ),
        }
    }

    fn print_end_offset(&self, offset: u64, layout: &Layout, out: &mut dyn Write) -> io::Result<()> {
        match self.config.border {
            BorderStyle::None => {
                let mut line = String::new();
                line.push(' ');
                line.push_str(&format!("{offset:08x}"));
                pad_line(&mut line, layout.line_width);
                writeln!(out, "{line}")
            }
            BorderStyle::Ascii => writeln!(
                out,
                "|{offset:08x}                                                                  |"
            ),
            BorderStyle::Unicode => writeln!(
                out,
                "│{offset:08x}                                                                  │"
            ),
        }
    }

    fn print_data_line(
        &self,
        line: &[u8],
        address: u64,
        layout: &Layout,
        out: &mut dyn Write,
    ) -> io::Result<()> {
        match self.config.border {
            BorderStyle::None => self.print_line_no_border(line, address, layout, out),
            BorderStyle::Ascii => self.print_line_bordered(line, address, out, true),
            BorderStyle::Unicode => self.print_line_bordered(line, address, out, false),
        }
    }

    fn print_line_no_border(
        &self,
        line: &[u8],
        address: u64,
        layout: &Layout,
        out: &mut dyn Write,
    ) -> io::Result<()> {
        let mut buf = String::new();

        if self.config.show_position {
            buf.push(' ');
            write_colored(&mut buf, &format!("{address:08x}"), &self.palette.offset, self.use_color, &self.palette.reset);
            buf.push_str("  ");
        } else {
            buf.push_str("  ");
        }

        while display_width(&buf) < layout.hex_start {
            buf.push(' ');
        }

        let panels = self.config.effective_panels() as usize;
        for panel in 0..panels {
            let start = panel * 8;
            if start >= line.len() && panel > 0 {
                break;
            }
            if panel > 0 {
                buf.push_str(&" ".repeat(layout.panel_sep));
            }
            let end = (start + 8).min(line.len());
            if start < line.len() {
                buf.push_str(&self.format_hex_panel(&line[start..end]));
            }
        }

        if let Some(char_start) = layout.char_start {
            while display_width(&buf) < char_start {
                buf.push(' ');
            }
            buf.push_str(&self.format_chars(line));
        }

        pad_line(&mut buf, layout.line_width);
        writeln!(out, "{buf}")
    }

    fn print_line_bordered(
        &self,
        line: &[u8],
        address: u64,
        out: &mut dyn Write,
        ascii: bool,
    ) -> io::Result<()> {
        let (v, sep) = if ascii { ('|', '|') } else { ('│', '┊') };
        let panel_count = self.config.effective_panels() as usize;
        let char_width = 8;

        write!(out, "{v}")?;
        if self.config.show_position {
            write!(out, "{address:08x}")?;
        } else {
            write!(out, "{:>8}", "")?;
        }
        write!(out, "{v}")?;

        for panel in 0..panel_count {
            let start = panel * 8;
            let panel_str = if start < line.len() {
                let end = (start + 8).min(line.len());
                self.format_hex_panel(&line[start..end])
            } else {
                String::new()
            };
            if panel > 0 {
                write!(out, "{}", if ascii { '|' } else { '┊' })?;
            }
            write!(out, "{:25}", format!(" {panel_str}"))?;
        }

        if self.config.show_characters {
            write!(out, "{v}")?;
            for panel in 0..panel_count {
                let start = panel * 8;
                let char_panel = if start < line.len() {
                    let end = (start + 8).min(line.len());
                    self.format_char_run(&line[start..end])
                } else {
                    String::new()
                };
                if panel > 0 {
                    write!(out, "{sep}")?;
                }
                write!(out, "{char_panel:<char_width$}")?;
            }
            write!(out, "{v}")?;
        }

        writeln!(out)
    }

    fn print_border_top(&self, out: &mut dyn Write) -> io::Result<()> {
        let panel_count = self.config.effective_panels() as usize;
        match self.config.border {
            BorderStyle::None => Ok(()),
            BorderStyle::Ascii => {
                write!(out, "+")?;
                write!(out, "{}", "-".repeat(8))?;
                write!(out, "+")?;
                for _ in 0..panel_count {
                    write!(out, "{}", "-".repeat(25))?;
                    write!(out, "+")?;
                }
                if self.config.show_characters {
                    for _ in 0..panel_count {
                        write!(out, "{}", "-".repeat(8))?;
                        write!(out, "+")?;
                    }
                }
                writeln!(out)
            }
            BorderStyle::Unicode => {
                write!(out, "┌")?;
                write!(out, "{}", "─".repeat(8))?;
                write!(out, "┬")?;
                for _ in 0..panel_count {
                    write!(out, "{}", "─".repeat(25))?;
                    write!(out, "┬")?;
                }
                if self.config.show_characters {
                    for i in 0..panel_count {
                        write!(out, "{}", "─".repeat(8))?;
                        if i + 1 < panel_count {
                            write!(out, "┬")?;
                        }
                    }
                    write!(out, "┐")?;
                }
                writeln!(out)
            }
        }
    }

    fn print_border_bottom(&self, out: &mut dyn Write) -> io::Result<()> {
        let panel_count = self.config.effective_panels() as usize;
        match self.config.border {
            BorderStyle::None => Ok(()),
            BorderStyle::Ascii => {
                write!(out, "+")?;
                write!(out, "{}", "-".repeat(8))?;
                write!(out, "+")?;
                for _ in 0..panel_count {
                    write!(out, "{}", "-".repeat(25))?;
                    write!(out, "+")?;
                }
                if self.config.show_characters {
                    for _ in 0..panel_count {
                        write!(out, "{}", "-".repeat(8))?;
                        write!(out, "+")?;
                    }
                }
                writeln!(out)
            }
            BorderStyle::Unicode => {
                write!(out, "└")?;
                write!(out, "{}", "─".repeat(8))?;
                write!(out, "┴")?;
                for _ in 0..panel_count {
                    write!(out, "{}", "─".repeat(25))?;
                    write!(out, "┴")?;
                }
                if self.config.show_characters {
                    for i in 0..panel_count {
                        write!(out, "{}", "─".repeat(8))?;
                        if i + 1 < panel_count {
                            write!(out, "┴")?;
                        }
                    }
                    write!(out, "┘")?;
                }
                writeln!(out)
            }
        }
    }

    fn format_hex_panel(&self, bytes: &[u8]) -> String {
        if bytes.is_empty() {
            return String::new();
        }

        let gs = self.config.group_size.max(1) as usize;
        let parts: Vec<String> = bytes
            .chunks(gs)
            .map(|chunk| self.format_group(chunk))
            .collect();
        parts.join(" ")
    }

    fn format_group(&self, bytes: &[u8]) -> String {
        let display_bytes = if self.config.group_size > 1 && bytes.len() == self.config.group_size as usize
        {
            reorder_group(bytes, self.config.endianness)
        } else {
            bytes.to_vec()
        };

        match self.config.base {
            Base::Hexadecimal if self.config.group_size > 1 => {
                let text: String = display_bytes.iter().map(|b| format!("{b:02x}")).collect();
                colorize_byte(self, display_bytes[0], &text)
            }
            Base::Hexadecimal => {
                display_bytes
                    .iter()
                    .map(|&b| colorize_byte(self, b, &format!("{b:02x}")))
                    .collect::<Vec<_>>()
                    .join(" ")
            }
            Base::Binary => display_bytes
                .iter()
                .map(|&b| colorize_byte(self, b, &format!("{b:08b}")))
                .collect::<Vec<_>>()
                .join(" "),
            Base::Octal => display_bytes
                .iter()
                .map(|&b| colorize_byte(self, b, &format!("{b:03o}")))
                .collect::<Vec<_>>()
                .join(" "),
            Base::Decimal => display_bytes
                .iter()
                .map(|&b| colorize_byte(self, b, &format!("{b:03}")))
                .collect::<Vec<_>>()
                .join(" "),
        }
    }

    fn format_chars(&self, line: &[u8]) -> String {
        if self.config.bytes_per_line() >= 16 && line.len() > 8 {
            format!(
                "{} {}",
                self.format_char_run(&line[..8.min(line.len())]),
                self.format_char_run(&line[8.min(line.len())..])
            )
        } else {
            self.format_char_run(line)
        }
    }

    fn format_char_run(&self, bytes: &[u8]) -> String {
        bytes
            .iter()
            .map(|&b| {
                let ch = map_byte(b, self.config.character_table);
                colorize_byte(self, b, &ch.to_string())
            })
            .collect()
    }
}

fn colorize_byte(printer: &Printer<'_>, byte: u8, text: &str) -> String {
    if printer.use_color {
        printer.palette.wrap_byte(
            byte,
            text,
            printer.config.color_scheme == ColorScheme::Gradient,
        )
    } else {
        text.to_string()
    }
}

fn write_colored(buf: &mut String, text: &str, color: &str, use_color: bool, reset: &str) {
    if use_color && !color.is_empty() {
        buf.push_str(color);
        buf.push_str(text);
        buf.push_str(reset);
    } else {
        buf.push_str(text);
    }
}

fn pad_line(line: &mut String, width: usize) {
    while line.chars().count() < width {
        line.push(' ');
    }
}

fn display_width(s: &str) -> usize {
    s.chars().count()
}

fn reorder_group(bytes: &[u8], endianness: Endianness) -> Vec<u8> {
    match endianness {
        Endianness::Big => bytes.to_vec(),
        Endianness::Little => {
            let mut v = bytes.to_vec();
            v.reverse();
            v
        }
    }
}

fn find_squeezable_run(lines: &[Vec<u8>], start: usize) -> usize {
    if start + 1 >= lines.len() {
        return start + 1;
    }
    let reference = &lines[start];
    let mut end = start + 1;
    while end < lines.len() && lines[end] == *reference {
        end += 1;
    }
    end
}

pub struct InputData {
    pub bytes: Vec<u8>,
    pub data_offset: u64,
}

pub fn load_input(
    file: Option<&str>,
    skip: i64,
    length: Option<u64>,
    display_offset: i64,
) -> Result<InputData> {
    use std::io::{Read, Seek, SeekFrom};

    if let Some(path) = file {
        let mut file = std::fs::File::open(path).map_err(|e| {
            if e.kind() == std::io::ErrorKind::NotFound {
                anyhow!("No such file or directory (os error 2)")
            } else {
                anyhow!(e)
            }
        })?;
        let file_len = file.metadata()?.len() as i64;

        let start = if skip < 0 {
            (file_len + skip).max(0) as u64
        } else {
            skip as u64
        };

        if skip != 0 {
            file.seek(SeekFrom::Start(start))?;
        }

        let mut buf = Vec::new();
        if let Some(len) = length {
            file.take(len).read_to_end(&mut buf)?;
        } else {
            file.read_to_end(&mut buf)?;
        }

        Ok(InputData {
            bytes: buf,
            data_offset: (start as i64 + display_offset).max(0) as u64,
        })
    } else {
        let stdin = io::stdin();
        let mut handle = stdin.lock();
        if skip > 0 {
            let mut discard = vec![0u8; skip as usize];
            handle.read_exact(&mut discard)?;
        }
        let mut buf = Vec::new();
        if let Some(len) = length {
            handle.take(len).read_to_end(&mut buf)?;
        } else {
            handle.read_to_end(&mut buf)?;
        }
        Ok(InputData {
            bytes: buf,
            data_offset: (skip.max(0) as i64 + display_offset).max(0) as u64,
        })
    }
}

pub fn parse_length_arg(s: &str, block_size: u64) -> Result<u64> {
    ByteCount::parse_positive(s, block_size)
        .with_context(|| format!("failed to parse `--length` arg \"{s}\" as byte count"))
}

pub fn parse_skip_arg(s: &str, block_size: u64) -> Result<i64> {
    ByteCount::parse(s, block_size, true)
        .with_context(|| format!("failed to parse `--skip` arg \"{s}\" as byte count"))
}

pub fn parse_display_offset_arg(s: &str, block_size: u64) -> Result<i64> {
    ByteCount::parse(s, block_size, false).with_context(|| {
        format!("failed to parse `--display-offset` arg \"{s}\" as byte count")
    })
}
