mod bytecount;
mod chars;
mod colors;
mod print;

use anyhow::{Context, Result};
use clap::{CommandFactory, Parser, ValueEnum};
use clap_complete::{generate, Shell};
use colors::{print_color_table, should_use_color, ColorMode, ColorPalette};
use print::{
    load_input, parse_display_offset_arg, parse_length_arg, parse_skip_arg, Base, BorderStyle,
    ColorScheme, Config, Endianness, PanelCount, Printer,
};
use std::io;

#[derive(Parser)]
#[command(
    name = "hexyl",
    version = "0.16.0",
    about = "A command-line hex viewer"
)]
struct Cli {
    #[arg(value_name = "FILE")]
    file: Option<String>,

    #[arg(short = 'n', long = "length", alias = "bytes", visible_short_aliases = ['c'])]
    length: Option<String>,

    #[arg(short = 's', long = "skip")]
    skip: Option<String>,

    #[arg(long = "block-size", default_value = "512")]
    block_size: String,

    #[arg(short = 'v', long = "no-squeezing")]
    no_squeezing: bool,

    #[arg(long = "color", default_value = "always")]
    color: ColorWhen,

    #[arg(long = "border", default_value = "unicode")]
    border: BorderWhen,

    #[arg(short = 'p', long = "plain")]
    plain: bool,

    #[arg(long = "no-characters")]
    no_characters: bool,

    #[arg(short = 'C', long = "characters")]
    characters: bool,

    #[arg(long = "character-table", default_value = "default")]
    character_table: CharacterTableArg,

    #[arg(long = "color-scheme", default_value = "default")]
    color_scheme: ColorSchemeArg,

    #[arg(short = 'P', long = "no-position")]
    no_position: bool,

    #[arg(short = 'o', long = "display-offset", default_value = "0")]
    display_offset: String,

    #[arg(long = "panels", default_value = "2")]
    panels: String,

    #[arg(short = 'g', long = "group-size", default_value = "1")]
    group_size: GroupSizeArg,

    #[arg(long = "groupsize", hide = true)]
    groupsize: Option<GroupSizeArg>,

    #[arg(long = "endianness", default_value = "big")]
    endianness: EndiannessArg,

    #[arg(short = 'e', hide = true)]
    little_endian: bool,

    #[arg(short = 'b', long = "base", default_value = "hexadecimal")]
    base: BaseArg,

    #[arg(long = "terminal-width")]
    terminal_width: Option<u16>,

    #[arg(long = "print-color-table")]
    print_color_table: bool,

    #[arg(short = 'i', long = "include")]
    include: bool,

    #[arg(long = "completion")]
    completion: Option<Shell>,
}

#[derive(Clone, ValueEnum)]
enum ColorWhen {
    Always,
    Auto,
    Never,
    Force,
}

#[derive(Clone, ValueEnum)]
enum BorderWhen {
    Unicode,
    Ascii,
    None,
}

#[derive(Clone, ValueEnum)]
enum CharacterTableArg {
    Default,
    Ascii,
    #[value(name = "codepage-1047")]
    Codepage1047,
    #[value(name = "codepage-437")]
    Codepage437,
    Braille,
}

#[derive(Clone, ValueEnum)]
enum ColorSchemeArg {
    Default,
    Gradient,
}

#[derive(Clone, Copy, ValueEnum)]
enum GroupSizeArg {
    #[value(name = "1")]
    One = 1,
    #[value(name = "2")]
    Two = 2,
    #[value(name = "4")]
    Four = 4,
    #[value(name = "8")]
    Eight = 8,
}

#[derive(Clone, ValueEnum)]
enum EndiannessArg {
    Little,
    Big,
}

#[derive(Clone, ValueEnum)]
enum BaseArg {
    Binary,
    Octal,
    Decimal,
    Hexadecimal,
}

fn main() -> Result<()> {
    let cli = Cli::parse();

    if let Some(shell) = cli.completion {
        let mut cmd = Cli::command();
        generate(shell, &mut cmd, "hexyl", &mut io::stdout());
        return Ok(());
    }

    let block_size = parse_length_arg(&cli.block_size, 512)?;
    let use_color = should_use_color(
        match cli.color {
            ColorWhen::Always => ColorMode::Always,
            ColorWhen::Auto => ColorMode::Auto,
            ColorWhen::Never => ColorMode::Never,
            ColorWhen::Force => ColorMode::Force,
        },
        true,
    );

    if cli.print_color_table {
        print_color_table(use_color)?;
        return Ok(());
    }

    let length = cli
        .length
        .as_deref()
        .map(|s| parse_length_arg(s, block_size))
        .transpose()?;

    let skip = cli
        .skip
        .as_deref()
        .map(|s| parse_skip_arg(s, block_size))
        .transpose()?
        .unwrap_or(0);

    let display_offset = parse_display_offset_arg(&cli.display_offset, block_size)?;

    let mut show_characters = !cli.no_characters;
    if cli.characters {
        show_characters = true;
    }

    let mut border = match cli.border {
        BorderWhen::Unicode => BorderStyle::Unicode,
        BorderWhen::Ascii => BorderStyle::Ascii,
        BorderWhen::None => BorderStyle::None,
    };
    let mut show_position = !cli.no_position;
    let mut color_mode = match cli.color {
        ColorWhen::Always => ColorMode::Always,
        ColorWhen::Auto => ColorMode::Auto,
        ColorWhen::Never => ColorMode::Never,
        ColorWhen::Force => ColorMode::Force,
    };

    if cli.plain {
        show_characters = false;
        show_position = false;
        border = BorderStyle::None;
        color_mode = ColorMode::Never;
    }

    let panels = if cli.panels.eq_ignore_ascii_case("auto") {
        PanelCount::Auto
    } else {
        PanelCount::Fixed(cli.panels.parse().context("invalid panels value")?)
    };

    let group_size = cli
        .groupsize
        .map(|g| g as u8)
        .unwrap_or(cli.group_size as u8);

    let endianness = if cli.little_endian {
        Endianness::Little
    } else {
        match cli.endianness {
            EndiannessArg::Little => Endianness::Little,
            EndiannessArg::Big => Endianness::Big,
        }
    };

    let input = load_input(cli.file.as_deref(), skip, length, display_offset)?;

    let config = Config {
        no_squeezing: cli.no_squeezing,
        color_mode,
        border,
        show_characters,
        character_table: match cli.character_table {
            CharacterTableArg::Default => chars::CharacterTable::Default,
            CharacterTableArg::Ascii => chars::CharacterTable::Ascii,
            CharacterTableArg::Codepage1047 => chars::CharacterTable::Codepage1047,
            CharacterTableArg::Codepage437 => chars::CharacterTable::Codepage437,
            CharacterTableArg::Braille => chars::CharacterTable::Braille,
        },
        color_scheme: match cli.color_scheme {
            ColorSchemeArg::Default => ColorScheme::Default,
            ColorSchemeArg::Gradient => ColorScheme::Gradient,
        },
        show_position,
        data_offset: input.data_offset,
        panels,
        group_size,
        endianness,
        base: match cli.base {
            BaseArg::Binary => Base::Binary,
            BaseArg::Octal => Base::Octal,
            BaseArg::Decimal => Base::Decimal,
            BaseArg::Hexadecimal => Base::Hexadecimal,
        },
        terminal_width: cli.terminal_width,
        include_style: cli.include,
        filename: cli.file.clone(),
    };

    let use_color = should_use_color(config.color_mode, true);
    let palette = ColorPalette::from_env(use_color);
    let printer = Printer {
        config: &config,
        palette,
        use_color,
    };

    let stdout = io::stdout();
    let mut handle = stdout.lock();
    printer.print(&input.bytes, &mut handle)?;
    Ok(())
}
