use regex::Regex;

pub enum Delimiter<'a> {
    Literal(&'a str),
    Regex(Regex),
}

pub fn split_fields<'a>(
    input: &'a str,
    delimiter: &Delimiter,
    greedy: bool,
    compress: bool,
) -> Vec<&'a str> {
    if compress && !greedy {
        match delimiter {
            Delimiter::Literal(d) if !d.is_empty() => {
                return split_literal(input, d);
            }
            _ => {}
        }
    }

    match delimiter {
        Delimiter::Literal(d) if d.is_empty() => vec![input],
        Delimiter::Literal(d) if greedy => split_greedy(input, d),
        Delimiter::Literal(d) => split_literal_all(input, d),
        Delimiter::Regex(re) => split_regex(input, re),
    }
}

fn split_literal_all<'a>(input: &'a str, delimiter: &str) -> Vec<&'a str> {
    if delimiter.is_empty() {
        return vec![input];
    }

    let mut fields = Vec::new();
    let mut start = 0;
    let mut i = 0;
    while i <= input.len() {
        if input[i..].starts_with(delimiter) {
            fields.push(&input[start..i]);
            i += delimiter.len();
            start = i;
        } else if i == input.len() {
            fields.push(&input[start..i]);
            break;
        } else {
            i += 1;
        }
    }
    fields
}

fn split_literal<'a>(input: &'a str, delimiter: &str) -> Vec<&'a str> {
    if delimiter.is_empty() {
        return vec![input];
    }

    let mut fields = Vec::new();
    let mut start = 0;
    let mut i = 0;
    let mut in_run = false;
    while i <= input.len() {
        if input[i..].starts_with(delimiter) {
            if !in_run {
                fields.push(&input[start..i]);
                start = i + delimiter.len();
                in_run = true;
            } else {
                start = i + delimiter.len();
            }
            i += delimiter.len();
        } else if i == input.len() {
            fields.push(&input[start..i]);
            break;
        } else {
            in_run = false;
            i += 1;
        }
    }
    fields
}

fn split_greedy<'a>(input: &'a str, delimiter: &str) -> Vec<&'a str> {
    if delimiter.is_empty() {
        return vec![input];
    }

    if delimiter.len() == 1 {
        let d = delimiter.as_bytes()[0];
        let mut fields = Vec::new();
        let bytes = input.as_bytes();
        let mut start = 0;
        let mut i = 0;
        while i <= bytes.len() {
            if i < bytes.len() && bytes[i] == d {
                fields.push(&input[start..i]);
                while i < bytes.len() && bytes[i] == d {
                    i += 1;
                }
                start = i;
            } else if i == bytes.len() {
                fields.push(&input[start..i]);
                break;
            } else {
                i += 1;
            }
        }
        return fields;
    }

    let mut fields = Vec::new();
    let mut start = 0;
    let mut i = 0;
    while i <= input.len() {
        if input[i..].starts_with(delimiter) {
            fields.push(&input[start..i]);
            while input[i..].starts_with(delimiter) {
                i += delimiter.len();
            }
            start = i;
        } else if i == input.len() {
            fields.push(&input[start..i]);
            break;
        } else {
            i += 1;
        }
    }
    fields
}

fn split_regex<'a>(input: &'a str, re: &Regex) -> Vec<&'a str> {
    let mut fields = Vec::new();
    let mut last = 0;
    for mat in re.find_iter(input) {
        fields.push(&input[last..mat.start()]);
        last = mat.end();
    }
    fields.push(&input[last..]);
    fields
}

pub fn trim_field(field: &str, delimiter: &Delimiter, trim: Option<char>) -> String {
    let Some(trim_kind) = trim else {
        return field.to_string();
    };

    let trim_chars: Vec<char> = match delimiter {
        Delimiter::Literal(d) => d.chars().collect(),
        Delimiter::Regex(_) => return field.to_string(),
    };

    if trim_chars.is_empty() {
        return field.to_string();
    }

    let mut result = field.to_string();
    match trim_kind {
        'l' | 'L' => {
            while let Some(first) = result.chars().next() {
                if trim_chars.contains(&first) {
                    result.remove(0);
                } else {
                    break;
                }
            }
        }
        'r' | 'R' => {
            while let Some(last) = result.chars().last() {
                if trim_chars.contains(&last) {
                    result.pop();
                } else {
                    break;
                }
            }
        }
        'b' | 'B' => {
            while let Some(first) = result.chars().next() {
                if trim_chars.contains(&first) {
                    result.remove(0);
                } else {
                    break;
                }
            }
            while let Some(last) = result.chars().last() {
                if trim_chars.contains(&last) {
                    result.pop();
                } else {
                    break;
                }
            }
        }
        _ => {}
    }
    result
}