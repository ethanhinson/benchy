use crate::bounds::{self, BoundItem, BoundsSpec};
use crate::split::{Delimiter, trim_field};

#[derive(Clone, Copy)]
pub struct FieldSpan {
    pub start: usize,
    pub end: usize,
}

pub struct OutputConfig<'a> {
    pub join: bool,
    pub replace_delimiter: Option<&'a str>,
    pub json: bool,
    pub complement: bool,
    pub compress: bool,
    pub fallback_oob: Option<&'a str>,
    pub delimiter: &'a Delimiter<'a>,
    pub delimiter_str: &'a str,
    pub trim: Option<char>,
}

pub fn select_fields(
    line: &str,
    fields: &[String],
    spans: &[FieldSpan],
    spec: &BoundsSpec,
    cfg: &OutputConfig<'_>,
) -> Result<String, i64> {
    let count = fields.len() as i64;

    if spec.is_format {
        return process_format(&spec.raw, fields, count, cfg.delimiter_str);
    }

    if cfg.complement {
        let kept = bounds::complement_selection(&spec.items, count);
        if kept.is_empty() {
            eprintln!("Error: the complement is empty.");
            std::process::exit(1);
        }
        return Ok(complement_output(line, fields, spans, &spec.items, cfg));
    }

    let mut parts = Vec::new();
    for item in &spec.items {
        match render_item(line, fields, spans, item, cfg, count) {
            Ok(part) => parts.push(part),
            Err(oob) => {
                let sep = if cfg.join || cfg.replace_delimiter.is_some() {
                    cfg.replace_delimiter.unwrap_or(cfg.delimiter_str)
                } else {
                    ""
                };
                let partial = if cfg.join || cfg.replace_delimiter.is_some() {
                    parts.join(sep)
                } else {
                    parts.concat()
                };
                if !partial.is_empty() {
                    print!("{partial}");
                }
                eprintln!("Error: Out of bounds: {oob}");
                std::process::exit(1);
            }
        }
    }

    if cfg.json {
        return Ok(format_json(&parts, cfg));
    }

    if cfg.join || cfg.replace_delimiter.is_some() {
        let sep = cfg.replace_delimiter.unwrap_or(cfg.delimiter_str);
        Ok(parts.join(sep))
    } else {
        Ok(parts.concat())
    }
}

fn render_item(
    line: &str,
    fields: &[String],
    spans: &[FieldSpan],
    item: &BoundItem,
    cfg: &OutputConfig<'_>,
    count: i64,
) -> Result<String, i64> {
    match item {
        BoundItem::Single(idx, fb) => {
            if let Some(i) = bounds::resolve_index(*idx, count) {
                Ok(field_text(fields, spans, i, cfg))
            } else if let Some(fb) = fb {
                Ok(fb.clone())
            } else if let Some(fb) = cfg.fallback_oob {
                Ok(fb.to_string())
            } else {
                Err(*idx)
            }
        }
        BoundItem::Range(start, end, fb) => {
            let (s, e) = bounds::resolve_range(*start, *end, count).ok_or_else(|| {
                if bounds::resolve_index(*start, count).is_none() {
                    *start
                } else {
                    *end
                }
            })?;
            if fb.is_some() {
                let mut out = String::new();
                for i in s..=e {
                    if i <= fields.len() {
                        out.push_str(&field_text(fields, spans, i, cfg));
                    } else if let Some(fb) = fb {
                        out.push_str(fb);
                    }
                }
                Ok(out)
            } else if cfg.compress || cfg.replace_delimiter.is_some() {
                let sep = cfg.replace_delimiter.unwrap_or(cfg.delimiter_str);
                let parts: Vec<String> = (s..=e)
                    .map(|i| field_text(fields, spans, i, cfg))
                    .collect();
                Ok(parts.join(sep))
            } else {
                Ok(range_text(line, spans, s, e))
            }
        }
    }
}

fn field_text(fields: &[String], _spans: &[FieldSpan], idx: usize, cfg: &OutputConfig<'_>) -> String {
    fields
        .get(idx - 1)
        .map(|s| trim_field(s, cfg.delimiter, cfg.trim))
        .unwrap_or_default()
}

fn range_text(line: &str, spans: &[FieldSpan], start: usize, end: usize) -> String {
    let start_byte = spans.get(start - 1).map(|s| s.start).unwrap_or(0);
    let end_byte = spans
        .get(end - 1)
        .map(|s| s.end)
        .unwrap_or(line.len());
    line.get(start_byte..end_byte).unwrap_or("").to_string()
}

fn complement_output(
    line: &str,
    fields: &[String],
    spans: &[FieldSpan],
    items: &[BoundItem],
    cfg: &OutputConfig<'_>,
) -> String {
    let count = fields.len() as i64;
    let kept = bounds::complement_selection(items, count);
    if kept.is_empty() {
        return String::new();
    }

    if cfg.join || cfg.replace_delimiter.is_some() {
        let sep = cfg.replace_delimiter.unwrap_or(cfg.delimiter_str);
        let parts: Vec<String> = kept
            .iter()
            .map(|i| field_text(fields, spans, *i, cfg))
            .collect();
        return parts.join(sep);
    }

    let mut out = String::new();
    for (pos, &idx) in kept.iter().enumerate() {
        if pos > 0 {
            let prev = kept[pos - 1];
            if idx == prev + 1 {
                out.push_str(cfg.delimiter_str);
            }
        }
        out.push_str(&field_text(fields, spans, idx, cfg));
    }
    let _ = line;
    let _ = spans;
    out
}

fn format_json(values: &[String], _cfg: &OutputConfig<'_>) -> String {
    format!(
        "[{}]",
        values
            .iter()
            .map(|v| format!("\"{}\"", escape_json(v)))
            .collect::<Vec<_>>()
            .join(",")
    )
}

pub fn select_fields_json(
    line: &str,
    fields: &[String],
    spans: &[FieldSpan],
    spec: &BoundsSpec,
    cfg: &OutputConfig<'_>,
) -> Result<String, i64> {
    let count = fields.len() as i64;
    if spec.is_format {
        return Err(1);
    }
    if let Some(oob) = bounds::first_oob_index(&spec.items, count) {
        return Err(oob);
    }

    let values: Vec<String> = if cfg.complement {
        bounds::complement_selection(&spec.items, count)
            .into_iter()
            .map(|i| field_text(fields, spans, i, cfg))
            .collect()
    } else {
        let mut vals = Vec::new();
        for item in &spec.items {
            match item {
                BoundItem::Single(idx, fb) => {
                    if let Some(i) = bounds::resolve_index(*idx, count) {
                        vals.push(field_text(fields, spans, i, cfg));
                    } else if let Some(fb) = fb {
                        vals.push(fb.clone());
                    } else if let Some(fb) = cfg.fallback_oob {
                        vals.push(fb.to_string());
                    }
                }
                BoundItem::Range(start, end, fb) => {
                    if let Some((s, e)) = bounds::resolve_range(*start, *end, count) {
                        for i in s..=e {
                            if i <= fields.len() {
                                vals.push(field_text(fields, spans, i, cfg));
                            } else if let Some(fb) = fb {
                                vals.push(fb.clone());
                            }
                        }
                    }
                }
            }
        }
        vals
    };
    let _ = line;
    Ok(format_json(&values, cfg))
}

pub fn process_format(
    format: &str,
    fields: &[String],
    count: i64,
    join_delim: &str,
) -> Result<String, i64> {
    let mut out = String::new();
    let chars: Vec<char> = format.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '{' {
            if i + 1 < chars.len() && chars[i + 1] == '{' {
                out.push('{');
                i += 2;
                continue;
            }
            let mut j = i + 1;
            while j < chars.len() && chars[j] != '}' {
                j += 1;
            }
            if j >= chars.len() {
                out.push('{');
                i += 1;
                continue;
            }
            let inner: String = chars[i + 1..j].iter().collect();
            if inner.ends_with(':') {
                let idx_str = inner.trim_end_matches(':');
                let idx: i64 = idx_str.parse().map_err(|_| 0)?;
                let start = bounds::resolve_index(idx, count).ok_or(idx)? as usize;
                out.push_str(&fields[start - 1..].join(join_delim));
            } else {
                let idx: i64 = inner.parse().map_err(|_| 0)?;
                let pos = bounds::resolve_index(idx, count).ok_or(idx)? - 1;
                out.push_str(&fields[pos]);
            }
            i = j + 1;
        } else if chars[i] == '}' {
            if i + 1 < chars.len() && chars[i + 1] == '}' {
                out.push('}');
                i += 2;
                continue;
            }
            out.push('}');
            i += 1;
        } else if chars[i] == '\\' && i + 1 < chars.len() {
            match chars[i + 1] {
                'n' => out.push('\n'),
                't' => out.push('\t'),
                '\\' => out.push('\\'),
                other => {
                    out.push('\\');
                    out.push(other);
                }
            }
            i += 2;
        } else {
            out.push(chars[i]);
            i += 1;
        }
    }
    Ok(out)
}

fn escape_json(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

pub fn compute_spans(line: &str, delimiter: &Delimiter, greedy: bool, compress: bool) -> (Vec<String>, Vec<FieldSpan>) {
    let parts = crate::split::split_fields(line, delimiter, greedy, compress);
    let mut fields = Vec::new();
    let mut spans = Vec::new();
    let mut pos = 0;
    for (i, part) in parts.iter().enumerate() {
        let start = line[pos..].find(part).map(|off| pos + off).unwrap_or(pos);
        let end = start + part.len();
        fields.push(part.to_string());
        spans.push(FieldSpan { start, end });
        pos = end;
        if i + 1 < parts.len() {
            if let Delimiter::Literal(d) = delimiter {
                if greedy {
                    while pos < line.len() && line[pos..].starts_with(d) {
                        pos += d.len().max(1);
                    }
                } else if compress {
                    while pos < line.len() && line[pos..].starts_with(d) {
                        pos += d.len();
                    }
                } else if !d.is_empty() {
                    if line[pos..].starts_with(d) {
                        pos += d.len();
                    }
                }
            } else if let Delimiter::Regex(re) = delimiter {
                if let Some(mat) = re.find(&line[pos..]) {
                    if mat.start() == 0 {
                        pos += mat.end();
                    }
                }
            }
        }
    }
    (fields, spans)
}
