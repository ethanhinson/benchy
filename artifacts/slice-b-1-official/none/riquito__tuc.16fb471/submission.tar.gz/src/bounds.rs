use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BoundItem {
    Single(i64, Option<String>),
    Range(i64, i64, Option<String>),
}

#[derive(Debug, Clone)]
pub struct BoundsSpec {
    pub items: Vec<BoundItem>,
    pub is_format: bool,
    pub raw: String,
}

#[derive(Debug)]
pub enum ParseError {
    NotANumber(String),
    Empty,
    InvalidRange,
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ParseError::NotANumber(s) => write!(f, "Not a number `{s}`"),
            ParseError::Empty => write!(f, "empty bounds"),
            ParseError::InvalidRange => write!(f, "invalid range"),
        }
    }
}

pub fn parse_bounds(raw: &str) -> Result<BoundsSpec, ParseError> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err(ParseError::Empty);
    }

    let is_format = trimmed.contains('{');
    if is_format {
        return Ok(BoundsSpec {
            items: Vec::new(),
            is_format: true,
            raw: raw.to_string(),
        });
    }

    let mut items = Vec::new();
    for part in split_commas(trimmed) {
        items.push(parse_bound_item(part)?);
    }
    if items.is_empty() {
        return Err(ParseError::Empty);
    }

    Ok(BoundsSpec {
        items,
        is_format: false,
        raw: raw.to_string(),
    })
}

fn split_commas(s: &str) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut start = 0;
    for (i, ch) in s.char_indices() {
        if ch == ',' {
            parts.push(&s[start..i]);
            start = i + 1;
        }
    }
    parts.push(&s[start..]);
    parts
}

fn parse_bound_item(part: &str) -> Result<BoundItem, ParseError> {
    let (spec, fallback) = if let Some(eq_pos) = part.rfind('=') {
        (&part[..eq_pos], Some(part[eq_pos + 1..].to_string()))
    } else {
        (part, None)
    };

    if let Some(colon_pos) = spec.find(':') {
        let start_str = spec[..colon_pos].trim();
        let end_str = spec[colon_pos + 1..].trim();

        let start = if start_str.is_empty() {
            1
        } else {
            parse_index(start_str)?
        };
        let end = if end_str.is_empty() {
            i64::MAX
        } else {
            parse_index(end_str)?
        };

        if start > end && end > 0 {
            return Err(ParseError::InvalidRange);
        }

        Ok(BoundItem::Range(start, end, fallback))
    } else {
        Ok(BoundItem::Single(parse_index(spec)?, fallback))
    }
}

fn parse_index(s: &str) -> Result<i64, ParseError> {
    let s = s.trim();
    s.parse::<i64>()
        .map_err(|_| ParseError::NotANumber(s.to_string()))
}

pub fn resolve_range(start: i64, end: i64, count: i64) -> Option<(usize, usize)> {
    let s = resolve_index(start, count)?;
    let e = if end == i64::MAX {
        count as usize
    } else {
        resolve_index(end, count)?
    };
    if s > e {
        None
    } else {
        Some((s, e))
    }
}

pub fn expand_selection(items: &[BoundItem], count: i64) -> Vec<(usize, Option<String>)> {
    let mut selected = Vec::new();
    for item in items {
        match item {
            BoundItem::Single(idx, fb) => {
                if let Some(i) = resolve_index(*idx, count) {
                    selected.push((i, fb.clone()));
                } else if fb.is_some() {
                    selected.push((0, fb.clone()));
                }
            }
            BoundItem::Range(start, end, fb) => {
                if let Some((s, e)) = resolve_range(*start, *end, count) {
                    for i in s..=e {
                        selected.push((i, fb.clone()));
                    }
                }
            }
        }
    }
    selected
}

pub fn complement_selection(
    items: &[BoundItem],
    count: i64,
) -> Vec<usize> {
    let mut excluded = std::collections::BTreeSet::new();
    for item in items {
        match item {
            BoundItem::Single(idx, _) => {
                if let Some(i) = resolve_index(*idx, count) {
                    excluded.insert(i);
                }
            }
            BoundItem::Range(start, end, _) => {
                let s = resolve_index(*start, count).unwrap_or(0);
                let e = if *end == i64::MAX {
                    count as usize
                } else {
                    resolve_index(*end, count).unwrap_or(0)
                };
                if s == 0 || e == 0 {
                    continue;
                }
                for i in s..=e {
                    excluded.insert(i);
                }
            }
        }
    }

    (1..=count as usize)
        .filter(|i| !excluded.contains(i))
        .collect()
}

pub fn resolve_index(idx: i64, count: i64) -> Option<usize> {
    if count <= 0 {
        return None;
    }
    let resolved = if idx > 0 {
        idx
    } else if idx < 0 {
        count + idx + 1
    } else {
        return None;
    };
    if resolved < 1 || resolved > count {
        None
    } else {
        Some(resolved as usize)
    }
}

pub fn first_oob_index(items: &[BoundItem], count: i64) -> Option<i64> {
    for item in items {
        match item {
            BoundItem::Single(idx, fb) => {
                if fb.is_none() && resolve_index(*idx, count).is_none() {
                    return Some(*idx);
                }
            }
            BoundItem::Range(start, end, fb) => {
                if fb.is_some() {
                    continue;
                }
                if resolve_range(*start, *end, count).is_none() {
                    if resolve_index(*start, count).is_none() {
                        return Some(*start);
                    }
                    if *end != i64::MAX && resolve_index(*end, count).is_none() {
                        return Some(*end);
                    }
                }
            }
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_simple_fields() {
        let spec = parse_bounds("1,3:5,-1").unwrap();
        assert_eq!(spec.items.len(), 3);
    }
}
