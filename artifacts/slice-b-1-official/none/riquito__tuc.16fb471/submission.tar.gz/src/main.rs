mod bounds;
mod output;
mod split;

use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::process;

use clap::{ArgGroup, Parser};
use regex::Regex;

use bounds::{parse_bounds, BoundsSpec};
use output::{compute_spans, OutputConfig};
use split::Delimiter;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum CutMode {
    Characters = 0,
    Fields = 1,
    Lines = 2,
    Bytes = 3,
}

#[derive(Parser, Debug)]
#[command(name = "tuc", version = "1.3.0", disable_version_flag = true, disable_help_flag = true)]
#[command(
    about = "Cut text (or bytes) where a delimiter matches, then keep the desired parts."
)]
#[command(group(
    ArgGroup::new("cut_mode")
        .args(["fields", "bytes", "characters", "lines"])
        .multiple(true)
))]
struct Cli {
    #[arg(short = 'g', long = "greedy-delimiter")]
    greedy_delimiter: bool,

    #[arg(short = 'p', long = "compress-delimiter")]
    compress_delimiter: bool,

    #[arg(short = 's', long = "only-delimited")]
    only_delimited: bool,

    #[arg(short = 'V', long = "version")]
    version: bool,

    #[arg(short = 'z', long = "zero-terminated")]
    zero_terminated: bool,

    #[arg(short = 'h', long = "help")]
    help: bool,

    #[arg(short = 'm', long = "complement")]
    complement: bool,

    #[arg(short = 'j', long = "join")]
    join: bool,

    #[arg(long = "no-join")]
    no_join: bool,

    #[arg(long = "json")]
    json: bool,

    #[arg(long = "no-mmap")]
    no_mmap: bool,

    #[arg(short = 'f', long = "fields", allow_hyphen_values = true)]
    fields: Option<String>,

    #[arg(short = 'b', long = "bytes", allow_hyphen_values = true)]
    bytes: Option<String>,

    #[arg(short = 'c', long = "characters", allow_hyphen_values = true)]
    characters: Option<String>,

    #[arg(short = 'l', long = "lines", allow_hyphen_values = true)]
    lines: Option<String>,

    #[arg(short = 'd', long = "delimiter", default_value = "\t", allow_hyphen_values = true)]
    delimiter: String,

    #[arg(short = 'e', long = "regex")]
    regex: Option<String>,

    #[arg(short = 'r', long = "replace-delimiter")]
    replace_delimiter: Option<String>,

    #[arg(short = 't', long = "trim")]
    trim: Option<String>,

    #[arg(long = "fallback-oob")]
    fallback_oob: Option<String>,

    #[arg(short = 'M', long = "fixed-memory")]
    fixed_memory: Option<u64>,

    filepath: Option<PathBuf>,
}

fn main() {
    let cli = Cli::parse();

    if cli.version {
        println!("tuc 1.3.0");
        return;
    }

    if cli.help {
        print_help();
        return;
    }

    let cut_mode = resolve_cut_mode(&cli);
    if cut_mode.is_none() {
        print_welcome();
        return;
    }

    let bounds_raw = bounds_arg(&cli).unwrap();
    let bounds = match parse_bounds(&bounds_raw) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("failed to parse '{bounds_raw}': {e}");
            process::exit(1);
        }
    };

    let trim = cli.trim.as_deref().and_then(|t| t.chars().next());

    let regex = if let Some(ref pattern) = cli.regex {
        match Regex::new(pattern) {
            Ok(re) => Some(re),
            Err(e) => {
                eprintln!("tuc: runtime error. The regular expression is malformed. {e}");
                process::exit(1);
            }
        }
    } else {
        None
    };

    let delimiter_str = if cli.regex.is_some() {
        ""
    } else {
        cli.delimiter.as_str()
    };

    let input = match read_input(&cli.filepath) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("{e}");
            process::exit(1);
        }
    };

    let mut join = cli.join;
    if cli.replace_delimiter.is_some() {
        join = true;
    }
    let lines_implies_join = matches!(cut_mode, Some(CutMode::Lines)) && !cli.no_join;
    if lines_implies_join {
        join = true;
    }
    if cli.no_join {
        join = false;
    }

    let delimiter = if let Some(re) = regex {
        Delimiter::Regex(re)
    } else {
        Delimiter::Literal(delimiter_str)
    };

    let cfg = OutputConfig {
        join,
        replace_delimiter: cli.replace_delimiter.as_deref(),
        json: cli.json,
        complement: cli.complement,
        compress: cli.compress_delimiter,
        fallback_oob: cli.fallback_oob.as_deref(),
        delimiter: &delimiter,
        delimiter_str,
        trim,
    };

    let code = run(
        &input,
        cut_mode.unwrap(),
        &bounds,
        &cfg,
        cli.greedy_delimiter,
        cli.compress_delimiter,
        cli.only_delimited,
        cli.zero_terminated,
        cli.no_join && matches!(cut_mode, Some(CutMode::Lines)),
    );
    if code != 0 {
        process::exit(code);
    }
}

fn resolve_cut_mode(cli: &Cli) -> Option<CutMode> {
    let mut mode = None;
    if cli.characters.is_some() {
        mode = Some(CutMode::Characters);
    }
    if cli.fields.is_some() {
        mode = Some(CutMode::Fields);
    }
    if cli.lines.is_some() {
        mode = Some(CutMode::Lines);
    }
    if cli.bytes.is_some() {
        mode = Some(CutMode::Bytes);
    }
    if mode.is_none() && implicit_fields_mode(cli) {
        mode = Some(CutMode::Fields);
    }
    mode
}

fn implicit_fields_mode(cli: &Cli) -> bool {
    cli.greedy_delimiter
        || cli.compress_delimiter
        || cli.only_delimited
        || cli.complement
        || cli.join
        || cli.no_join
        || cli.json
        || cli.replace_delimiter.is_some()
        || cli.trim.is_some()
        || cli.zero_terminated
        || cli.fixed_memory.is_some()
}

fn bounds_arg(cli: &Cli) -> Option<String> {
    cli.bytes
        .clone()
        .or_else(|| cli.lines.clone())
        .or_else(|| cli.fields.clone())
        .or_else(|| cli.characters.clone())
        .or_else(|| {
            if implicit_fields_mode(cli) || cli.replace_delimiter.is_some() || cli.json {
                Some("1:".to_string())
            } else {
                None
            }
        })
}

fn read_input(path: &Option<PathBuf>) -> Result<String, String> {
    match path {
        Some(p) => fs::read_to_string(p).map_err(|_| {
            format!(
                "tuc: runtime error. The file \"{}\" does not exist",
                p.display()
            )
        }),
        None => {
            let mut buf = String::new();
            io::stdin()
                .read_to_string(&mut buf)
                .map_err(|e| format!("tuc: runtime error. {e}"))?;
            Ok(buf)
        }
    }
}

fn run(
    input: &str,
    mode: CutMode,
    bounds: &BoundsSpec,
    cfg: &OutputConfig<'_>,
    greedy: bool,
    compress: bool,
    only_delimited: bool,
    zero: bool,
    lines_no_join: bool,
) -> i32 {
    let mut stdout = io::stdout().lock();

    match mode {
        CutMode::Bytes => process_bytes(input, bounds, cfg, &mut stdout),
        CutMode::Characters => {
            process_units(input, bounds, cfg, greedy, compress, only_delimited, zero, true, &mut stdout)
        }
        CutMode::Fields => {
            process_units(input, bounds, cfg, greedy, compress, only_delimited, zero, false, &mut stdout)
        }
        CutMode::Lines => process_lines(input, bounds, cfg, zero, lines_no_join, &mut stdout),
    }
}

fn process_bytes(input: &str, bounds: &BoundsSpec, cfg: &OutputConfig<'_>, out: &mut impl Write) -> i32 {
    let bytes = input.as_bytes();
    let count = bytes.len() as i64;

    if bounds.is_format {
        return fail_oob(1);
    }
    if let Some(oob) = bounds::first_oob_index(&bounds.items, count) {
        return fail_oob(oob);
    }

    let selected = if cfg.complement {
        bounds::complement_selection(&bounds.items, count)
            .into_iter()
            .map(|i| (i, None))
            .collect()
    } else {
        bounds::expand_selection(&bounds.items, count)
    };

    let mut result = Vec::new();
    for (idx, fb) in selected {
        if idx == 0 {
            if let Some(text) = fb.or_else(|| cfg.fallback_oob.map(str::to_string)) {
                result.extend_from_slice(text.as_bytes());
            }
        } else if idx <= bytes.len() {
            result.push(bytes[idx - 1]);
        } else if let Some(text) = fb.or_else(|| cfg.fallback_oob.map(str::to_string)) {
            result.extend_from_slice(text.as_bytes());
        }
    }
    let _ = out.write_all(&result);
    0
}

fn process_units(
    input: &str,
    bounds: &BoundsSpec,
    cfg: &OutputConfig<'_>,
    greedy: bool,
    compress: bool,
    only_delimited: bool,
    zero: bool,
    by_char: bool,
    out: &mut impl Write,
) -> i32 {
    let line_sep = if zero { "\0" } else { "\n" };
    let lines = split_input_lines(input, zero);

    for line in lines {
        if only_delimited && !line_contains_delimiter(line, cfg) {
            continue;
        }

        let (fields, spans) = if by_char {
            let mut fields = Vec::new();
            let mut spans = Vec::new();
            let mut pos = 0;
            for ch in line.chars() {
                let len = ch.len_utf8();
                fields.push(ch.to_string());
                spans.push(output::FieldSpan {
                    start: pos,
                    end: pos + len,
                });
                pos += len;
            }
            (fields, spans)
        } else {
            compute_spans(line, cfg.delimiter, greedy, compress)
        };

        let result = if cfg.json {
            output::select_fields_json(line, &fields, &spans, bounds, cfg)
        } else {
            output::select_fields(line, &fields, &spans, bounds, cfg)
        };

        match result {
            Ok(result) => {
                let _ = out.write_all(result.as_bytes());
                let _ = out.write_all(line_sep.as_bytes());
            }
            Err(oob) => return fail_oob(oob),
        }
    }
    0
}

fn process_lines(
    input: &str,
    bounds: &BoundsSpec,
    cfg: &OutputConfig<'_>,
    zero: bool,
    no_join: bool,
    out: &mut impl Write,
) -> i32 {
    let lines: Vec<String> = split_input_lines(input, zero)
        .into_iter()
        .map(str::to_string)
        .collect();
    let count = lines.len() as i64;

    if bounds.is_format {
        return fail_oob(1);
    }
    if let Some(oob) = lines_oob(bounds, count) {
        return fail_oob(oob);
    }

    let selected: Vec<(usize, Option<String>)> = if bounds.items.len() == 1 {
        if let bounds::BoundItem::Single(-1, fb) = &bounds.items[0] {
            (1..=count as usize).map(|i| (i, fb.clone())).collect()
        } else if cfg.complement {
            bounds::complement_selection(&bounds.items, count)
                .into_iter()
                .map(|i| (i, None))
                .collect()
        } else {
            bounds::expand_selection(&bounds.items, count)
        }
    } else if cfg.complement {
        bounds::complement_selection(&bounds.items, count)
            .into_iter()
            .map(|i| (i, None))
            .collect()
    } else {
        bounds::expand_selection(&bounds.items, count)
    };

    if cfg.json {
        let values: Vec<String> = selected
            .iter()
            .map(|(idx, fb)| {
                lines
                    .get(idx - 1)
                    .cloned()
                    .or_else(|| fb.clone())
                    .or_else(|| cfg.fallback_oob.map(str::to_string))
                    .unwrap_or_default()
            })
            .collect();
        let json = format!(
            "[{}]",
            values
                .iter()
                .map(|v| format!("\"{}\"", v.replace('\\', "\\\\").replace('"', "\\\"")))
                .collect::<Vec<_>>()
                .join(",")
        );
        let _ = out.write_all(json.as_bytes());
        let _ = out.write_all(b"\n");
        return 0;
    }

    let line_sep = if zero { "\0" } else { "\n" };
    let join_sep = cfg.replace_delimiter.unwrap_or(line_sep);

    if no_join {
        let mut merged = String::new();
        for (idx, _) in &selected {
            if let Some(line) = lines.get(idx - 1) {
                merged.push_str(line);
            }
        }
        let _ = out.write_all(merged.as_bytes());
        let _ = out.write_all(b"\n");
    } else if cfg.join || cfg.replace_delimiter.is_some() {
        let parts: Vec<&str> = selected
            .iter()
            .filter_map(|(idx, _)| lines.get(idx - 1).map(String::as_str))
            .collect();
        let joined = parts.join(join_sep);
        let _ = out.write_all(joined.as_bytes());
        let _ = out.write_all(b"\n");
    } else {
        for (idx, _) in &selected {
            if let Some(line) = lines.get(idx - 1) {
                let _ = out.write_all(line.as_bytes());
                let _ = out.write_all(line_sep.as_bytes());
            }
        }
    }
    0
}

fn lines_oob(spec: &BoundsSpec, count: i64) -> Option<i64> {
    for item in &spec.items {
        match item {
            bounds::BoundItem::Range(start, end, fb) if fb.is_none() => {
                if spec.items.len() == 1 && *start == 1 && *end == -1 {
                    continue;
                }
                if *end < 0 {
                    if *start > 0 && *end == -1 && *start != 1 {
                        return Some(*start);
                    }
                    if *start >= 1 && bounds::resolve_index(*start, count).is_none() {
                        return Some(*start);
                    }
                    if *start == 1 && *end == -1 {
                        continue;
                    }
                    return Some(if *start > 0 { *start } else { *end });
                }
                if *start < 0 {
                    return Some(*start);
                }
            }
            bounds::BoundItem::Single(idx, fb) if fb.is_none() && *idx < 0 && *idx != -1 => {
                return Some(*idx);
            }
            _ => {}
        }
    }
    bounds::first_oob_index(&spec.items, count)
}

fn line_contains_delimiter(line: &str, cfg: &OutputConfig<'_>) -> bool {
    match cfg.delimiter {
        Delimiter::Literal(d) => line.contains(d),
        Delimiter::Regex(re) => re.is_match(line),
    }
}

fn split_input_lines(input: &str, zero: bool) -> Vec<&str> {
    if zero {
        if input.is_empty() {
            Vec::new()
        } else {
            input.split('\0').collect()
        }
    } else if input.is_empty() {
        Vec::new()
    } else {
        let mut lines: Vec<&str> = input.split('\n').collect();
        if input.ends_with('\n') {
            lines.pop();
        }
        lines
    }
}

fn fail_oob(idx: i64) -> i32 {
    eprintln!("Error: Out of bounds: {idx}");
    1
}

fn print_welcome() {
    print!(
        "\
tuc 1.3.0 - Created by Riccardo Attilio Galli

Cut text (or bytes) where a delimiter matches, then keep the desired parts.

Some examples:

    $ echo \"a/b/c\" | tuc -d / -f 1,-1
    ac

    $ echo \"a/b/c\" | tuc -d / -f 2:
    b/c

    $ echo \"hello.bak\" | tuc -d . -f 'mv {{1:}} {{1}}'
    mv hello.bak hello

    $ printf \"a\\nb\\nc\\nd\\ne\" | tuc -l 2:-2
    b
    c
    d

Run `tuc --help` for more detailed information.
Send bug reports to: https://github.com/riquito/tuc/issues
"
    );
}

fn print_help() {
    print!(
        "\
tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
                                  Use colon (:) to match a range (inclusive).
                                  Use equal (=) to apply out of bound fallback.
                                  Fields can be negative (-1 is the last field).
                                  [default: 1:]

                                  e.g. cutting the string 'a-b-c-d' on '-'
                                    -f 1     => a
                                    -f 1:    => a-b-c-d
                                    -f 1:3   => a-b-c
                                    -f 3,2   => cb
                                    -f 3,1:2 => ca-b
                                    -f -3:-2 => b-c
                                    -f 1,8=fallback => afallback

                                  To re-apply the delimiter add -j, to replace
                                  it add -r (followed by the new delimiter).

                                  You can also format the output using {{}} syntax
                                  e.g.
                                    -f '({{1}}, {{2}})' => (a, b)

                                  You can escape {{ and }} using {{{{ and }}}}.

    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
                                  Implies --join. To merge lines, use --no-join
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \\t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
                                  Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
                                  It's overridden by any fallback assigned to a
                                  specific field (see -f for help)
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
                                  This allows to read lines arbitrarily large.
                                  Works only with single-byte delimiters,
                                  fields in ascending order, -z, -j, -r

Options precedence:
    --trim and --compress-delimiter are applied before --fields or similar

Memory consumption:
    --characters and --fields read and allocate memory one line at a time

    --lines allocate memory one line at a time as long as the requested fields
    are ordered and non-negative (e.g. -l 1,3:4,4,7), otherwise it allocates
    the whole input in memory (it also happens when -p or -m are being used)

    --bytes allocate the whole input in memory

    --fixed-memory will read the input in chunks of <size> kilobytes. This
    allows to read lines arbitrarily large. Works only with single-byte
    delimiters, fields in ascending order, -z, -j, -r

Colors:
    Help is displayed using colors. Colors will be suppressed in the
    following circumstances:
    - when the TERM environment variable is not set or set to \"dumb\"
    - when the NO_COLOR environment variable is set (regardless of value)
"
    );
}
