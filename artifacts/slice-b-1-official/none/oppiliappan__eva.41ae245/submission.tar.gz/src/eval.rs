use crate::error::EvaError;
use crate::preprocess;

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum PreviousAnswer {
    CommandMode,
    Repl { available: bool },
}

#[derive(Debug, Clone)]
enum Token {
    Number(f64),
    Constant(&'static str),
    PreviousAnswer,
    Function { name: String, argc: usize },
    UnaryMinus,
    Plus,
    Minus,
    Star,
    Slash,
    Caret,
    LeftParen,
    RightParen,
    Comma,
}

pub fn evaluate_expression(
    input: &str,
    config: &crate::Config,
    previous: PreviousAnswer,
    previous_value: f64,
) -> Result<f64, EvaError> {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return Ok(0.0);
    }

    let balanced = preprocess::balance_parentheses(trimmed).map_err(|_| {
        EvaError::syntax("Mismatched parentheses!")
    })?;
    let prepared = preprocess::insert_implicit_multiplication(&balanced);
    let tokens = tokenize(&prepared, previous)?;
    let rpn = to_rpn(tokens)?;
    evaluate_rpn(&rpn, config, previous_value)
}

fn tokenize(input: &str, previous: PreviousAnswer) -> Result<Vec<Token>, EvaError> {
    let chars: Vec<char> = input.chars().collect();
    let mut tokens = Vec::new();
    let mut index = 0;

    while index < chars.len() {
        let ch = chars[index];

        if ch.is_ascii_whitespace() {
            index += 1;
            continue;
        }

        if ch.is_ascii_digit() || (ch == '.' && next_is_digit(&chars, index + 1)) {
            let start = index;
            index += 1;
            while index < chars.len()
                && (chars[index].is_ascii_digit() || chars[index] == '.')
            {
                index += 1;
            }
            let literal: String = chars[start..index].iter().collect();
            let value = literal
                .parse::<f64>()
                .map_err(|_| EvaError::syntax(format!("Invalid number '{literal}'")))?;
            tokens.push(Token::Number(value));
            continue;
        }

        if ch.is_ascii_alphabetic() || ch == '_' {
            if ch == '_' && !is_ident_part(chars.get(index + 1).copied()) {
                match previous {
                    PreviousAnswer::CommandMode => tokens.push(Token::Number(0.0)),
                    PreviousAnswer::Repl { available: true } => {
                        tokens.push(Token::PreviousAnswer)
                    }
                    PreviousAnswer::Repl { available: false } => {
                        return Err(EvaError::syntax("No previous answer!"));
                    }
                }
                index += 1;
                continue;
            }

            let start = index;
            index += 1;
            while index < chars.len() && is_ident_part(Some(chars[index])) {
                index += 1;
            }
            let ident: String = chars[start..index].iter().collect();
            match ident.as_str() {
                "pi" => tokens.push(Token::Constant("pi")),
                "e" => tokens.push(Token::Constant("e")),
                _ => {
                    let argc = function_argc(&ident).ok_or_else(|| {
                        EvaError::syntax(format!("Unknown function '{ident}'"))
                    })?;
                    tokens.push(Token::Function {
                        name: ident,
                        argc,
                    });
                }
            }
            continue;
        }

        match ch {
            '+' => tokens.push(Token::Plus),
            '-' => tokens.push(Token::Minus),
            '*' if next_is_star(&chars, index) => {
                tokens.push(Token::Caret);
                index += 1;
            }
            '*' => tokens.push(Token::Star),
            '/' => tokens.push(Token::Slash),
            '^' => tokens.push(Token::Caret),
            '(' => tokens.push(Token::LeftParen),
            ')' => tokens.push(Token::RightParen),
            ',' => tokens.push(Token::Comma),
            _ => return Err(EvaError::syntax(format!("Unexpected character '{ch}'"))),
        }
        index += 1;
    }

    Ok(tokens)
}

fn next_is_digit(chars: &[char], index: usize) -> bool {
    chars.get(index).is_some_and(|ch| ch.is_ascii_digit())
}

fn next_is_star(chars: &[char], index: usize) -> bool {
    chars.get(index + 1).is_some_and(|&ch| ch == '*')
}

fn is_ident_part(ch: Option<char>) -> bool {
    matches!(ch, Some(c) if c.is_ascii_alphanumeric() || c == '_')
}

fn function_argc(name: &str) -> Option<usize> {
    match name {
        "sin" | "cos" | "tan" | "csc" | "sec" | "cot" | "sinh" | "cosh" | "tanh" | "asin"
        | "acos" | "atan" | "acsc" | "asec" | "acot" | "ln" | "log2" | "log10" | "sqrt"
        | "ceil" | "floor" | "abs" | "deg" | "rad" => Some(1),
        "log" | "nroot" => Some(2),
        _ => None,
    }
}

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
enum Precedence {
    Add = 2,
    Mul = 3,
    Pow = 4,
    Unary = 5,
}

fn to_rpn(tokens: Vec<Token>) -> Result<Vec<Token>, EvaError> {
    let mut output = Vec::new();
    let mut operators: Vec<(Token, Precedence, bool)> = Vec::new();
    let mut expect_operand = true;
    let mut arg_stack: Vec<usize> = Vec::new();

    for token in tokens {
        match token {
            Token::Number(_)
            | Token::Constant(_)
            | Token::PreviousAnswer => {
                if !expect_operand {
                    return Err(EvaError::parser(
                        "Too many operands, too few operators",
                    ));
                }
                output.push(token);
                flush_unary_operators(&mut output, &mut operators);
                expect_operand = false;
            }
            Token::Function { name, argc } => {
                if !expect_operand {
                    return Err(EvaError::parser(
                        "Too many operands, too few operators",
                    ));
                }
                operators.push((
                    Token::Function {
                        name: name.clone(),
                        argc,
                    },
                    Precedence::Unary,
                    false,
                ));
                arg_stack.push(1);
                expect_operand = true;
            }
            Token::Plus if expect_operand => {
                expect_operand = true;
            }
            Token::Minus if expect_operand => {
                push_operator(
                    &mut output,
                    &mut operators,
                    Token::UnaryMinus,
                    Precedence::Unary,
                    true,
                )?;
                expect_operand = true;
            }
            Token::Plus => {
                push_operator(&mut output, &mut operators, Token::Plus, Precedence::Add, false)?;
                expect_operand = true;
            }
            Token::Minus => {
                push_operator(&mut output, &mut operators, Token::Minus, Precedence::Add, false)?;
                expect_operand = true;
            }
            Token::Star => {
                push_operator(&mut output, &mut operators, Token::Star, Precedence::Mul, false)?;
                expect_operand = true;
            }
            Token::Slash => {
                push_operator(&mut output, &mut operators, Token::Slash, Precedence::Mul, false)?;
                expect_operand = true;
            }
            Token::Caret => {
                push_operator(&mut output, &mut operators, Token::Caret, Precedence::Pow, true)?;
                expect_operand = true;
            }
            Token::Comma => {
                while let Some((top, _, _)) = operators.last() {
                    if matches!(top, Token::LeftParen) {
                        break;
                    }
                    output.push(operators.pop().unwrap().0);
                }
                if let Some(count) = arg_stack.last_mut() {
                    *count += 1;
                }
                expect_operand = true;
            }
            Token::LeftParen => {
                if !expect_operand {
                    return Err(EvaError::parser(
                        "Too many operands, too few operators",
                    ));
                }
                operators.push((Token::LeftParen, Precedence::Add, false));
                expect_operand = true;
            }
            Token::RightParen => {
                while let Some((top, _, _)) = operators.last() {
                    if matches!(top, Token::LeftParen) {
                        break;
                    }
                    output.push(operators.pop().unwrap().0);
                }

                if operators.pop().is_none() {
                    return Err(EvaError::parser(
                        "Too many operators, too few operands",
                    ));
                }

                if let Some((Token::Function { name, argc }, _, _)) = operators.last().cloned() {
                    if expect_operand {
                        return Err(EvaError::parser(format!(
                            "To few arguments for function, need {argc}"
                        )));
                    }
                    let supplied = arg_stack.pop().unwrap_or(1);
                    if supplied < argc {
                        return Err(EvaError::parser(format!(
                            "To few arguments for function, need {argc}"
                        )));
                    }
                    if supplied > argc {
                        return Err(EvaError::parser(format!(
                            "Too many arguments for function, need {argc}"
                        )));
                    }
                    output.push(operators.pop().unwrap().0);
                    let _ = name;
                }

                expect_operand = false;
                flush_unary_operators(&mut output, &mut operators);
            }
            Token::UnaryMinus => unreachable!(),
        }
    }

    if expect_operand && !output.is_empty() {
        return Err(EvaError::parser(
            "Too many operators, too few operands",
        ));
    }

    while let Some((op, _, _)) = operators.pop() {
        if matches!(op, Token::LeftParen) {
            return Err(EvaError::parser(
                "Too many operators, too few operands",
            ));
        }
        output.push(op);
    }

    if output.is_empty() {
        return Err(EvaError::parser(
            "Too many operators, too few operands",
        ));
    }

    Ok(output)
}

fn flush_unary_operators(
    output: &mut Vec<Token>,
    operators: &mut Vec<(Token, Precedence, bool)>,
) {
    while matches!(operators.last().map(|(token, _, _)| token), Some(Token::UnaryMinus)) {
        output.push(operators.pop().unwrap().0);
    }
}

fn push_operator(
    output: &mut Vec<Token>,
    operators: &mut Vec<(Token, Precedence, bool)>,
    operator: Token,
    precedence: Precedence,
    right_associative: bool,
) -> Result<(), EvaError> {
    while let Some((top, top_prec, top_right)) = operators.last().cloned() {
        if matches!(top, Token::LeftParen | Token::Function { .. }) {
            break;
        }

        let pop = if right_associative {
            top_prec > precedence
        } else {
            top_prec >= precedence
        };

        if pop {
            output.push(operators.pop().unwrap().0);
        } else {
            break;
        }

        let _ = top_right;
    }

    operators.push((operator, precedence, right_associative));
    Ok(())
}

fn evaluate_rpn(
    rpn: &[Token],
    config: &crate::Config,
    previous_value: f64,
) -> Result<f64, EvaError> {
    let mut stack: Vec<f64> = Vec::new();

    for token in rpn {
        match token {
            Token::Number(value) => stack.push(*value),
            Token::Constant(name) => stack.push(match *name {
                "pi" => std::f64::consts::PI,
                "e" => std::f64::consts::E,
                _ => unreachable!(),
            }),
            Token::PreviousAnswer => stack.push(previous_value),
            Token::UnaryMinus => unary_op(&mut stack, |value| -value)?,
            Token::Function { name, argc } => {
                if stack.len() < *argc {
                    return Err(EvaError::parser(
                        "Too many operators, too few operands",
                    ));
                }
                let args: Vec<f64> = stack.split_off(stack.len() - *argc);
                stack.push(apply_function(name, &args, config)?);
            }
            Token::Plus => binary_op(&mut stack, |a, b| Ok(a + b))?,
            Token::Minus => binary_op(&mut stack, |a, b| Ok(a - b))?,
            Token::Star => binary_op(&mut stack, |a, b| Ok(a * b))?,
            Token::Slash => binary_op(&mut stack, |a, b| {
                if b == 0.0 {
                    Err(EvaError::math("Divide by zero error!"))
                } else {
                    Ok(a / b)
                }
            })?,
            Token::Caret => binary_op(&mut stack, |a, b| Ok(a.powf(b)))?,
            Token::LeftParen | Token::RightParen | Token::Comma => unreachable!(),
        }
    }

    if stack.len() != 1 {
        return Err(EvaError::parser(
            "Too many operators, too few operands",
        ));
    }

    Ok(stack[0])
}

fn unary_op<F>(stack: &mut Vec<f64>, op: F) -> Result<(), EvaError>
where
    F: FnOnce(f64) -> f64,
{
    if stack.is_empty() {
        return Err(EvaError::parser(
            "Too many operators, too few operands",
        ));
    }
    let value = stack.pop().unwrap();
    stack.push(op(value));
    Ok(())
}

fn binary_op<F>(stack: &mut Vec<f64>, op: F) -> Result<(), EvaError>
where
    F: FnOnce(f64, f64) -> Result<f64, EvaError>,
{
    if stack.len() < 2 {
        return Err(EvaError::parser(
            "Too many operators, too few operands",
        ));
    }
    let rhs = stack.pop().unwrap();
    let lhs = stack.pop().unwrap();
    stack.push(op(lhs, rhs)?);
    Ok(())
}

fn apply_function(name: &str, args: &[f64], config: &crate::Config) -> Result<f64, EvaError> {
    let value = args[0];
    match name {
        "sin" => trig(value, config, f64::sin),
        "cos" => trig(value, config, f64::cos),
        "tan" => trig(value, config, f64::tan),
        "csc" => {
            let result = trig(value, config, f64::sin)?;
            if result == 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(1.0 / result)
            }
        }
        "sec" => {
            let result = trig(value, config, f64::cos)?;
            Ok(1.0 / result)
        }
        "cot" => {
            let result = trig(value, config, f64::tan)?;
            if result == 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(1.0 / result)
            }
        }
        "sinh" => Ok(value.sinh()),
        "cosh" => Ok(value.cosh()),
        "tanh" => Ok(value.tanh()),
        "asin" => Ok(args[0].asin()),
        "acos" => Ok(args[0].acos()),
        "atan" => Ok(args[0].atan()),
        "acsc" => {
            if args[0] == 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok((1.0 / args[0]).asin())
            }
        }
        "asec" => Ok((1.0 / args[0]).acos()),
        "acot" => Ok((1.0 / args[0]).atan()),
        "ln" => {
            if value <= 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(value.ln())
            }
        }
        "log2" => {
            if value <= 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(value.log2())
            }
        }
        "log10" => {
            if value <= 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(value.log10())
            }
        }
        "sqrt" => {
            if value < 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(value.sqrt())
            }
        }
        "ceil" => Ok(value.ceil()),
        "floor" => Ok(value.floor()),
        "abs" => Ok(value.abs()),
        "deg" => Ok(value.to_degrees()),
        "rad" => Ok(value.to_radians()),
        "log" => {
            let number = args[0];
            let base = args[1];
            if number <= 0.0 || base <= 0.0 || base == 1.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(number.log(base))
            }
        }
        "nroot" => {
            let number = args[0];
            let root = args[1];
            if root == 0.0 {
                Err(EvaError::domain("Out of bounds!"))
            } else {
                Ok(number.powf(1.0 / root))
            }
        }
        _ => Err(EvaError::syntax(format!("Unknown function '{name}'"))),
    }
}

fn trig(value: f64, config: &crate::Config, f: fn(f64) -> f64) -> Result<f64, EvaError> {
    let radians = match config.angle_unit {
        crate::AngleUnit::Degree | crate::AngleUnit::Gradian => value.to_radians(),
        crate::AngleUnit::Radian => value,
    };
    Ok(f(radians))
}
