use directories::ProjectDirs;

pub fn history_file() -> Option<std::path::PathBuf> {
    ProjectDirs::from("com", "NerdyPepper", "eva")
        .map(|dirs| dirs.data_dir().join("history.txt"))
}

pub fn previous_answer_file() -> Option<std::path::PathBuf> {
    ProjectDirs::from("com", "NerdyPepper", "eva").map(|dirs| {
        dirs.cache_dir().join("previous_ans.txt")
    })
}
