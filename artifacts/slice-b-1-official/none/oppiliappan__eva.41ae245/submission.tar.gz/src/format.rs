use crate::Config;

const DIGITS: &[char; 36] = &[
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
    'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
];

pub fn format_output(value: f64, config: &Config) -> String {
    if config.base == 10 {
        format_decimal(value, config.fix)
    } else {
        format_radix(value, config.base)
    }
}

fn format_decimal(value: f64, fix: u8) -> String {
    let rounded = round_to(value, fix as i32);
    let negative = rounded.is_sign_negative();
    let abs = rounded.abs();

    let multiplier = 10f64.powi(fix as i32);
    let scaled = (abs * multiplier).round();
    let whole = (scaled / multiplier).floor();
    let fraction = scaled - whole * multiplier;

    let whole_str = group_integer(whole as u64);
    let frac_str = format!("{:0width$}", fraction as u64, width = fix as usize);

    if fix == 0 {
        unreachable!("fix validated to be >= 1");
    }

    if negative {
        format!("-{whole_str}.{frac_str}")
    } else {
        format!("{whole_str}.{frac_str}")
    }
}

fn group_integer(value: u64) -> String {
    let digits = value.to_string();
    if digits.len() <= 3 {
        return digits;
    }

    let mut groups = Vec::new();
    let chars: Vec<char> = digits.chars().collect();
    let mut index = chars.len();
    while index > 0 {
        let start = index.saturating_sub(3);
        groups.push(chars[start..index].iter().collect::<String>());
        index = start;
    }
    groups.reverse();
    groups.join(",")
}

fn format_radix(value: f64, base: u8) -> String {
    let negative = value.is_sign_negative();
    let abs = value.abs();
    let integer = abs.floor();
    let fraction = abs - integer;

    let int_str = convert_integer(integer as u128, base);
    let frac_digit = convert_fraction_digit(fraction, base);
    let grouped = group_radix(&int_str, &frac_digit);

    if negative {
        // Observed outputs are always non-negative in tests; keep sign if needed.
        format!("-{grouped}")
    } else {
        grouped
    }
}

fn convert_integer(mut value: u128, base: u8) -> String {
    if value == 0 {
        return "0".to_string();
    }

    let mut digits = Vec::new();
    let radix = base as u128;
    while value > 0 {
        let rem = (value % radix) as usize;
        digits.push(DIGITS[rem]);
        value /= radix;
    }
    digits.into_iter().rev().collect()
}

fn convert_fraction_digit(fraction: f64, base: u8) -> char {
    let scaled = (fraction * base as f64).floor() as usize;
    DIGITS[scaled.min(35)]
}

fn group_radix(integer: &str, frac_digit: &char) -> String {
    let mut groups = Vec::new();
    let chars: Vec<char> = integer.chars().collect();
    let mut index = chars.len();
    while index > 0 {
        let start = index.saturating_sub(3);
        groups.push(chars[start..index].iter().collect::<String>());
        index = start;
    }
    groups.reverse();

    if groups.is_empty() {
        groups.push("0".to_string());
    }

    if let Some(last) = groups.last_mut() {
        last.push('.');
        last.push(*frac_digit);
    }

    if groups.len() <= 3 {
        while groups.len() < 4 {
            groups.insert(0, String::new());
        }

        let mut out = [' '; 15];
        out[1] = ',';
        out[5] = ',';
        out[9] = ',';
        place_segment(&mut out, 10, &groups[3]);
        place_segment(&mut out, 6, &groups[2]);
        place_segment(&mut out, 2, &groups[1]);
        place_segment(&mut out, 0, &groups[0]);
        out.iter().collect()
    } else {
        groups.join(",")
    }
}

fn place_segment(buffer: &mut [char; 15], start: usize, text: &str) {
    let width = if start == 10 { 5 } else if start == 0 { 1 } else { 3 };
    let chars: Vec<char> = text.chars().collect();
    let len = chars.len().min(width);
    let offset = start + width - len;
    for (index, ch) in chars.iter().take(len).enumerate() {
        buffer[offset + index] = *ch;
    }
}

fn round_to(value: f64, places: i32) -> f64 {
    let multiplier = 10f64.powi(places);
    (value * multiplier).round() / multiplier
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::AngleUnit;

    fn config(fix: u8, base: u8) -> Config {
        Config {
            fix,
            base,
            angle_unit: AngleUnit::Degree,
            input: None,
        }
    }

    #[test]
    fn decimal_formatting() {
        assert_eq!(format_output(1.0, &config(10, 10)), "1.0000000000");
        assert_eq!(format_output(1000.0, &config(10, 10)), "1,000.0000000000");
    }

    #[test]
    fn hex_small_values() {
        assert_eq!(format_output(255.0, &config(10, 16)), " ,   ,   , FF.0");
    }
}
