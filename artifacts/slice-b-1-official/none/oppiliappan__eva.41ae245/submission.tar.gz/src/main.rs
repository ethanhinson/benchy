use clap::Parser;
use eva::{run, Config};
use std::process::ExitCode;

fn main() -> ExitCode {
    run(Config::parse())
}
