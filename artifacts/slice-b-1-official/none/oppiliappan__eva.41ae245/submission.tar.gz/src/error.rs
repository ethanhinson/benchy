use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum EvaError {
    Domain(String),
    Math(String),
    Syntax(String),
    Parser(String),
}

impl EvaError {
    pub fn domain(message: impl Into<String>) -> Self {
        Self::Domain(message.into())
    }

    pub fn math(message: impl Into<String>) -> Self {
        Self::Math(message.into())
    }

    pub fn syntax(message: impl Into<String>) -> Self {
        Self::Syntax(message.into())
    }

    pub fn parser(message: impl Into<String>) -> Self {
        Self::Parser(message.into())
    }
}

impl fmt::Display for EvaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Domain(message) => write!(f, "Domain Error: {message}"),
            Self::Math(message) => write!(f, "Math Error: {message}"),
            Self::Syntax(message) => write!(f, "Syntax Error: {message}"),
            Self::Parser(message) => write!(f, "Parser Error: {message}"),
        }
    }
}

impl std::error::Error for EvaError {}
