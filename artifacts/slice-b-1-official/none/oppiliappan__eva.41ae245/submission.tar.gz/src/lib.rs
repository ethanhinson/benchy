pub mod error;
pub mod eval;
pub mod format;
pub mod paths;
pub mod preprocess;
pub mod repl;

pub use error::EvaError;

use clap::{Parser, ValueEnum};
use std::process::ExitCode;

#[derive(Clone, Copy, Debug, ValueEnum, PartialEq, Eq)]
pub enum AngleUnit {
    Degree,
    Radian,
    Gradian,
}

#[derive(Parser, Debug)]
#[command(
    name = "eva",
    version = "0.3.1",
    about = "Calculator REPL similar to bc(1)"
)]
pub struct Config {
    #[arg(short = 'f', long = "fix", default_value_t = 10)]
    pub fix: u8,

    #[arg(short = 'b', long = "base", default_value_t = 10)]
    pub base: u8,

    #[arg(short = 'a', long = "angle_unit", default_value = "degree")]
    pub angle_unit: AngleUnit,

    pub input: Option<String>,
}

impl Config {
    pub fn validate(&self) -> Result<(), String> {
        if !(1..=64).contains(&self.fix) {
            return Err(format!(
                "invalid value '{}' for '--fix <FIX>': {} is not in 1..=64",
                self.fix, self.fix
            ));
        }
        if !(1..=36).contains(&self.base) {
            return Err(format!(
                "invalid value '{}' for '--base <RADIX>': {} is not in 1..=36",
                self.base, self.base
            ));
        }
        Ok(())
    }
}

pub fn run(config: Config) -> ExitCode {
    if let Err(message) = config.validate() {
        eprintln!("error: {message}");
        eprintln!();
        eprintln!("For more information, try '--help'.");
        return ExitCode::from(2);
    }

    if let Some(ref input) = config.input {
        match eval::evaluate_expression(input, &config, eval::PreviousAnswer::CommandMode, 0.0) {
            Ok(value) => {
                println!("{}", format::format_output(value, &config));
                ExitCode::SUCCESS
            }
            Err(err) => {
                eprintln!("{err}");
                ExitCode::from(1)
            }
        }
    } else {
        repl::run_repl(&config);
        ExitCode::SUCCESS
    }
}
