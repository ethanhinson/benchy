use crate::eval::{self, PreviousAnswer};
use crate::paths;
use crate::Config;
use rustyline::error::ReadlineError;
use rustyline::{DefaultEditor, Result as RustyResult};
use std::fs;
use std::io::{self, Write};

pub fn run_repl(config: &Config) {
    let mut previous = load_previous_answer();
    let mut has_previous = false;

    let mut editor = match create_editor() {
        Ok(editor) => Some(editor),
        Err(_) => None,
    };

    if let Some(editor) = editor.as_mut() {
        if editor.load_history(&history_path()).is_err() {
            println!("No previous history.");
        }
    } else if !history_path().exists() {
        println!("No previous history.");
    }

    loop {
        let line = match read_line(editor.as_mut()) {
            Ok(Some(line)) => line,
            Ok(None) => break,
            Err(_) => break,
        };

        if let Some(editor) = editor.as_mut() {
            let _ = editor.add_history_entry(line.as_str());
        }

        match eval::evaluate_expression(
            &line,
            config,
            PreviousAnswer::Repl {
                available: has_previous,
            },
            previous,
        ) {
            Ok(value) => {
                println!("{}", crate::format::format_output(value, config));
                previous = value;
                has_previous = true;
                save_previous_answer(previous);
            }
            Err(err) => {
                eprintln!("{err}");
            }
        }
    }

    if let Some(mut editor) = editor {
        let _ = editor.save_history(&history_path());
    }
}

fn create_editor() -> RustyResult<DefaultEditor> {
    DefaultEditor::new()
}

fn read_line(editor: Option<&mut DefaultEditor>) -> io::Result<Option<String>> {
    if let Some(editor) = editor {
        match editor.readline("> ") {
            Ok(line) => Ok(Some(line)),
            Err(ReadlineError::Eof) => Ok(None),
            Err(ReadlineError::Interrupted) => Ok(None),
            Err(err) => Err(io::Error::other(err)),
        }
    } else {
        print!("> ");
        io::stdout().flush()?;
        let mut line = String::new();
        match io::stdin().read_line(&mut line) {
            Ok(0) => Ok(None),
            Ok(_) => Ok(Some(line)),
            Err(err) => Err(err),
        }
    }
}

fn history_path() -> std::path::PathBuf {
    paths::history_file().unwrap_or_else(|| std::path::PathBuf::from("history.txt"))
}

fn load_previous_answer() -> f64 {
    paths::previous_answer_file()
        .and_then(|path| fs::read_to_string(path).ok())
        .and_then(|content| content.trim().parse().ok())
        .unwrap_or(0.0)
}

fn save_previous_answer(value: f64) {
    if let Some(path) = paths::previous_answer_file() {
        if let Some(parent) = path.parent() {
            let _ = fs::create_dir_all(parent);
        }
        let _ = fs::write(path, format!("{value}"));
    }
}
