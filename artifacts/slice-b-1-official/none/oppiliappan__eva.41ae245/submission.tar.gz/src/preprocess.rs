const FUNCTIONS: &[&str] = &[
    "sin", "cos", "tan", "csc", "sec", "cot", "sinh", "cosh", "tanh", "asin", "acos", "atan",
    "acsc", "asec", "acot", "ln", "log2", "log10", "sqrt", "ceil", "floor", "abs", "deg", "rad",
    "log", "nroot",
];

const CONSTANTS: &[&str] = &["pi", "e"];

pub fn balance_parentheses(input: &str) -> Result<String, ()> {
    let mut depth = 0i32;
    for ch in input.chars() {
        match ch {
            '(' => depth += 1,
            ')' => {
                depth -= 1;
                if depth < 0 {
                    return Err(());
                }
            }
            _ => {}
        }
    }

    let mut balanced = input.to_string();
    while depth > 0 {
        balanced.push(')');
        depth -= 1;
    }
    Ok(balanced)
}

pub fn insert_implicit_multiplication(input: &str) -> String {
    let atoms = split_atoms(input);
    let mut output = String::new();

    for (index, atom) in atoms.iter().enumerate() {
        if index > 0 && needs_mult(&atoms[index - 1], atom) {
            output.push('*');
        }
        output.push_str(atom);
    }

    output
}

fn split_atoms(input: &str) -> Vec<String> {
    let chars: Vec<char> = input.chars().collect();
    let mut atoms = Vec::new();
    let mut index = 0;

    while index < chars.len() {
        let ch = chars[index];
        if ch.is_ascii_whitespace() {
            index += 1;
            continue;
        }

        if ch.is_ascii_digit() || (ch == '.' && is_digit_at(&chars, index + 1)) {
            let start = index;
            index += 1;
            while index < chars.len()
                && (chars[index].is_ascii_digit() || chars[index] == '.')
            {
                index += 1;
            }
            atoms.push(chars[start..index].iter().collect());
            continue;
        }

        if ch.is_ascii_alphabetic() || ch == '_' {
            let start = index;
            index += 1;
            while index < chars.len() && is_ident_part(chars[index]) {
                index += 1;
            }
            let ident: String = chars[start..index].iter().collect();
            if let Some(rest) = ident.strip_prefix("pi") {
                if !rest.is_empty() && rest.chars().all(|ch| ch.is_ascii_digit()) {
                    atoms.push("pi".to_string());
                    atoms.push(rest.to_string());
                    continue;
                }
            }
            if let Some(rest) = ident.strip_prefix('e') {
                if !rest.is_empty() && rest.chars().all(|ch| ch.is_ascii_digit()) {
                    atoms.push("e".to_string());
                    atoms.push(rest.to_string());
                    continue;
                }
            }
            atoms.push(ident);
            continue;
        }

        if ch == '*' && is_star_at(&chars, index) {
            atoms.push("**".to_string());
            index += 2;
            continue;
        }

        atoms.push(ch.to_string());
        index += 1;
    }

    atoms
}

fn needs_mult(previous: &str, next: &str) -> bool {
    if is_number(previous) {
        return next.starts_with('(') || is_identifier(next);
    }

    if is_identifier(previous) {
        if next.starts_with('(') {
            return false;
        }
        if next.chars().next().is_some_and(|ch| ch.is_ascii_digit()) {
            return true;
        }
    }

    if previous == ")" {
        return next.starts_with('(') || is_number(next) || is_identifier(next);
    }

    false
}

fn is_number(token: &str) -> bool {
    !token.is_empty()
        && token
            .chars()
            .all(|ch| ch.is_ascii_digit() || ch == '.')
}

fn is_identifier(token: &str) -> bool {
    token == "_" || CONSTANTS.contains(&token) || FUNCTIONS.contains(&token)
        || token.chars().all(|ch| ch.is_ascii_alphabetic() || ch == '_')
}

fn is_ident_part(ch: char) -> bool {
    ch.is_ascii_alphanumeric() || ch == '_'
}

fn is_digit_at(chars: &[char], index: usize) -> bool {
    chars.get(index).is_some_and(|ch| ch.is_ascii_digit())
}

fn is_star_at(chars: &[char], index: usize) -> bool {
    chars.get(index + 1).is_some_and(|&ch| ch == '*')
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn balances_open_parens() {
        assert_eq!(balance_parentheses("ceil(sqrt(3^2 + 5^2").unwrap(), "ceil(sqrt(3^2 + 5^2))");
    }

    #[test]
    fn preserves_function_names_with_digits() {
        assert_eq!(insert_implicit_multiplication("log10(100)"), "log10(100)");
        assert_eq!(insert_implicit_multiplication("5sin(45)"), "5*sin(45)");
    }
}
