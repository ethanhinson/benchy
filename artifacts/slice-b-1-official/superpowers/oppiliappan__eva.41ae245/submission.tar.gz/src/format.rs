use crate::eval::Config;

const DIGITS: &[u8; 36] = b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

pub fn format_number(value: f64, config: &Config) -> String {
    if config.base == 10 {
        format_base10(value, config.fix)
    } else {
        format_other_base(value, config.base, config.fix)
    }
}

fn format_base10(value: f64, fix: u8) -> String {
    let negative = value.is_sign_negative() && !value.is_nan();
    let abs = value.abs();

    let formatted = format!("{:.1$}", abs, fix as usize);
    let (int_part, frac_part) = formatted.split_once('.').unwrap_or((&formatted, ""));

    let mut int_str = int_part.to_string();
    insert_commas_base10(&mut int_str);

    let sign = if negative { "-" } else { "" };
    format!("{sign}{int_str}.{frac_part}")
}

fn insert_commas_base10(s: &mut String) {
    if s.len() <= 3 {
        return;
    }
    let chars: Vec<char> = s.chars().collect();
    let mut out = String::new();
    for (i, ch) in chars.iter().enumerate() {
        if i > 0 && (chars.len() - i) % 3 == 0 {
            out.push(',');
        }
        out.push(*ch);
    }
    *s = out;
}

fn format_other_base(value: f64, base: u8, fix: u8) -> String {
    let negative = value.is_sign_negative() && !value.is_nan();
    let abs = value.abs();

    let int_part = abs.trunc() as u128;
    let frac_part = abs - int_part as f64;

    let mut int_str = to_base(int_part, base);
    insert_commas_generic(&mut int_str);

    let mut frac_digits = String::new();
    let mut remaining = frac_part;
    for _ in 0..fix {
        remaining *= base as f64;
        let digit = remaining.trunc() as u8;
        frac_digits.push(DIGITS[digit as usize] as char);
        remaining -= digit as f64;
    }

    let frac_str = if frac_digits.chars().all(|c| c == '0') {
        "0".to_string()
    } else {
        trim_trailing_chars(&frac_digits, '0')
    };

    let sign = if negative { "-" } else { "" };
    format_non_base10(&format!("{sign}{int_str}"), &frac_str)
}

fn format_non_base10(int_with_commas: &str, frac_str: &str) -> String {
    let body = format!("{int_with_commas}.{frac_str}");
    let width = if body.contains(',') {
        13.max(body.len() + 6)
    } else if body.len() > 7 {
        body.len() + 9
    } else {
        12
    };
    let padded = format!("{body:>width$}");
    let chars: Vec<char> = padded.chars().collect();
    let tail: String = chars[7..].iter().collect();
    if tail.starts_with(',') {
        format!(
            "{},{},{}{tail}",
            chars[0],
            chars[1..4].iter().collect::<String>(),
            chars[4..7].iter().collect::<String>()
        )
    } else {
        format!(
            "{},{},{},{}",
            chars[0],
            chars[1..4].iter().collect::<String>(),
            chars[4..7].iter().collect::<String>(),
            tail
        )
    }
}

fn trim_trailing_chars(s: &str, ch: char) -> String {
    let mut out = s.to_string();
    while out.ends_with(ch) && out.len() > 1 {
        out.pop();
    }
    out
}

fn insert_commas_generic(s: &mut String) {
    if s.len() <= 3 {
        return;
    }
    let chars: Vec<char> = s.chars().collect();
    let mut out = String::new();
    for (i, ch) in chars.iter().enumerate() {
        if i > 0 && (chars.len() - i) % 3 == 0 {
            out.push(',');
        }
        out.push(*ch);
    }
    *s = out;
}

fn to_base(mut n: u128, base: u8) -> String {
    if n == 0 {
        return "0".into();
    }
    let mut digits = Vec::new();
    let b = base as u128;
    while n > 0 {
        let rem = (n % b) as usize;
        digits.push(DIGITS[rem] as char);
        n /= b;
    }
    digits.iter().rev().collect()
}
