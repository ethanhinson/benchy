use crate::parse::Expr;

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum AngleUnit {
    Degree,
    Radian,
    Gradian,
}

#[derive(Clone, Copy, Debug)]
pub struct Config {
    pub fix: u8,
    pub base: u8,
    pub angle_unit: AngleUnit,
}

#[derive(Debug, Clone, PartialEq)]
pub enum EvalError {
    Parser(String),
    Syntax(String),
    Math(String),
    Domain(String),
}

impl std::fmt::Display for EvalError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EvalError::Parser(msg) => write!(f, "Parser Error: {msg}"),
            EvalError::Syntax(msg) => write!(f, "Syntax Error: {msg}"),
            EvalError::Math(msg) => write!(f, "Math Error: {msg}"),
            EvalError::Domain(msg) => write!(f, "Domain Error: {msg}"),
        }
    }
}

pub struct Evaluator {
    config: Config,
    previous: f64,
}

impl Evaluator {
    pub fn new(config: Config) -> Self {
        Self {
            config,
            previous: 0.0,
        }
    }

    pub fn config(&self) -> Config {
        self.config
    }

    pub fn evaluate(&mut self, expr: &Expr) -> Result<f64, EvalError> {
        let value = eval_expr(expr, self.config.angle_unit, self.previous)?;
        self.previous = value;
        Ok(value)
    }
}

fn eval_expr(expr: &Expr, angle_unit: AngleUnit, previous: f64) -> Result<f64, EvalError> {
    match expr {
        Expr::Number(n) => Ok(*n),
        Expr::Previous => Ok(previous),
        Expr::Unary { op, rhs } => {
            let v = eval_expr(rhs, angle_unit, previous)?;
            match op {
                '+' => Ok(v),
                '-' => Ok(-v),
                _ => unreachable!(),
            }
        }
        Expr::Binary { op, lhs, rhs } => {
            let l = eval_expr(lhs, angle_unit, previous)?;
            let r = eval_expr(rhs, angle_unit, previous)?;
            match op {
                '+' => Ok(l + r),
                '-' => Ok(l - r),
                '*' => Ok(l * r),
                '/' => {
                    if r == 0.0 {
                        return Err(EvalError::Math("Divide by zero error!".into()));
                    }
                    Ok(l / r)
                }
                '^' => Ok(l.powf(r)),
                _ => unreachable!(),
            }
        }
        Expr::Call { name, args } => eval_function(name, args, angle_unit, previous),
    }
}

fn to_radians(x: f64, unit: AngleUnit) -> f64 {
    match unit {
        AngleUnit::Degree => x.to_radians(),
        AngleUnit::Radian => x,
        AngleUnit::Gradian => x * std::f64::consts::PI / 200.0,
    }
}

fn eval_function(
    name: &str,
    args: &[Expr],
    angle_unit: AngleUnit,
    previous: f64,
) -> Result<f64, EvalError> {
    let eval1 = |e: &Expr| eval_expr(e, angle_unit, previous);
    let eval_args = |n: usize| -> Result<Vec<f64>, EvalError> {
        if args.len() != n {
            return Err(EvalError::Parser(format!(
                "To few arguments for function, need {n}"
            )));
        }
        args.iter().map(eval1).collect()
    };

    match name {
        "sin" => Ok(to_radians(eval_args(1)?[0], angle_unit).sin()),
        "cos" => Ok(to_radians(eval_args(1)?[0], angle_unit).cos()),
        "tan" => Ok(to_radians(eval_args(1)?[0], angle_unit).tan()),
        "csc" => {
            let s = to_radians(eval_args(1)?[0], angle_unit).sin();
            if s == 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(1.0 / s)
        }
        "sec" => {
            let c = to_radians(eval_args(1)?[0], angle_unit).cos();
            if c == 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(1.0 / c)
        }
        "cot" => {
            let t = to_radians(eval_args(1)?[0], angle_unit).tan();
            if t == 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(1.0 / t)
        }
        "sinh" => Ok(eval_args(1)?[0].sinh()),
        "cosh" => Ok(eval_args(1)?[0].cosh()),
        "tanh" => Ok(eval_args(1)?[0].tanh()),
        "asin" => {
            let v = eval_args(1)?[0];
            if v < -1.0 || v > 1.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(v.asin())
        }
        "acos" => {
            let v = eval_args(1)?[0];
            if v < -1.0 || v > 1.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(v.acos())
        }
        "atan" => Ok(eval_args(1)?[0].atan()),
        "acsc" => {
            let v = eval_args(1)?[0];
            if v.abs() < 1.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok((1.0 / v).asin())
        }
        "asec" => {
            let v = eval_args(1)?[0];
            if v.abs() < 1.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok((1.0 / v).acos())
        }
        "acot" => Ok((1.0 / eval_args(1)?[0]).atan()),
        "ln" => {
            let v = eval_args(1)?[0];
            if v <= 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(v.ln())
        }
        "log2" => {
            let v = eval_args(1)?[0];
            if v <= 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(v.log2())
        }
        "log10" => {
            let v = eval_args(1)?[0];
            if v <= 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(v.log10())
        }
        "sqrt" => {
            let v = eval_args(1)?[0];
            if v < 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(v.sqrt())
        }
        "ceil" => Ok(eval_args(1)?[0].ceil()),
        "floor" => Ok(eval_args(1)?[0].floor()),
        "abs" => Ok(eval_args(1)?[0].abs()),
        "log" => {
            let vals = eval_args(2)?;
            let (x, base) = (vals[0], vals[1]);
            if x <= 0.0 || (base <= 0.0 && base != 0.0) {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(x.log(base))
        }
        "nroot" => {
            let vals = eval_args(2)?;
            let (x, n) = (vals[0], vals[1]);
            if x < 0.0 {
                return Err(EvalError::Domain("Out of bounds!".into()));
            }
            Ok(x.powf(1.0 / n))
        }
        "deg" => Ok(eval_args(1)?[0].to_degrees()),
        "rad" => Ok(eval_args(1)?[0].to_radians()),
        other => Err(EvalError::Syntax(format!("Unknown function '{other}'"))),
    }
}
