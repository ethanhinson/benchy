use crate::eval::EvalError;

#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    Number(f64),
    Ident(String),
    Plus,
    Minus,
    Star,
    Slash,
    Caret,
    LParen,
    RParen,
    Comma,
}

pub fn tokenize(input: &str) -> Result<Vec<Token>, EvalError> {
    let raw = lex_raw(input)?;
    Ok(insert_implicit_multiplication(raw))
}

fn lex_raw(input: &str) -> Result<Vec<Token>, EvalError> {
    let chars: Vec<char> = input.chars().collect();
    let mut tokens = Vec::new();
    let mut i = 0;

    while i < chars.len() {
        let ch = chars[i];
        if ch.is_ascii_whitespace() {
            i += 1;
            continue;
        }

        match ch {
            '+' => {
                tokens.push(Token::Plus);
                i += 1;
            }
            '-' => {
                tokens.push(Token::Minus);
                i += 1;
            }
            '*' => {
                if i + 1 < chars.len() && chars[i + 1] == '*' {
                    tokens.push(Token::Caret);
                    i += 2;
                } else {
                    tokens.push(Token::Star);
                    i += 1;
                }
            }
            '/' => {
                tokens.push(Token::Slash);
                i += 1;
            }
            '^' => {
                tokens.push(Token::Caret);
                i += 1;
            }
            '(' => {
                tokens.push(Token::LParen);
                i += 1;
            }
            ')' => {
                tokens.push(Token::RParen);
                i += 1;
            }
            ',' => {
                tokens.push(Token::Comma);
                i += 1;
            }
            '.' | '0'..='9' => {
                let start = i;
                let mut saw_dot = false;
                while i < chars.len() {
                    let c = chars[i];
                    if c == '.' {
                        if saw_dot {
                            break;
                        }
                        saw_dot = true;
                        i += 1;
                    } else if c.is_ascii_digit() {
                        i += 1;
                    } else {
                        break;
                    }
                }
                let slice: String = chars[start..i].iter().collect();
                let value: f64 = slice
                    .parse()
                    .map_err(|_| EvalError::Parser("Too many operators, too few operands".into()))?;
                tokens.push(Token::Number(value));
            }
            'a'..='z' | 'A'..='Z' | '_' => {
                let start = i;
                while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '_') {
                    i += 1;
                }
                let ident: String = chars[start..i].iter().collect();
                tokens.push(Token::Ident(ident));
            }
            _ => {
                return Err(EvalError::Parser(
                    "Too many operators, too few operands".into(),
                ));
            }
        }
    }

    Ok(tokens)
}

fn insert_implicit_multiplication(tokens: Vec<Token>) -> Vec<Token> {
    if tokens.is_empty() {
        return tokens;
    }

    let mut out = Vec::with_capacity(tokens.len() * 2);
    out.push(tokens[0].clone());

    for pair in tokens.windows(2) {
        if needs_implicit_mult(&pair[0], &pair[1]) {
            out.push(Token::Star);
        }
        out.push(pair[1].clone());
    }

    out
}

fn needs_implicit_mult(prev: &Token, next: &Token) -> bool {
    matches!(
        (prev, next),
        (Token::Number(_), Token::LParen)
            | (Token::Number(_), Token::Ident(_))
            | (Token::RParen, Token::LParen)
            | (Token::Ident(_), Token::Number(_))
    )
}
