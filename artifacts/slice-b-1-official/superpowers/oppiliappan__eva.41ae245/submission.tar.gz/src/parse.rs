use crate::eval::EvalError;
use crate::lexer::Token;

#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    Number(f64),
    Previous,
    Unary { op: char, rhs: Box<Expr> },
    Binary {
        op: char,
        lhs: Box<Expr>,
        rhs: Box<Expr>,
    },
    Call {
        name: String,
        args: Vec<Expr>,
    },
}

pub fn parse(tokens: &[Token]) -> Result<Expr, EvalError> {
    if tokens.is_empty() {
        return Err(EvalError::Parser("Too many operators, too few operands".into()));
    }

    let mut parser = Parser { tokens, pos: 0 };
    let expr = parser.parse_expression()?;
    if parser.has_remaining() {
        return Err(EvalError::Parser(
            "Too many operators, too few operands".into(),
        ));
    }
    Ok(expr)
}

struct Parser<'a> {
    tokens: &'a [Token],
    pos: usize,
}

impl<'a> Parser<'a> {
    fn peek(&self) -> Option<&Token> {
        self.tokens.get(self.pos)
    }

    fn advance(&mut self) -> Option<&Token> {
        let tok = self.tokens.get(self.pos);
        if tok.is_some() {
            self.pos += 1;
        }
        tok
    }

    fn has_remaining(&self) -> bool {
        self.pos < self.tokens.len()
    }

    fn parse_expression(&mut self) -> Result<Expr, EvalError> {
        self.parse_additive()
    }

    fn parse_additive(&mut self) -> Result<Expr, EvalError> {
        let mut lhs = self.parse_multiplicative()?;
        while matches!(self.peek(), Some(Token::Plus | Token::Minus)) {
            let op = match self.advance().unwrap() {
                Token::Plus => '+',
                Token::Minus => '-',
                _ => unreachable!(),
            };
            let rhs = self.parse_multiplicative()?;
            lhs = Expr::Binary {
                op,
                lhs: Box::new(lhs),
                rhs: Box::new(rhs),
            };
        }
        Ok(lhs)
    }

    fn parse_multiplicative(&mut self) -> Result<Expr, EvalError> {
        let mut lhs = self.parse_power()?;
        while matches!(self.peek(), Some(Token::Star | Token::Slash)) {
            let op = match self.advance().unwrap() {
                Token::Star => '*',
                Token::Slash => '/',
                _ => unreachable!(),
            };
            let rhs = self.parse_power()?;
            lhs = Expr::Binary {
                op,
                lhs: Box::new(lhs),
                rhs: Box::new(rhs),
            };
        }
        Ok(lhs)
    }

    fn parse_power(&mut self) -> Result<Expr, EvalError> {
        let mut lhs = self.parse_unary()?;
        if matches!(self.peek(), Some(Token::Caret)) {
            self.advance();
            let rhs = self.parse_power()?;
            lhs = Expr::Binary {
                op: '^',
                lhs: Box::new(lhs),
                rhs: Box::new(rhs),
            };
        }
        Ok(lhs)
    }

    fn parse_unary(&mut self) -> Result<Expr, EvalError> {
        match self.peek() {
            Some(Token::Plus) => {
                self.advance();
                let rhs = self.parse_unary()?;
                Ok(Expr::Unary {
                    op: '+',
                    rhs: Box::new(rhs),
                })
            }
            Some(Token::Minus) => {
                self.advance();
                let rhs = self.parse_unary()?;
                Ok(Expr::Unary {
                    op: '-',
                    rhs: Box::new(rhs),
                })
            }
            _ => self.parse_primary(),
        }
    }

    fn parse_primary(&mut self) -> Result<Expr, EvalError> {
        match self.peek() {
            Some(Token::Number(n)) => {
                let value = *n;
                self.advance();
                Ok(Expr::Number(value))
            }
            Some(Token::Ident(name)) => {
                let name = name.clone();
                self.advance();

                if name == "_" {
                    return Ok(Expr::Previous);
                }

                if name == "pi" {
                    return Ok(Expr::Number(std::f64::consts::PI));
                }
                if name == "e" {
                    return Ok(Expr::Number(std::f64::consts::E));
                }

                if matches!(self.peek(), Some(Token::LParen)) {
                    self.advance();
                    let mut args = Vec::new();
                    if !matches!(self.peek(), Some(Token::RParen)) {
                        loop {
                            args.push(self.parse_expression()?);
                            match self.peek() {
                                Some(Token::Comma) => {
                                    self.advance();
                                }
                                Some(Token::RParen) => break,
                                _ => {
                                    return Err(EvalError::Parser(
                                        "Too many operators, too few operands".into(),
                                    ));
                                }
                            }
                        }
                    }
                    if !matches!(self.advance(), Some(Token::RParen)) {
                        return Err(EvalError::Parser(
                            "Too many operators, too few operands".into(),
                        ));
                    }
                    return Ok(Expr::Call { name, args });
                }

                Err(EvalError::Parser(
                    "Too many operators, too few operands".into(),
                ))
            }
            Some(Token::LParen) => {
                self.advance();
                let expr = self.parse_expression()?;
                if !matches!(self.advance(), Some(Token::RParen)) {
                    return Err(EvalError::Parser(
                        "Too many operators, too few operands".into(),
                    ));
                }
                Ok(expr)
            }
            _ => {
                self.advance();
                Err(EvalError::Parser(
                    "Too many operators, too few operands".into(),
                ))
            }
        }
    }
}
