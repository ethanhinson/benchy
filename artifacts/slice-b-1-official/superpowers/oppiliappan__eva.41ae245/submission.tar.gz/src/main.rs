mod eval;
mod format;
mod lexer;
mod parse;

use clap::{Parser, ValueEnum};
use eval::{AngleUnit, Config, EvalError, Evaluator};
use format::format_number;
use rustyline::DefaultEditor;
use std::io::IsTerminal;

#[derive(Parser)]
#[command(name = "eva", version = "0.3.1", about = "Calculator REPL similar to bc(1)")]
struct Cli {
    #[arg(
        short = 'f',
        long = "fix",
        default_value_t = 10,
        value_name = "FIX",
        help = "Number of decimal places in output (1 - 64)"
    )]
    fix: u8,

    #[arg(
        short = 'b',
        long = "base",
        default_value_t = 10,
        value_name = "RADIX",
        help = "Radix of calculation output (1 - 36)"
    )]
    base: u8,

    #[arg(
        short = 'a',
        long = "angle_unit",
        default_value = "degree",
        value_name = "angle_unit",
        help = "Angle unit"
    )]
    angle_unit: AngleUnitArg,

    #[arg(value_name = "INPUT", help = "Optional expression string to run eva in command mode")]
    input: Option<String>,
}

#[derive(Clone, ValueEnum)]
enum AngleUnitArg {
    Degree,
    Radian,
    Gradian,
}

impl From<AngleUnitArg> for AngleUnit {
    fn from(value: AngleUnitArg) -> Self {
        match value {
            AngleUnitArg::Degree => AngleUnit::Degree,
            AngleUnitArg::Radian => AngleUnit::Radian,
            AngleUnitArg::Gradian => AngleUnit::Gradian,
        }
    }
}

fn main() {
    let cli = Cli::parse();

    if !(1..=64).contains(&cli.fix) {
        eprintln!(
            "error: invalid value '{}' for '--fix <FIX>': {} is not in 1..=64",
            cli.fix, cli.fix
        );
        eprintln!();
        eprintln!("For more information, try '--help'.");
        std::process::exit(2);
    }

    if !(1..=36).contains(&cli.base) {
        eprintln!(
            "error: invalid value '{}' for '--base <RADIX>': {} is not in 1..=36",
            cli.base, cli.base
        );
        eprintln!();
        eprintln!("For more information, try '--help'.");
        std::process::exit(2);
    }

    let config = Config {
        fix: cli.fix,
        base: cli.base,
        angle_unit: cli.angle_unit.into(),
    };

    let mut evaluator = Evaluator::new(config);

    if let Some(input) = cli.input {
        match evaluate_line(&mut evaluator, &input) {
            Ok(value) => println!("{}", format_number(value, &evaluator.config())),
            Err(err) => {
                eprintln!("{}", err);
                std::process::exit(1);
            }
        }
        return;
    }

    run_repl(&mut evaluator);
}

fn run_repl(evaluator: &mut Evaluator) {
    let mut editor = DefaultEditor::new().expect("failed to create line editor");
    if std::io::stdin().is_terminal() {
        let history_path = dirs_history_path();
        if editor.load_history(&history_path).is_err() {
            println!("No previous history.");
        }
    }

    loop {
        match editor.readline("> ") {
            Ok(line) => {
                let trimmed = line.trim();
                if trimmed.is_empty() {
                    println!("{}", format_number(0.0, &evaluator.config()));
                    if std::io::stdin().is_terminal() {
                        let _ = editor.add_history_entry(line);
                    }
                    continue;
                }

                match evaluate_line(evaluator, trimmed) {
                    Ok(value) => {
                        println!("{}", format_number(value, &evaluator.config()));
                        if std::io::stdin().is_terminal() {
                            let _ = editor.add_history_entry(line);
                        }
                    }
                    Err(err) => eprintln!("{}", err),
                }
            }
            Err(rustyline::error::ReadlineError::Interrupted) | Err(rustyline::error::ReadlineError::Eof) => {
                println!();
                break;
            }
            Err(err) => {
                eprintln!("{err}");
                break;
            }
        }
    }
}

fn dirs_history_path() -> String {
    if let Some(home) = std::env::var_os("HOME") {
        return format!("{}/.eva_history", home.to_string_lossy());
    }
    ".eva_history".to_string()
}

fn balance_parentheses(input: &str) -> String {
    let mut balance = 0i64;
    for ch in input.chars() {
        match ch {
            '(' => balance += 1,
            ')' => balance -= 1,
            _ => {}
        }
    }
    if balance > 0 {
        let mut balanced = input.to_string();
        balanced.push_str(&")".repeat(balance as usize));
        balanced
    } else {
        input.to_string()
    }
}

fn evaluate_line(evaluator: &mut Evaluator, input: &str) -> Result<f64, EvalError> {
    let balanced = balance_parentheses(input);
    let tokens = lexer::tokenize(&balanced)?;
    let ast = parse::parse(&tokens)?;
    evaluator.evaluate(&ast)
}
