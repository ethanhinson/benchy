#!/bin/sh
set -eu

cd "$(dirname "$0")"
cargo build --release
cp target/release/eva ./candidate
cp -f ./candidate ./executable
