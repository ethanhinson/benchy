use std::io::{self, Write};

use crate::chars::CharacterTable;
use crate::colors::Colors;

pub const BYTES_PER_PANEL: usize = 8;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BorderStyle {
    Unicode,
    Ascii,
    None,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Endianness {
    Little,
    Big,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Base {
    Binary,
    Octal,
    Decimal,
    Hexadecimal,
}

#[derive(Debug, Clone)]
pub struct DisplayOptions {
    pub show_position: bool,
    pub show_characters: bool,
    pub border: BorderStyle,
    pub colors_enabled: bool,
    pub colors: Colors,
    pub char_table: CharacterTable,
    pub group_size: usize,
    pub endianness: Endianness,
    pub base: Base,
    pub num_panels: usize,
    pub display_offset: u64,
    pub squeeze: bool,
    pub include_style: bool,
    pub include_name: String,
}

impl DisplayOptions {
    pub fn bytes_per_line(&self) -> usize {
        if self.base == Base::Hexadecimal {
            BYTES_PER_PANEL * self.num_panels
        } else {
            BYTES_PER_PANEL
        }
    }

    pub fn effective_panels(&self) -> usize {
        if self.base == Base::Hexadecimal {
            self.num_panels
        } else {
            1
        }
    }
}

pub fn display_data(data: &[u8], opts: &DisplayOptions, out: &mut dyn Write) -> io::Result<()> {
    if opts.include_style {
        return write_include(data, &opts.include_name, out);
    }

    if data.is_empty() {
        if opts.border != BorderStyle::None {
            return write_empty_border(opts, out);
        }
        return Ok(());
    }

    if opts.border != BorderStyle::None {
        return write_all_bordered(data, opts, out);
    }

    let bpl = opts.bytes_per_line();
    let hex_width = hex_area_width(opts);
    let mut offset = 0usize;
    let mut prev: Option<(String, String)> = None;
    let mut squeeze_pending = false;

    while offset < data.len() {
        let end = (offset + bpl).min(data.len());
        let chunk = &data[offset..end];
        let file_off = offset as u64 + opts.display_offset;

        let hex = format_full_hex(chunk, opts);
        let ascii = if opts.show_characters {
            format_ascii(chunk, opts)
        } else {
            String::new()
        };

        if opts.squeeze {
            let key = (strip_ansi(&hex), strip_ansi(&ascii));
            if prev.as_ref() == Some(&key) {
                if !squeeze_pending {
                    write_squeeze_line(opts, hex_width, out)?;
                    squeeze_pending = true;
                }
                offset = end;
                continue;
            }
            squeeze_pending = false;
            prev = Some(key);
        }

        write_plain_line(file_off, &hex, &ascii, opts, hex_width, out)?;
        offset = end;
    }

    if opts.squeeze && squeeze_pending {
        let final_off = data.len() as u64 + opts.display_offset;
        write_plain_line(final_off, "", "", opts, hex_width, out)?;
    }

    Ok(())
}

fn write_plain_line(
    file_offset: u64,
    hex: &str,
    ascii: &str,
    opts: &DisplayOptions,
    hex_width: usize,
    out: &mut dyn Write,
) -> io::Result<()> {
    let bpl = opts.bytes_per_line();
    let panels = opts.effective_panels();

    if opts.show_position {
        let off = format!("{:08x}", file_offset);
        if opts.colors_enabled {
            write!(out, " {}", opts.colors.offset.wrap(&off))?;
        } else {
            write!(out, " {off}")?;
        }
        write!(out, "  ")?;
    } else {
        write!(out, "  ")?;
    }

    write!(out, "{hex}")?;
    let plain_hex_len = strip_ansi(hex).len();
    if plain_hex_len < hex_width {
        write!(out, "{}", " ".repeat(hex_width - plain_hex_len))?;
    }

    if opts.show_characters {
        write!(out, "  {ascii}")?;
        let plain = strip_ansi(ascii);
        let target = if panels > 1 { bpl + 1 } else { bpl };
        let count = plain.chars().count();
        if count < target {
            write!(out, "{}", " ".repeat(target - count))?;
        }
        writeln!(out, " ")
    } else {
        writeln!(out, "  ")
    }
}

fn write_squeeze_line(
    opts: &DisplayOptions,
    hex_width: usize,
    out: &mut dyn Write,
) -> io::Result<()> {
    let bpl = opts.bytes_per_line();
    let panels = opts.effective_panels();
    let char_w = if opts.show_characters {
        if panels > 1 { bpl + 1 } else { bpl }
    } else {
        0
    };
    let pos_w = if opts.show_position { 11 } else { 2 };
    let total = pos_w + hex_width + if opts.show_characters { 3 + char_w } else { 2 };
    write!(out, " *")?;
    writeln!(out, "{:width$}", "", width = total.saturating_sub(2))
}

fn format_full_hex(chunk: &[u8], opts: &DisplayOptions) -> String {
    let panels = opts.effective_panels();
    let mut parts = Vec::new();
    for p in 0..panels {
        let start = p * BYTES_PER_PANEL;
        if start >= chunk.len() {
            break;
        }
        let end = (start + BYTES_PER_PANEL).min(chunk.len());
        parts.push(format_panel_hex(&chunk[start..end], opts));
    }
    if panels > 1 {
        match parts.len() {
            0 => String::new(),
            1 => parts[0].clone(),
            _ => format!("{}   {}", parts[0], parts[1]),
        }
    } else {
        parts.into_iter().next().unwrap_or_default()
    }
}

fn format_panel_hex(bytes: &[u8], opts: &DisplayOptions) -> String {
    if bytes.is_empty() {
        return String::new();
    }
    let gs = opts.group_size.max(1);
    let mut parts = Vec::new();
    let mut i = 0;
    while i < bytes.len() {
        let end = (i + gs).min(bytes.len());
        parts.push(format_group(&bytes[i..end], opts));
        i = end;
    }
    parts.join(" ")
}

fn format_group(group: &[u8], opts: &DisplayOptions) -> String {
    if group.is_empty() {
        return String::new();
    }
    match opts.base {
        Base::Hexadecimal if opts.group_size > 1 && group.len() == opts.group_size => {
            let ordered: Vec<u8> = if opts.endianness == Endianness::Big {
                group.to_vec()
            } else {
                let mut rev = group.to_vec();
                rev.reverse();
                rev
            };
            let mut val: u64 = 0;
            for &b in &ordered {
                val = (val << 8) | b as u64;
            }
            let width = group.len() * 2;
            format!("{:0width$x}", val, width = width)
        }
        Base::Hexadecimal => group
            .iter()
            .map(|&b| {
                if opts.colors_enabled {
                    opts.colors.color_byte(b, true)
                } else {
                    format!("{b:02x}")
                }
            })
            .collect::<Vec<_>>()
            .join(" "),
        Base::Binary => group
            .iter()
            .map(|&b| format!("{b:08b}"))
            .collect::<Vec<_>>()
            .join(" "),
        Base::Octal => group
            .iter()
            .map(|&b| format!("{b:03o}"))
            .collect::<Vec<_>>()
            .join(" "),
        Base::Decimal => group
            .iter()
            .map(|&b| format!("{b:03}"))
            .collect::<Vec<_>>()
            .join(" "),
    }
}

fn format_ascii(chunk: &[u8], opts: &DisplayOptions) -> String {
    let bpl = opts.bytes_per_line();
    let panels = opts.effective_panels();
    let mut s = String::new();
    for i in 0..bpl {
        if i == BYTES_PER_PANEL && panels > 1 {
            s.push(' ');
        }
        if i < chunk.len() {
            let b = chunk[i];
            let ch = opts.char_table.map(b);
            if opts.colors_enabled {
                s.push_str(&opts.colors.color_char(ch, b, true));
            } else {
                s.push(ch);
            }
        }
    }
    s
}

fn hex_area_width(opts: &DisplayOptions) -> usize {
    let per = hex_panel_width(opts);
    let panels = opts.effective_panels();
    if panels > 1 {
        per * 2 + 3
    } else {
        per
    }
}

fn hex_panel_width(opts: &DisplayOptions) -> usize {
    let n = BYTES_PER_PANEL;
    match opts.base {
        Base::Hexadecimal if opts.group_size == 1 => n * 3 - 1,
        Base::Hexadecimal => {
            let groups = n / opts.group_size;
            groups * (opts.group_size * 2) + groups.saturating_sub(1)
        }
        Base::Binary => n * 9 - 1,
        Base::Octal | Base::Decimal => n * 4 - 1,
    }
}

pub fn strip_ansi(s: &str) -> String {
    let mut result = String::new();
    let mut chars = s.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            while chars.next().is_some() {
                if chars.peek() == Some(&'m') {
                    chars.next();
                    break;
                }
            }
        } else {
            result.push(ch);
        }
    }
    result
}

fn write_empty_border(opts: &DisplayOptions, out: &mut dyn Write) -> io::Result<()> {
    write_border_frame(opts, out, |out| {
        let v = match opts.border {
            BorderStyle::Unicode => '│',
            BorderStyle::Ascii => '|',
            BorderStyle::None => ' ',
        };
        writeln!(
            out,
            "{v}{empty:>8}{v} {msg:<24}{v}{blank:<25}{v}{blank:<8}{v}{blank:<8}{v}",
            empty = "",
            msg = "No content",
            blank = "",
            v = v,
        )
    })
}

fn write_all_bordered(data: &[u8], opts: &DisplayOptions, out: &mut dyn Write) -> io::Result<()> {
    write_border_frame(opts, out, |out| {
        let bpl = opts.bytes_per_line();
        let (v, mid) = match opts.border {
            BorderStyle::Unicode => ('│', '┊'),
            BorderStyle::Ascii => ('|', '|'),
            BorderStyle::None => (' ', ' '),
        };

        let mut offset = 0usize;
        while offset < data.len() {
            let end = (offset + bpl).min(data.len());
            let chunk = &data[offset..end];
            let file_off = offset as u64 + opts.display_offset;

            let p1 = if chunk.len() > 0 {
                format_panel_hex(&chunk[..chunk.len().min(BYTES_PER_PANEL)], opts)
            } else {
                String::new()
            };
            let p2 = if chunk.len() > BYTES_PER_PANEL {
                format_panel_hex(&chunk[BYTES_PER_PANEL..], opts)
            } else {
                String::new()
            };

            let hex_cell = if p2.is_empty() {
                p1
            } else {
                format!("{p1} {mid} {p2}")
            };

            let ascii_cell = if opts.show_characters {
                let mut chars = String::new();
                for (i, &b) in chunk.iter().enumerate() {
                    if i == BYTES_PER_PANEL {
                        chars.push(mid);
                    }
                    chars.push(opts.char_table.map(b));
                }
                chars
            } else {
                String::new()
            };

            if opts.show_position {
                write!(out, "{v}{file_off:08x}{v} {hex_cell} {v}")?;
            } else {
                write!(out, "{v}{empty:>8}{v} {hex_cell} {v}", empty = "", v = v)?;
            }

            if opts.show_characters {
                write!(out, "{ascii_cell}{v}")?;
            } else {
                write!(out, "{empty:>17}{v}", empty = "", v = v)?;
            }
            writeln!(out)?;

            offset = end;
        }
        Ok(())
    })
}

fn write_border_frame<F>(opts: &DisplayOptions, out: &mut dyn Write, mut body: F) -> io::Result<()>
where
    F: FnMut(&mut dyn Write) -> io::Result<()>,
{
    let (tl, h, t, tr, v, bl, br, sep) = match opts.border {
        BorderStyle::Unicode => ('┌', '─', '┬', '┐', '│', '└', '┘', '┴'),
        BorderStyle::Ascii => ('+', '-', '+', '+', '|', '+', '+', '+'),
        BorderStyle::None => (' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '),
    };

    writeln!(
        out,
        "{tl}{}{t}{}{t}{}{t}{}{t}{}{tr}",
        repeat(h, 8),
        repeat(h, 25),
        repeat(h, 25),
        repeat(h, 8),
        repeat(h, 8),
    )?;
    body(out)?;
    writeln!(
        out,
        "{bl}{}{sep}{}{sep}{}{sep}{}{sep}{}{br}",
        repeat(h, 8),
        repeat(h, 25),
        repeat(h, 25),
        repeat(h, 8),
        repeat(h, 8),
    )
}

fn repeat(ch: char, n: usize) -> String {
    ch.to_string().repeat(n)
}

fn write_include(data: &[u8], name: &str, out: &mut dyn Write) -> io::Result<()> {
    let var_name = sanitize_name(name);
    writeln!(out, "unsigned char {var_name}[] = {{")?;
    write!(out, "  ")?;
    for (i, b) in data.iter().enumerate() {
        if i > 0 {
            if i % 12 == 0 {
                writeln!(out)?;
                write!(out, "  ")?;
            } else {
                write!(out, " ")?;
            }
        }
        write!(out, "0x{b:02x}")?;
        if i + 1 < data.len() {
            write!(out, ",")?;
        }
    }
    writeln!(out)?;
    writeln!(out, "}};")?;
    writeln!(out, "unsigned int {var_name}_len = {};", data.len())
}

fn sanitize_name(path: &str) -> String {
    std::path::Path::new(path)
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("data")
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() { c } else { '_' })
        .collect()
}
