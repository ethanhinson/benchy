#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CharacterTable {
    Default,
    Ascii,
    Codepage1047,
    Codepage437,
    Braille,
}

impl CharacterTable {
    pub fn map(self, b: u8) -> char {
        match self {
            CharacterTable::Default => default_char(b),
            CharacterTable::Ascii => ascii_char(b),
            CharacterTable::Codepage1047 => codepage_1047_char(b),
            CharacterTable::Codepage437 => codepage_437_char(b),
            CharacterTable::Braille => braille_char(b),
        }
    }
}

fn default_char(b: u8) -> char {
    match b {
        0x00 => '⋄',
        0x20 => ' ',
        0x09 | 0x0a | 0x0c | 0x0d => '_',
        0x21..=0x7e => b as char,
        0x01..=0x08 | 0x0b..=0x1f | 0x7f => '•',
        _ => '×',
    }
}

fn ascii_char(b: u8) -> char {
    if b == 0x20 {
        ' '
    } else if (0x21..=0x7e).contains(&b) {
        b as char
    } else {
        '.'
    }
}

fn codepage_1047_char(b: u8) -> char {
    if b == 0x40 {
        return ' ';
    }
    if (0x41..=0x49).contains(&b) || (0xc1..=0xc9).contains(&b) {
        return (b as char);
    }
    '.'
}

fn codepage_437_char(b: u8) -> char {
    if b == 0x00 {
        return '⋄';
    }
    if b == 0x20 {
        return ' ';
    }
    if (0x21..=0x7e).contains(&b) {
        return b as char;
    }
    match b {
        0x01 => '☺',
        0x02 => '☻',
        0x03 => '♥',
        0x04 => '♦',
        0x05 => '♣',
        0x06 => '♠',
        0x07 => '•',
        0x08 => '◘',
        0x09 => '○',
        0x0a => '◙',
        0x0b => '♂',
        0x0c => '♀',
        0x0d => '♪',
        0x0e => '♫',
        0x0f => '☼',
        _ if b >= 0x80 => char::from_u32(0x2500 + (b as u32 % 64)).unwrap_or('×'),
        _ => '.',
    }
}

fn braille_char(b: u8) -> char {
    match b {
        0x00 => '⋄',
        0x20 => ' ',
        0x09 => '→',
        0x0a => '↵',
        0x21..=0x7e => b as char,
        _ => char::from_u32(0x2800 + b as u32).unwrap_or('×'),
    }
}
