use std::fmt;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParseContext {
    Length,
    Skip,
    DisplayOffset,
}

#[derive(Debug)]
pub enum ParseError {
    InvalidForm,
    InvalidUnit(String),
    NegativeNotAllowed,
    Overflow,
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ParseError::InvalidForm => write!(f, "is not of the expected form <pos-integer>[<unit>]"),
            ParseError::InvalidUnit(u) => write!(f, "invalid unit \"{u}\""),
            ParseError::NegativeNotAllowed => write!(
                f,
                "negative offset specified, but only positive offsets (counts) are accepted in this context"
            ),
            ParseError::Overflow => write!(f, "value overflow"),
        }
    }
}

impl std::error::Error for ParseError {}

const SI_UNITS: [(&str, u64); 7] = [
    ("B", 1),
    ("kB", 1_000),
    ("MB", 1_000_000),
    ("GB", 1_000_000_000),
    ("TB", 1_000_000_000_000),
    ("PB", 1_000_000_000_000_000),
    ("EB", 1_000_000_000_000_000_000),
];

const BIN_UNITS: [(&str, u64); 7] = [
    ("B", 1),
    ("KiB", 1 << 10),
    ("MiB", 1 << 20),
    ("GiB", 1 << 30),
    ("TiB", 1_u64 << 40),
    ("PiB", 1_u64 << 50),
    ("EiB", 1_u64 << 60),
    // Note: larger binary units may overflow u64
];

pub fn parse_byte_count(
    input: &str,
    block_size: u64,
    context: ParseContext,
) -> Result<i64, ParseError> {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return Err(ParseError::InvalidForm);
    }

    let negative = trimmed.starts_with('-');
    let s = if negative { &trimmed[1..] } else { trimmed };

    if negative && context == ParseContext::DisplayOffset {
        return Err(ParseError::NegativeNotAllowed);
    }

    let value = parse_positive(s, block_size)?;
    let signed = if negative {
        -(value as i64)
    } else {
        value as i64
    };
    Ok(signed)
}

fn parse_positive(s: &str, block_size: u64) -> Result<u64, ParseError> {
    if let Some(hex) = s.strip_prefix("0x").or_else(|| s.strip_prefix("0X")) {
        if hex.is_empty() || !hex.chars().all(|c| c.is_ascii_hexdigit()) {
            return Err(ParseError::InvalidForm);
        }
        return u64::from_str_radix(hex, 16).map_err(|_| ParseError::Overflow);
    }

    if s.chars().all(|c| c.is_ascii_digit()) {
        return s.parse().map_err(|_| ParseError::Overflow);
    }

    let split = s
        .char_indices()
        .find(|(_, c)| !c.is_ascii_digit())
        .map(|(i, _)| i)
        .ok_or(ParseError::InvalidForm)?;

    let (num, unit) = s.split_at(split);
    if num.is_empty() {
        return Err(ParseError::InvalidForm);
    }
    let n: u64 = num.parse().map_err(|_| ParseError::Overflow)?;

    if unit == "block" {
        return n
            .checked_mul(block_size)
            .ok_or(ParseError::Overflow);
    }

    for (name, mult) in SI_UNITS {
        if unit == name {
            return n.checked_mul(mult).ok_or(ParseError::Overflow);
        }
    }
    for (name, mult) in BIN_UNITS {
        if unit == name {
            return n.checked_mul(mult).ok_or(ParseError::Overflow);
        }
    }

    Err(ParseError::InvalidUnit(unit.to_string()))
}
