use std::env;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorWhen {
    Always,
    Auto,
    Never,
    Force,
}

impl ColorWhen {
    pub fn use_colors(self, stdout_is_tty: bool) -> bool {
        match self {
            ColorWhen::Always => !env::var_os("NO_COLOR").is_some_and(|_| true) || false,
            ColorWhen::Auto => stdout_is_tty && env::var_os("NO_COLOR").is_none(),
            ColorWhen::Never => false,
            ColorWhen::Force => true,
        }
    }

    pub fn effective(self, stdout_is_tty: bool) -> bool {
        match self {
            ColorWhen::Always => env::var_os("NO_COLOR").is_none(),
            ColorWhen::Auto => stdout_is_tty && env::var_os("NO_COLOR").is_none(),
            ColorWhen::Never => false,
            ColorWhen::Force => true,
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct AnsiColor {
    pub code: u8,
}

impl AnsiColor {
    pub fn fg(self) -> String {
        format!("\x1b[{}m", self.code)
    }
}

pub const RESET: &str = "\x1b[39m";

#[derive(Debug, Clone)]
pub struct ColorScheme {
    pub null: AnsiColor,
    pub ascii_printable: AnsiColor,
    pub ascii_whitespace: AnsiColor,
    pub ascii_other: AnsiColor,
    pub non_ascii: AnsiColor,
    pub offset: AnsiColor,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SchemeKind {
    Default,
    Gradient,
}

fn parse_color_name(name: &str) -> Option<AnsiColor> {
    let lower = name.trim().to_ascii_lowercase();
    let code = match lower.as_str() {
        "black" => 30,
        "red" => 31,
        "green" => 32,
        "yellow" => 33,
        "blue" => 34,
        "magenta" => 35,
        "cyan" => 36,
        "white" => 37,
        "bright black" | "brightblack" => 90,
        "bright red" => 91,
        "bright green" => 92,
        "bright yellow" => 93,
        "bright blue" => 94,
        "bright magenta" => 95,
        "bright cyan" => 96,
        "bright white" => 97,
        _ => return None,
    };
    Some(AnsiColor { code })
}

#[derive(Debug, Clone)]
pub enum ColorSpec {
    Standard(u8),
    Rgb(u8, u8, u8),
}

impl ColorSpec {
    pub fn wrap(&self, text: &str) -> String {
        match self {
            ColorSpec::Standard(code) => format!("\x1b[{code}m{text}\x1b[39m"),
            ColorSpec::Rgb(r, g, b) => format!("\x1b[38;2;{r};{g};{b}m{text}\x1b[39m"),
        }
    }
}

pub fn parse_color_spec(name: &str) -> Option<ColorSpec> {
    let lower = name.trim().to_ascii_lowercase();
    if let Some(hex) = lower.strip_prefix('#') {
        if hex.len() == 6 && hex.chars().all(|c| c.is_ascii_hexdigit()) {
            let r = u8::from_str_radix(&hex[0..2], 16).ok()?;
            let g = u8::from_str_radix(&hex[2..4], 16).ok()?;
            let b = u8::from_str_radix(&hex[4..6], 16).ok()?;
            return Some(ColorSpec::Rgb(r, g, b));
        }
        return None;
    }
    parse_color_name(name).map(|c| ColorSpec::Standard(c.code))
}

#[derive(Debug, Clone)]
pub struct Colors {
    pub null: ColorSpec,
    pub ascii_printable: ColorSpec,
    pub ascii_whitespace: ColorSpec,
    pub ascii_other: ColorSpec,
    pub non_ascii: ColorSpec,
    pub offset: ColorSpec,
    pub scheme: SchemeKind,
}

impl Colors {
    pub fn from_env(scheme: SchemeKind) -> Self {
        let default = Self::default_scheme(scheme);
        Colors {
            null: env_color("HEXYL_COLOR_NULL").unwrap_or(default.null),
            ascii_printable: env_color("HEXYL_COLOR_ASCII_PRINTABLE")
                .unwrap_or(default.ascii_printable),
            ascii_whitespace: env_color("HEXYL_COLOR_ASCII_WHITESPACE")
                .unwrap_or(default.ascii_whitespace),
            ascii_other: env_color("HEXYL_COLOR_ASCII_OTHER").unwrap_or(default.ascii_other),
            non_ascii: env_color("HEXYL_COLOR_NONASCII").unwrap_or(default.non_ascii),
            offset: env_color("HEXYL_COLOR_OFFSET").unwrap_or(default.offset),
            scheme,
        }
    }

    fn default_scheme(scheme: SchemeKind) -> Self {
        match scheme {
            SchemeKind::Default => Colors {
                null: ColorSpec::Standard(90),
                ascii_printable: ColorSpec::Standard(36),
                ascii_whitespace: ColorSpec::Standard(32),
                ascii_other: ColorSpec::Standard(32),
                non_ascii: ColorSpec::Standard(33),
                offset: ColorSpec::Standard(39),
                scheme,
            },
            SchemeKind::Gradient => Colors {
                null: ColorSpec::Standard(90),
                ascii_printable: ColorSpec::Standard(36),
                ascii_whitespace: ColorSpec::Standard(32),
                ascii_other: ColorSpec::Standard(32),
                non_ascii: ColorSpec::Standard(33),
                offset: ColorSpec::Standard(39),
                scheme,
            },
        }
    }

    pub fn color_byte(&self, b: u8, enabled: bool) -> String {
        if !enabled {
            return format!("{:02x}", b);
        }
        let spec = self.byte_color(b);
        spec.wrap(&format!("{:02x}", b))
    }

    pub fn byte_color(&self, b: u8) -> &ColorSpec {
        if b == 0 {
            return &self.null;
        }
        if b >= 0x80 {
            return &self.non_ascii;
        }
        if (0x20..=0x7e).contains(&b) {
            if b == 0x20 {
                return &self.ascii_whitespace;
            }
            return &self.ascii_printable;
        }
        if matches!(b, 0x09 | 0x0a | 0x0b | 0x0c | 0x0d) {
            return &self.ascii_whitespace;
        }
        &self.ascii_other
    }

    pub fn color_char(&self, ch: char, b: u8, enabled: bool) -> String {
        if !enabled {
            return ch.to_string();
        }
        if self.scheme == SchemeKind::Gradient {
            let spec = gradient_color(b);
            return spec.wrap(&ch.to_string());
        }
        let spec = self.char_color(b);
        spec.wrap(&ch.to_string())
    }

    fn char_color(&self, b: u8) -> &ColorSpec {
        self.byte_color(b)
    }
}

fn env_color(var: &str) -> Option<ColorSpec> {
    env::var(var).ok().and_then(|v| parse_color_spec(&v))
}

fn gradient_color(b: u8) -> ColorSpec {
    if b == 0 {
        return ColorSpec::Standard(90);
    }
    if (0x20..=0x7e).contains(&b) {
        return ColorSpec::Standard(36);
    }
    if b < 0x80 {
        // pink to violet gradient for non-printable ASCII
        let t = b as f64 / 127.0;
        let r = (255.0 * (1.0 - t * 0.3)) as u8;
        let g = (127.0 * t) as u8;
        let b_val = (255.0 * t) as u8;
        return ColorSpec::Rgb(r, g, b_val);
    }
    // heatmap red -> yellow -> white for non-ASCII
    let t = (b - 0x80) as f64 / 127.0;
    let r = 255;
    let g = (255.0 * t.min(0.5) * 2.0) as u8;
    let b_val = if t > 0.5 {
        ((t - 0.5) * 2.0 * 255.0) as u8
    } else {
        0
    };
    ColorSpec::Rgb(r, g, b_val)
}

pub fn print_color_table(colors: &Colors, enabled: bool) {
    println!("hexyl color reference:\n");
    let entries = [
        (colors.null.clone(), "⋄ NULL bytes (0x00)"),
        (
            colors.ascii_printable.clone(),
            "a ASCII printable characters (0x20 - 0x7E)",
        ),
        (
            colors.ascii_whitespace.clone(),
            "_ ASCII whitespace (0x09 - 0x0D, 0x20)",
        ),
        (
            colors.ascii_other.clone(),
            "• ASCII control characters (except NULL and whitespace)",
        ),
        (
            colors.non_ascii.clone(),
            "× Non-ASCII bytes (0x80 - 0xFF)",
        ),
    ];
    for (spec, label) in entries {
        if enabled {
            print!("{}", spec.wrap(label));
        } else {
            print!("{label}");
        }
        println!();
    }
}
