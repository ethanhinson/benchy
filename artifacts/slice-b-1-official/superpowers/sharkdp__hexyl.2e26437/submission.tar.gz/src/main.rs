mod chars;
mod colors;
mod display;
mod parse;

use std::fs::File;
use std::io::{self, Read, Seek, SeekFrom};
use std::path::PathBuf;
use std::process;

use clap::{CommandFactory, Parser, ValueEnum};
use clap_complete::{generate, Shell};
use terminal_size::{terminal_size, Width};

use chars::CharacterTable;
use colors::{print_color_table, ColorWhen, Colors, SchemeKind};
use display::{Base, BorderStyle, DisplayOptions, Endianness};
use parse::{parse_byte_count, ParseContext};

#[derive(Debug, Clone, Copy, ValueEnum)]
enum ColorWhenArg {
    Always,
    Auto,
    Never,
    Force,
}

impl From<ColorWhenArg> for ColorWhen {
    fn from(v: ColorWhenArg) -> Self {
        match v {
            ColorWhenArg::Always => ColorWhen::Always,
            ColorWhenArg::Auto => ColorWhen::Auto,
            ColorWhenArg::Never => ColorWhen::Never,
            ColorWhenArg::Force => ColorWhen::Force,
        }
    }
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum BorderArg {
    Unicode,
    Ascii,
    None,
}

impl From<BorderArg> for BorderStyle {
    fn from(v: BorderArg) -> Self {
        match v {
            BorderArg::Unicode => BorderStyle::Unicode,
            BorderArg::Ascii => BorderStyle::Ascii,
            BorderArg::None => BorderStyle::None,
        }
    }
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum CharacterTableArg {
    Default,
    Ascii,
    #[value(name = "codepage-1047")]
    Codepage1047,
    #[value(name = "codepage-437")]
    Codepage437,
    Braille,
}

impl From<CharacterTableArg> for CharacterTable {
    fn from(v: CharacterTableArg) -> Self {
        match v {
            CharacterTableArg::Default => CharacterTable::Default,
            CharacterTableArg::Ascii => CharacterTable::Ascii,
            CharacterTableArg::Codepage1047 => CharacterTable::Codepage1047,
            CharacterTableArg::Codepage437 => CharacterTable::Codepage437,
            CharacterTableArg::Braille => CharacterTable::Braille,
        }
    }
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum ColorSchemeArg {
    Default,
    Gradient,
}

impl From<ColorSchemeArg> for SchemeKind {
    fn from(v: ColorSchemeArg) -> Self {
        match v {
            ColorSchemeArg::Default => SchemeKind::Default,
            ColorSchemeArg::Gradient => SchemeKind::Gradient,
        }
    }
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum EndiannessArg {
    Little,
    Big,
}

impl From<EndiannessArg> for Endianness {
    fn from(v: EndiannessArg) -> Self {
        match v {
            EndiannessArg::Little => Endianness::Little,
            EndiannessArg::Big => Endianness::Big,
        }
    }
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum BaseArg {
    Binary,
    Octal,
    Decimal,
    Hexadecimal,
}

impl From<BaseArg> for Base {
    fn from(v: BaseArg) -> Self {
        match v {
            BaseArg::Binary => Base::Binary,
            BaseArg::Octal => Base::Octal,
            BaseArg::Decimal => Base::Decimal,
            BaseArg::Hexadecimal => Base::Hexadecimal,
        }
    }
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum GroupSizeArg {
    #[value(name = "1")]
    One,
    #[value(name = "2")]
    Two,
    #[value(name = "4")]
    Four,
    #[value(name = "8")]
    Eight,
}

impl From<GroupSizeArg> for usize {
    fn from(v: GroupSizeArg) -> Self {
        match v {
            GroupSizeArg::One => 1,
            GroupSizeArg::Two => 2,
            GroupSizeArg::Four => 4,
            GroupSizeArg::Eight => 8,
        }
    }
}

#[derive(Parser, Debug)]
#[command(name = "hexyl", version = "0.16.0", about = "A command-line hex viewer")]
struct Args {
    #[arg(value_name = "FILE")]
    file: Option<PathBuf>,

    #[arg(short = 'n', long = "length", alias = "bytes", short_aliases = ['l', 'c'])]
    length: Option<String>,

    #[arg(short = 's', long = "skip")]
    skip: Option<String>,

    #[arg(long = "block-size", default_value = "512")]
    block_size: String,

    #[arg(short = 'v', long = "no-squeezing")]
    no_squeezing: bool,

    #[arg(long = "color", default_value = "always", value_enum)]
    color: ColorWhenArg,

    #[arg(long = "border", default_value = "unicode", value_enum)]
    border: BorderArg,

    #[arg(short = 'p', long = "plain")]
    plain: bool,

    #[arg(long = "no-characters")]
    no_characters: bool,

    #[arg(short = 'C', long = "characters")]
    characters: bool,

    #[arg(long = "character-table", default_value = "default", value_enum)]
    character_table: CharacterTableArg,

    #[arg(long = "color-scheme", default_value = "default", value_enum)]
    color_scheme: ColorSchemeArg,

    #[arg(short = 'P', long = "no-position")]
    no_position: bool,

    #[arg(short = 'o', long = "display-offset", default_value = "0")]
    display_offset: String,

    #[arg(long = "panels", default_value = "2")]
    panels: String,

    #[arg(short = 'g', long = "group-size", alias = "groupsize", default_value = "1", value_enum)]
    group_size: GroupSizeArg,

    #[arg(long = "endianness", default_value = "big", value_enum)]
    endianness: EndiannessArg,

    #[arg(short = 'e')]
    little_endian: bool,

    #[arg(short = 'b', long = "base", default_value = "hexadecimal", value_enum)]
    base: BaseArg,

    #[arg(long = "terminal-width")]
    terminal_width: Option<String>,

    #[arg(long = "print-color-table")]
    print_color_table: bool,

    #[arg(short = 'i', long = "include")]
    include: bool,

    #[arg(long = "completion")]
    completion: Option<Shell>,
}

fn main() {
    let args = Args::parse();
    if let Some(shell) = args.completion {
        let mut cmd = Args::command();
        generate(shell, &mut cmd, "hexyl", &mut io::stdout());
        return;
    }

    if args.print_color_table {
        let scheme: SchemeKind = args.color_scheme.into();
        let colors = Colors::from_env(scheme);
        let color_when: ColorWhen = args.color.into();
        let enabled = color_when.effective(atty::is(atty::Stream::Stdout));
        print_color_table(&colors, enabled);
        return;
    }

    if let Err(e) = run(args) {
        eprintln!("Error: {e}");
        process::exit(1);
    }
}

fn run(args: Args) -> Result<(), Box<dyn std::error::Error>> {
    let block_size = parse_u64(&args.block_size, 512, "block-size")?;

    let skip_amount = if let Some(skip_s) = &args.skip {
        parse_byte_count(skip_s, block_size, ParseContext::Skip)
            .map_err(|e| format!("failed to parse `--skip` arg \"{skip_s}\" as byte count\n\nCaused by:\n    {e}"))?
    } else {
        0
    };

    let data = read_input(&args, block_size, skip_amount)?;

    let scheme: SchemeKind = args.color_scheme.into();
    let colors = Colors::from_env(scheme);
    let stdout_tty = atty::is(atty::Stream::Stdout);
    let color_when: ColorWhen = args.color.into();

    let mut border: BorderStyle = args.border.into();
    let mut show_characters = !args.no_characters;
    let mut show_position = !args.no_position;
    let mut color = color_when;
    if args.plain {
        border = BorderStyle::None;
        show_characters = false;
        show_position = false;
        color = ColorWhen::Never;
    }

    let num_panels = resolve_panels(&args.panels, args.terminal_width.as_deref(), block_size)?;

    let mut base_offset = parse_byte_count(&args.display_offset, block_size, ParseContext::DisplayOffset)
        .map_err(|e| format!("failed to parse `--display-offset` arg \"{}\" as byte count\n\nCaused by:\n    {e}", args.display_offset))?
        .max(0) as u64;

    let skip_offset = if skip_amount >= 0 {
        skip_amount as u64
    } else if let Some(path) = &args.file {
        let len = std::fs::metadata(path)?.len() as i64;
        (len + skip_amount).max(0) as u64
    } else {
        0
    };

    let display_offset = base_offset + skip_offset;

    let include_name = args
        .file
        .as_ref()
        .and_then(|p| p.to_str())
        .unwrap_or("stdin")
        .to_string();

    let endianness = if args.little_endian {
        Endianness::Little
    } else {
        args.endianness.into()
    };

    let opts = DisplayOptions {
        show_position,
        show_characters,
        border,
        colors_enabled: if args.plain { false } else { color.effective(stdout_tty) },
        colors,
        char_table: args.character_table.into(),
        group_size: args.group_size.into(),
        endianness,
        base: args.base.into(),
        num_panels,
        display_offset,
        squeeze: !args.no_squeezing && !args.include,
        include_style: args.include,
        include_name,
    };

    display::display_data(&data, &opts, &mut io::stdout())?;
    Ok(())
}

fn parse_u64(s: &str, default: u64, name: &str) -> Result<u64, String> {
    if s.is_empty() {
        return Ok(default);
    }
    s.parse().map_err(|_| format!("invalid {name} value"))
}

fn resolve_panels(
    panels: &str,
    terminal_width: Option<&str>,
    block_size: u64,
) -> Result<usize, Box<dyn std::error::Error>> {
    if let Some(tw) = terminal_width {
        let width: usize = if tw.chars().all(|c| c.is_ascii_digit()) {
            tw.parse()?
        } else {
            parse_byte_count(tw, block_size, ParseContext::Length)? as usize
        };
        // Approximate panels from width
        let panel_width = 35;
        let max_panels = (width / panel_width).max(1);
        return Ok(max_panels.min(2).max(1));
    }

    if panels == "auto" {
        let width = terminal_size()
            .map(|(Width(w), _)| w as usize)
            .unwrap_or(80);
        if width >= 120 {
            Ok(2)
        } else {
            Ok(1)
        }
    } else {
        let n: usize = panels.parse()?;
        Ok(n.max(1))
    }
}

fn read_input(args: &Args, block_size: u64, skip_amount: i64) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
    let length = if let Some(len_s) = &args.length {
        Some(parse_byte_count(len_s, block_size, ParseContext::Length)
            .map_err(|e| format!("failed to parse `--length` arg \"{len_s}\" as byte count\n\nCaused by:\n    {e}"))?)
    } else {
        None
    };

    if let Some(path) = &args.file {
        let mut file = File::open(path)?;
        if skip_amount != 0 {
            if skip_amount < 0 {
                let len = file.metadata()?.len() as i64;
                let pos = len + skip_amount;
                if pos < 0 {
                    return Ok(Vec::new());
                }
                file.seek(SeekFrom::Start(pos as u64))?;
            } else {
                file.seek(SeekFrom::Start(skip_amount as u64))?;
            }
        }
        read_bytes(&mut file, length)
    } else {
        if skip_amount != 0 {
            return Err("skip on stdin is not supported".into());
        }
        read_bytes(&mut io::stdin(), length)
    }
}

fn read_bytes(reader: &mut dyn Read, length: Option<i64>) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
    let mut data = Vec::new();
    if let Some(len) = length {
        if len < 0 {
            return Err("negative length is not supported".into());
        }
        let mut buf = vec![0u8; len as usize];
        let n = reader.read(&mut buf)?;
        data.extend_from_slice(&buf[..n]);
    } else {
        reader.read_to_end(&mut data)?;
    }
    Ok(data)
}

// Minimal atty check without extra dependency
mod atty {
    pub enum Stream {
        Stdout,
    }

    pub fn is(_: Stream) -> bool {
        unsafe { libc::isatty(libc::STDOUT_FILENO) != 0 }
    }
}
