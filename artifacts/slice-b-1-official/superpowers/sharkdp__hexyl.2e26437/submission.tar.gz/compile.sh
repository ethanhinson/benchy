#!/bin/sh
set -eu

cd "$(dirname "$0")"
cargo build --release
cp target/release/hexyl ./candidate
cp -f ./candidate ./executable
