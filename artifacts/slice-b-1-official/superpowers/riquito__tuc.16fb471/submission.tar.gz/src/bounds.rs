use std::fmt;

#[derive(Debug, Clone)]
pub enum FieldSpec {
    Single(i64, Option<String>),
    Range(i64, Option<i64>, Option<String>),
}

#[derive(Debug, Clone)]
pub enum BoundsList {
    Fields(Vec<FieldSpec>),
    Format(String),
}

#[derive(Debug, Clone)]
pub struct OutputSegment {
    pub parts: Vec<String>,
    pub is_range: bool,
}

#[derive(Debug)]
pub struct ParseError {
    pub message: String,
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.message)
    }
}

fn parse_number(s: &str) -> Result<i64, ParseError> {
    s.parse::<i64>().map_err(|_| ParseError {
        message: format!("Not a number `{s}`"),
    })
}

fn parse_field_spec(part: &str) -> Result<FieldSpec, ParseError> {
    let (spec, fallback) = if let Some((left, fb)) = part.split_once('=') {
        (left, Some(fb.to_string()))
    } else {
        (part, None)
    };

    if let Some((start, end)) = spec.split_once(':') {
        let left = parse_number(start)?;
        let right = if end.is_empty() {
            None
        } else {
            Some(parse_number(end)?)
        };
        if let Some(r) = right {
            if left > r {
                return Err(ParseError {
                    message: format!("Field left value cannot be greater than right value"),
                });
            }
        }
        Ok(FieldSpec::Range(left, right, fallback))
    } else {
        Ok(FieldSpec::Single(parse_number(spec)?, fallback))
    }
}

pub fn parse_bounds(input: &str) -> Result<BoundsList, ParseError> {
    if input.contains('{') {
        return Ok(BoundsList::Format(input.to_string()));
    }

    if input.is_empty() {
        return Err(ParseError {
            message: "UserBoundsList must contain at least one UserBounds".to_string(),
        });
    }

    let mut specs = Vec::new();
    for part in input.split(',') {
        specs.push(parse_field_spec(part.trim())?);
    }
    Ok(BoundsList::Fields(specs))
}

pub fn resolve_index(index: i64, count: i64) -> Option<i64> {
    if count == 0 {
        return None;
    }
    let resolved = if index < 0 {
        count + index + 1
    } else {
        index
    };
    if resolved < 1 || resolved > count {
        None
    } else {
        Some(resolved)
    }
}

pub fn build_segments(
    specs: &[FieldSpec],
    items: &[String],
    count: i64,
    generic_fallback: Option<&str>,
) -> Result<Vec<OutputSegment>, String> {
    let mut out = Vec::new();
    for spec in specs {
        match spec {
            FieldSpec::Single(idx, fb) => {
                let fallback = fb.as_deref().or(generic_fallback);
                match resolve_index(*idx, count) {
                    Some(r) => out.push(OutputSegment {
                        parts: vec![items[r as usize - 1].clone()],
                        is_range: false,
                    }),
                    None => {
                        if let Some(fb) = fallback {
                            out.push(OutputSegment {
                                parts: vec![fb.to_string()],
                                is_range: false,
                            });
                        } else {
                            return Err(format!("Out of bounds: {idx}"));
                        }
                    }
                }
            }
            FieldSpec::Range(start, end, fb) => {
                let fallback = fb.as_deref().or(generic_fallback);
                let rs = resolve_index(*start, count);
                let re = match end {
                    Some(e) => resolve_index(*e, count),
                    None => Some(count),
                };
                match (rs, re) {
                    (Some(s), Some(e)) if s <= e => {
                        let mut parts = Vec::new();
                        for i in s..=e {
                            parts.push(items[i as usize - 1].clone());
                        }
                        out.push(OutputSegment {
                            parts,
                            is_range: true,
                        });
                    }
                    _ => {
                        if let Some(fb) = fallback {
                            out.push(OutputSegment {
                                parts: vec![fb.to_string()],
                                is_range: false,
                            });
                        } else if rs.is_none() {
                            return Err(format!("Out of bounds: {start}"));
                        } else {
                            return Err(format!("Out of bounds: {}", end.unwrap_or(-1)));
                        }
                    }
                }
            }
        }
    }
    Ok(out)
}

pub fn complement_specs(
    specs: &[FieldSpec],
    count: i64,
) -> Result<Vec<FieldSpec>, String> {
    let mut keep = vec![false; count as usize];
    for spec in specs {
        match spec {
            FieldSpec::Single(idx, _) => {
                if let Some(r) = resolve_index(*idx, count) {
                    keep[r as usize - 1] = true;
                } else {
                    return Err(format!("Out of bounds: {idx}"));
                }
            }
            FieldSpec::Range(start, end, _) => {
                let rs = resolve_index(*start, count)
                    .ok_or_else(|| format!("Out of bounds: {start}"))?;
                let re = match end {
                    Some(e) => resolve_index(*e, count)
                        .ok_or_else(|| format!("Out of bounds: {e}"))?,
                    None => count,
                };
                for i in rs..=re {
                    keep[i as usize - 1] = true;
                }
            }
        }
    }
    let mut out = Vec::new();
    for (i, &k) in keep.iter().enumerate() {
        if !k {
            out.push(FieldSpec::Single((i + 1) as i64, None));
        }
    }
    Ok(out)
}

pub fn assemble_segments(segments: &[OutputSegment], join: bool, delimiter: &str) -> String {
    if join {
        let mut flat = Vec::new();
        for seg in segments {
            flat.extend(seg.parts.clone());
        }
        return flat.join(delimiter);
    }

    let mut out = String::new();
    for seg in segments {
        if seg.is_range {
            out.push_str(&seg.parts.join(delimiter));
        } else {
            out.push_str(&seg.parts.concat());
        }
    }
    out
}
