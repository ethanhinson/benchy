mod bounds;
mod format;
mod split;

use bounds::{assemble_segments, build_segments, complement_specs, parse_bounds, BoundsList, FieldSpec};
use format::render_format;
use regex::Regex;
use split::{json_array, split_fields, split_lines, trim_delimiter};
use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read};
use std::process;

const SHORT_HELP: &str = r#"tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\0), not LF (\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
                                  Use colon (:) to match a range (inclusive).
                                  Use equal (=) to apply out of bound fallback.
                                  Fields can be negative (-1 is the last field).
                                  [default: 1:]

                                  e.g. cutting the string 'a-b-c-d' on '-'
                                    -f 1     => a
                                    -f 1:    => a-b-c-d
                                    -f 1:3   => a-b-c
                                    -f 3,2   => cb
                                    -f 3,1:2 => ca-b
                                    -f -3:-2 => b-c
                                    -f 1,8=fallback => afallback

                                  To re-apply the delimiter add -j, to replace
                                  it add -r (followed by the new delimiter).

                                  You can also format the output using {} syntax
                                  e.g.
                                    -f '({1}, {2})' => (a, b)

                                  You can escape { and } using {{ and }}.

    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
                                  Implies --join. To merge lines, use --no-join
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
                                  Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
                                  It's overridden by any fallback assigned to a
                                  specific field (see -f for help)
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
                                  This allows to read lines arbitrarily large.
                                  Works only with single-byte delimiters,
                                  fields in ascending order, -z, -j, -r

Options precedence:
    --trim and --compress-delimiter are applied before --fields or similar

Memory consumption:
    --characters and --fields read and allocate memory one line at a time

    --lines allocate memory one line at a time as long as the requested fields
    are ordered and non-negative (e.g. -l 1,3:4,4,7), otherwise it allocates
    the whole input in memory (it also happens when -p or -m are being used)

    --bytes allocate the whole input in memory

    --fixed-memory will read the input in chunks of <size> kilobytes. This
    allows to read lines arbitrarily large. Works only with single-byte
    delimiters, fields in ascending order, -z, -j, -r
"#;

const BANNER: &str = r#"tuc 1.3.0 - Created by Riccardo Attilio Galli

Cut text (or bytes) where a delimiter matches, then keep the desired parts.

Some examples:

    $ echo "a/b/c" | tuc -d / -f 1,-1
    ac

    $ echo "a/b/c" | tuc -d / -f 2:
    b/c

    $ echo "hello.bak" | tuc -d . -f 'mv {1:} {1}'
    mv hello.bak hello

    $ printf "a\nb\nc\nd\ne" | tuc -l 2:-2
    b
    c
    d

Run `tuc --help` for more detailed information.
Send bug reports to: https://github.com/riquito/tuc/issues
"#;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Mode {
    Fields,
    Bytes,
    Characters,
    Lines,
}

struct Config {
    mode: Mode,
    bounds_raw: String,
    delimiter: String,
    regex: Option<String>,
    greedy: bool,
    compress: bool,
    only_delimited: bool,
    zero_terminated: bool,
    complement: bool,
    join: Option<bool>,
    json: bool,
    replace_delimiter: Option<String>,
    trim: Option<char>,
    fallback_oob: Option<String>,
    input_path: Option<String>,
    show_help: bool,
    show_version: bool,
    explicit_bounds: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            mode: Mode::Fields,
            bounds_raw: "1:".to_string(),
            delimiter: "\t".to_string(),
            regex: None,
            greedy: false,
            compress: false,
            only_delimited: false,
            zero_terminated: false,
            complement: false,
            join: None,
            json: false,
            replace_delimiter: None,
            trim: None,
            fallback_oob: None,
            input_path: None,
            show_help: false,
            show_version: false,
            explicit_bounds: false,
        }
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let config = match parse_args(&args[1..]) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("{e}");
            process::exit(1);
        }
    };

    if config.show_version {
        println!("tuc 1.3.0");
        return;
    }
    if config.show_help {
        print!("{SHORT_HELP}");
        return;
    }

    let bounds = match parse_bounds(&config.bounds_raw) {
        Ok(b) => b,
        Err(e) => {
            eprintln!("failed to parse '{}': {}", config.bounds_raw, e.message);
            process::exit(1);
        }
    };

    let regex = if let Some(ref pat) = config.regex {
        match Regex::new(pat) {
            Ok(r) => Some(r),
            Err(e) => {
                eprintln!("Invalid regex: {e}");
                process::exit(1);
            }
        }
    } else {
        None
    };

    let join = resolve_join(&config);
    let output_delim = config
        .replace_delimiter
        .as_deref()
        .unwrap_or(&config.delimiter);

    if !config.explicit_bounds
        && config.input_path.is_none()
        && io::stdin().is_terminal()
    {
        print!("{BANNER}");
        return;
    }

    let input = match read_input(&config) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("{e}");
            process::exit(1);
        }
    };

    if let Err(e) = process_all(
        &input,
        &config,
        bounds,
        regex.as_ref(),
        join,
        output_delim,
    ) {
        eprintln!("Error: {e}");
        process::exit(1);
    }
}

fn parse_args(args: &[String]) -> Result<Config, String> {
    let mut config = Config::default();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-g" | "--greedy-delimiter" => config.greedy = true,
            "-p" | "--compress-delimiter" => config.compress = true,
            "-s" | "--only-delimited" => config.only_delimited = true,
            "-V" | "--version" => config.show_version = true,
            "-z" | "--zero-terminated" => config.zero_terminated = true,
            "-h" | "--help" => config.show_help = true,
            "-m" | "--complement" => config.complement = true,
            "-j" | "--join" => config.join = Some(true),
            "--no-join" | "--nojoin" => config.join = Some(false),
            "--json" => config.json = true,
            "--no-mmap" => {}
            "-f" | "--fields" => {
                config.mode = Mode::Fields;
                config.bounds_raw = next_value(args, &mut i, "-f")?;
                config.explicit_bounds = true;
            }
            "-b" | "--bytes" => {
                config.mode = Mode::Bytes;
                config.bounds_raw = next_value(args, &mut i, "-b")?;
                config.explicit_bounds = true;
            }
            "-c" | "--characters" => {
                config.mode = Mode::Characters;
                config.bounds_raw = next_value(args, &mut i, "-c")?;
                config.explicit_bounds = true;
            }
            "-l" | "--lines" => {
                config.mode = Mode::Lines;
                config.bounds_raw = next_value(args, &mut i, "-l")?;
                config.explicit_bounds = true;
            }
            "-d" | "--delimiter" => config.delimiter = next_value(args, &mut i, "-d")?,
            "-e" | "--regex" => config.regex = Some(next_value(args, &mut i, "-e")?),
            "-r" | "--replace-delimiter" => {
                config.replace_delimiter = Some(next_value(args, &mut i, "-r")?);
            }
            "-t" | "--trim" => {
                let v = next_value(args, &mut i, "-t")?;
                let c = v
                    .chars()
                    .next()
                    .ok_or_else(|| "trim type required".to_string())?;
                config.trim = Some(c);
            }
            "--fallback-oob" => {
                config.fallback_oob = Some(next_value(args, &mut i, "--fallback-oob")?);
            }
            "-M" | "--fixed-memory" => {
                let _ = next_value(args, &mut i, "-M")?;
            }
            other if other.starts_with('-') => {
                return Err(format!("unexpected argument: {other}"));
            }
            path => {
                config.input_path = Some(path.to_string());
            }
        }
        i += 1;
    }
    Ok(config)
}

fn next_value(args: &[String], i: &mut usize, flag: &str) -> Result<String, String> {
    *i += 1;
    args.get(*i)
        .cloned()
        .ok_or_else(|| format!("missing value for {flag}"))
}

fn resolve_join(config: &Config) -> bool {
    if let Some(j) = config.join {
        return j;
    }
    if config.replace_delimiter.is_some() {
        return true;
    }
    config.mode == Mode::Lines
}

fn read_input(config: &Config) -> Result<String, String> {
    if let Some(ref path) = config.input_path {
        fs::read_to_string(path).map_err(|e| e.to_string())
    } else {
        let mut buf = String::new();
        io::stdin()
            .read_to_string(&mut buf)
            .map_err(|e| e.to_string())?;
        Ok(buf)
    }
}

fn process_all(
    input: &str,
    config: &Config,
    bounds: BoundsList,
    regex: Option<&Regex>,
    join: bool,
    output_delim: &str,
) -> Result<(), String> {
    match config.mode {
        Mode::Bytes => process_bytes(input, config, bounds, join, output_delim),
        Mode::Characters => process_characters(input, config, bounds, join, output_delim),
        Mode::Lines => process_lines(input, config, bounds, join, output_delim),
        Mode::Fields => process_fields(input, config, bounds, regex, join, output_delim),
    }
}

fn process_fields(
    input: &str,
    config: &Config,
    bounds: BoundsList,
    regex: Option<&Regex>,
    join: bool,
    output_delim: &str,
) -> Result<(), String> {
    if config.zero_terminated {
        for record in input.split('\0') {
            if record.is_empty() {
                continue;
            }
            emit_field_record(record, config, &bounds, regex, join, output_delim)?;
        }
        return Ok(());
    }

    if input.is_empty() {
        return Ok(());
    }

    for line in input.split_inclusive('\n') {
        let line = line.strip_suffix('\n').unwrap_or(line);
        emit_field_record(line, config, &bounds, regex, join, output_delim)?;
    }
    Ok(())
}

fn emit_field_record(
    line: &str,
    config: &Config,
    bounds: &BoundsList,
    regex: Option<&Regex>,
    join: bool,
    output_delim: &str,
) -> Result<(), String> {
    if config.only_delimited {
        let has = regex
            .map(|re| re.is_match(line))
            .unwrap_or_else(|| line.contains(&config.delimiter));
        if !has {
            return Ok(());
        }
    }
    let out = process_single(line, config, bounds, regex, join, output_delim)?;
    println!("{out}");
    Ok(())
}

fn process_lines(
    input: &str,
    config: &Config,
    bounds: BoundsList,
    join: bool,
    output_delim: &str,
) -> Result<(), String> {
    let lines = split_lines(input, config.zero_terminated);
    let count = lines.len() as i64;
    let generic = config.fallback_oob.as_deref();

    let field_specs = match &bounds {
        BoundsList::Fields(v) => {
            if config.complement {
                complement_specs(v, count)?
            } else {
                normalize_line_specs(v)
            }
        }
        BoundsList::Format(t) => {
            let out = render_format(t, &lines, count, generic, output_delim)?;
            print!("{out}");
            if join {
                println!();
            }
            return Ok(());
        }
    };

    let line_delim = "\n";
    let segments = build_segments(&field_specs, &lines, count, generic)?;

    if config.join == Some(false) {
        for seg in &segments {
            for part in &seg.parts {
                print!("{part}");
            }
        }
        println!();
        return Ok(());
    }

    let out = assemble_segments(&segments, join, line_delim);
    if out.is_empty() {
        println!();
    } else if out.ends_with('\n') {
        print!("{out}");
    } else {
        println!("{out}");
    }
    Ok(())
}

fn normalize_line_specs(specs: &[FieldSpec]) -> Vec<FieldSpec> {
    if specs.len() == 1 {
        if let FieldSpec::Single(-1, fb) = &specs[0] {
            return vec![FieldSpec::Range(1, Some(-1), fb.clone())];
        }
    }
    specs.to_vec()
}

fn process_bytes(
    input: &str,
    config: &Config,
    bounds: BoundsList,
    join: bool,
    output_delim: &str,
) -> Result<(), String> {
    let data = input.trim_end_matches('\n').as_bytes();
    let count = data.len() as i64;
    let generic = config.fallback_oob.as_deref();

    match &bounds {
        BoundsList::Format(t) => {
            let items: Vec<String> = data
                .iter()
                .map(|&b| String::from(b as char))
                .collect();
            let out = render_format(t, &items, count, generic, output_delim)?;
            println!("{out}");
            return Ok(());
        }
        BoundsList::Fields(specs) => {
            let field_specs = if config.complement {
                complement_specs(specs, count)?
            } else {
                specs.clone()
            };

            let items = byte_items(data);
            let segments = build_segments(&field_specs, &items, count, generic)?;
            if !join
                && field_specs.len() == 1
                && matches!(field_specs[0], FieldSpec::Range(_, _, _))
            {
                if let FieldSpec::Range(start, end, fb) = &field_specs[0] {
                    let fallback = fb.as_deref().or(generic);
                    let rs = bounds::resolve_index(*start, count);
                    let re = match end {
                        Some(e) => bounds::resolve_index(*e, count),
                        None => Some(count),
                    };
                    match (rs, re) {
                        (Some(s), Some(e)) => {
                            let slice = &data[s as usize - 1..e as usize];
                            print!("{}", String::from_utf8_lossy(slice));
                            println!();
                            return Ok(());
                        }
                        _ => {
                            if let Some(fb) = fallback {
                                println!("{fb}");
                                return Ok(());
                            }
                            return Err(format!("Out of bounds: {start}"));
                        }
                    }
                }
            }
            let out = assemble_segments(&segments, join, output_delim);
            println!("{out}");
        }
    }
    Ok(())
}

fn byte_items(data: &[u8]) -> Vec<String> {
    data.iter().map(|&b| String::from(b as char)).collect()
}

fn process_characters(
    input: &str,
    config: &Config,
    bounds: BoundsList,
    join: bool,
    output_delim: &str,
) -> Result<(), String> {
    if input.is_empty() {
        return Ok(());
    }
    for line in input.split_inclusive('\n') {
        let line = line.strip_suffix('\n').unwrap_or(line);
        let units: Vec<String> = line.chars().map(|c| c.to_string()).collect();
        let count = units.len() as i64;
        let generic = config.fallback_oob.as_deref();
        match &bounds {
            BoundsList::Format(t) => {
                let out = render_format(t, &units, count, generic, output_delim)?;
                println!("{out}");
            }
            BoundsList::Fields(specs) => {
                let field_specs = if config.complement {
                    complement_specs(specs, count)?
                } else {
                    specs.clone()
                };
                let segments = build_segments(&field_specs, &units, count, generic)?;
                let out = assemble_segments(&segments, join, output_delim);
                println!("{out}");
            }
        }
    }
    Ok(())
}

fn process_single(
    line: &str,
    config: &Config,
    bounds: &BoundsList,
    regex: Option<&Regex>,
    join: bool,
    output_delim: &str,
) -> Result<String, String> {
    let trimmed = trim_delimiter(line, &config.delimiter, config.trim);
    let parts = split_fields(
        &trimmed,
        &config.delimiter,
        regex,
        config.greedy,
        config.compress,
    );
    let count = parts.len() as i64;
    let generic = config.fallback_oob.as_deref();

    if config.json {
        return Ok(json_array(&parts));
    }

    match bounds {
        BoundsList::Format(template) => {
            render_format(template, &parts, count, generic, output_delim)
        }
        BoundsList::Fields(specs) => {
            let field_specs = if config.complement {
                complement_specs(specs, count)?
            } else {
                specs.clone()
            };
            let segments = build_segments(&field_specs, &parts, count, generic)?;
            Ok(assemble_segments(&segments, join, output_delim))
        }
    }
}
