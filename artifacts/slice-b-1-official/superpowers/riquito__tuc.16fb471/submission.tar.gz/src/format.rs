use crate::bounds::resolve_index;

pub fn render_format(
    template: &str,
    items: &[String],
    count: i64,
    generic_fallback: Option<&str>,
    delimiter: &str,
) -> Result<String, String> {
    let mut out = String::new();
    let chars: Vec<char> = template.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '{' {
            if i + 1 < chars.len() && chars[i + 1] == '{' {
                out.push('{');
                i += 2;
                continue;
            }
            let start = i + 1;
            let mut j = start;
            while j < chars.len() && chars[j] != '}' {
                j += 1;
            }
            if j >= chars.len() {
                return Err(format!(
                    "failed to parse '{template}': unclosed placeholder"
                ));
            }
            let inner: String = chars[start..j].iter().collect();
            out.push_str(&resolve_format_ref(
                &inner,
                items,
                count,
                generic_fallback,
                delimiter,
            )?);
            i = j + 1;
            continue;
        }
        if chars[i] == '}' {
            if i + 1 < chars.len() && chars[i + 1] == '}' {
                out.push('}');
                i += 2;
                continue;
            }
            return Err(format!(
                "failed to parse '{template}': unexpected '}}'"
            ));
        }
        if chars[i] == '\\' && i + 1 < chars.len() && chars[i + 1] == 'n' {
            out.push('\n');
            i += 2;
            continue;
        }
        out.push(chars[i]);
        i += 1;
    }
    Ok(out)
}

fn resolve_format_ref(
    inner: &str,
    items: &[String],
    count: i64,
    generic_fallback: Option<&str>,
    delimiter: &str,
) -> Result<String, String> {
    if let Some((start, end)) = inner.split_once(':') {
        let left = parse_format_number(start)?;
        let rs = resolve_index(left, count).ok_or_else(|| format!("Out of bounds: {left}"))?;
        let re = if end.is_empty() {
            count
        } else {
            resolve_index(parse_format_number(end)?, count)
                .ok_or_else(|| format!("Out of bounds: {end}"))?
        };
        if rs > re {
            return Err(format!(
                "failed to parse '{{{inner}}}': Field left value cannot be greater than right value"
            ));
        }
        let mut out = String::new();
        for idx in rs..=re {
            if !out.is_empty() {
                out.push_str(delimiter);
            }
            out.push_str(field_at(items, idx as usize));
        }
        return Ok(out);
    }

    match parse_format_number(inner) {
        Ok(idx) => match resolve_index(idx, count) {
            Some(r) => Ok(field_at(items, r as usize).to_string()),
            None => {
                if let Some(fb) = generic_fallback {
                    Ok(fb.to_string())
                } else {
                    Err(format!("Out of bounds: {idx}"))
                }
            }
        },
        Err(e) => Err(format!("failed to parse '{{{inner}}}': {e}")),
    }
}

fn parse_format_number(s: &str) -> Result<i64, String> {
    s.parse::<i64>().map_err(|_| format!("Not a number `{s}`"))
}

fn field_at<'a>(items: &'a [String], one_based: usize) -> &'a str {
    items
        .get(one_based.saturating_sub(1))
        .map(|s| s.as_str())
        .unwrap_or("")
}
