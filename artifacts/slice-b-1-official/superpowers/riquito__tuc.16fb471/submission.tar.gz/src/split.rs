use regex::Regex;

pub fn split_fields(
    line: &str,
    delimiter: &str,
    regex: Option<&Regex>,
    greedy: bool,
    compress: bool,
) -> Vec<String> {
    if compress {
        return split_compressed(line, delimiter, regex);
    }
    if greedy {
        return split_greedy(line, delimiter, regex);
    }
    split_plain(line, delimiter, regex)
}

fn split_plain(line: &str, delimiter: &str, regex: Option<&Regex>) -> Vec<String> {
    if let Some(re) = regex {
        return re.split(line).map(|s| s.to_string()).collect();
    }
    if delimiter.is_empty() {
        return vec![line.to_string()];
    }
    line.split(delimiter).map(|s| s.to_string()).collect()
}

fn split_greedy(line: &str, delimiter: &str, regex: Option<&Regex>) -> Vec<String> {
    if let Some(re) = regex {
        let pattern = format!("(?:{0})+", re.as_str());
        let merged = Regex::new(&pattern).expect("invalid greedy regex");
        return merged.split(line).map(|s| s.to_string()).collect();
    }
    if delimiter.is_empty() {
        return vec![line.to_string()];
    }
    let mut fields = Vec::new();
    let delim = delimiter.as_bytes();
    let mut start = 0;
    let mut i = 0;
    while i <= line.len() {
        if i < line.len() && line[i..].starts_with(delimiter) {
            fields.push(line[start..i].to_string());
            while i < line.len() && line[i..].starts_with(delimiter) {
                i += delim.len();
            }
            start = i;
        } else if i < line.len() {
            i += 1;
        } else {
            fields.push(line[start..i].to_string());
            break;
        }
    }
    fields
}

fn split_compressed(line: &str, delimiter: &str, regex: Option<&Regex>) -> Vec<String> {
    if let Some(re) = regex {
        let pattern = format!("(?:{0})+", re.as_str());
        let merged = Regex::new(&pattern).expect("invalid compress regex");
        let mut fields = Vec::new();
        let mut last = 0;
        for m in merged.find_iter(line) {
            fields.push(line[last..m.start()].to_string());
            last = m.end();
        }
        fields.push(line[last..].to_string());
        return fields;
    }

    if delimiter.is_empty() {
        return vec![line.to_string()];
    }

    let mut normalized = String::with_capacity(line.len());
    let delim = delimiter.as_bytes();
    let mut i = 0;
    while i < line.len() {
        if line[i..].starts_with(delimiter) {
            normalized.push_str(delimiter);
            i += delim.len();
            while i < line.len() && line[i..].starts_with(delimiter) {
                i += delim.len();
            }
        } else {
            normalized.push(line.as_bytes()[i] as char);
            i += 1;
        }
    }
    normalized
        .split(delimiter)
        .map(|s| s.to_string())
        .collect()
}

pub fn trim_delimiter(line: &str, delimiter: &str, trim: Option<char>) -> String {
    let Some(kind) = trim else {
        return line.to_string();
    };
    if delimiter.is_empty() {
        return line.to_string();
    }
    let upper = kind.to_ascii_uppercase();
    match upper {
        'L' => trim_end(line, delimiter, true, false),
        'R' => trim_end(line, delimiter, false, true),
        'B' => trim_end(line, delimiter, true, true),
        _ => line.to_string(),
    }
}

fn trim_end(line: &str, delimiter: &str, left: bool, right: bool) -> String {
    let mut result = line.to_string();
    if left {
        while result.starts_with(delimiter) {
            result = result[delimiter.len()..].to_string();
        }
    }
    if right {
        while result.ends_with(delimiter) {
            result = result[..result.len() - delimiter.len()].to_string();
        }
    }
    result
}

pub fn split_lines(input: &str, zero_terminated: bool) -> Vec<String> {
    if zero_terminated {
        return input.split('\0').map(|s| s.to_string()).collect();
    }
    if input.is_empty() {
        return Vec::new();
    }
    input
        .split_inclusive('\n')
        .map(|part| part.strip_suffix('\n').unwrap_or(part).to_string())
        .collect()
}

pub fn json_array(fields: &[String]) -> String {
    let mut out = String::from("[");
    for (i, field) in fields.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        out.push('"');
        for ch in field.chars() {
            match ch {
                '"' => out.push_str("\\\""),
                '\\' => out.push_str("\\\\"),
                '\n' => out.push_str("\\n"),
                '\r' => out.push_str("\\r"),
                '\t' => out.push_str("\\t"),
                c if c.is_control() => {
                    out.push_str(&format!("\\u{:04x}", c as u32));
                }
                c => out.push(c),
            }
        }
        out.push('"');
    }
    out.push(']');
    out
}
