use crate::colors::Colors;

const BYTES_PER_PANEL: usize = 8;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BorderStyle {
    Unicode,
    Ascii,
    None,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CharacterTable {
    Default,
    Ascii,
    Codepage1047,
    Codepage437,
    Braille,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Endianness {
    Little,
    Big,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Base {
    Binary,
    Octal,
    Decimal,
    Hexadecimal,
}

#[derive(Debug, Clone)]
pub struct RenderConfig {
    pub show_position: bool,
    pub show_characters: bool,
    pub border: BorderStyle,
    pub panels: PanelCount,
    pub group_size: usize,
    pub endianness: Endianness,
    pub base: Base,
    pub display_offset: u64,
    pub no_squeezing: bool,
    pub character_table: CharacterTable,
    pub colors: Colors,
}

#[derive(Debug, Clone)]
pub enum PanelCount {
    Fixed(usize),
    Auto,
}

struct LineLayout {
    char_column: Option<usize>,
    line_width: usize,
}

pub fn render(data: &[u8], config: &RenderConfig) -> String {
    let bytes_per_line = bytes_per_line(config);
    let panel_count = panel_count(config);
    let mut lines = Vec::new();

    for (line_idx, chunk) in data.chunks(bytes_per_line).enumerate() {
        let offset = config.display_offset + (line_idx as u64 * bytes_per_line as u64);
        lines.push(format_data_line(chunk, offset, panel_count, config));
    }

    if !config.no_squeezing {
        lines = apply_squeezing(lines, config, bytes_per_line);
    }

    match config.border {
        BorderStyle::None => lines.join("\n") + if lines.is_empty() { "" } else { "\n" },
        BorderStyle::Unicode | BorderStyle::Ascii => wrap_with_border(&lines, config),
    }
}

fn panel_count(config: &RenderConfig) -> usize {
    match config.panels {
        PanelCount::Fixed(n) => n,
        PanelCount::Auto => auto_panel_count(config),
    }
}

fn bytes_per_line(config: &RenderConfig) -> usize {
    panel_count(config) * BYTES_PER_PANEL
}

fn auto_panel_count(config: &RenderConfig) -> usize {
    let width = terminal_width().unwrap_or(80);
    let overhead = if config.show_position { 10 } else { 2 };
    let panel_width = 25;
    let char_width = if config.show_characters { 18 } else { 0 };
    let border_overhead = if config.border != BorderStyle::None { 6 } else { 0 };
    let available = width.saturating_sub(overhead + char_width + border_overhead);
    (available / panel_width).max(1)
}

fn terminal_width() -> Option<usize> {
    std::env::var("COLUMNS")
        .ok()
        .and_then(|v| v.parse().ok())
}

fn compute_layout(config: &RenderConfig, chunk_len: usize, panel_count: usize) -> LineLayout {
    if config.border != BorderStyle::None {
        return LineLayout {
            char_column: None,
            line_width: 0,
        };
    }

    if !config.show_characters {
        let width = if config.show_position { 62 } else { 53 };
        return LineLayout {
            char_column: None,
            line_width: width,
        };
    }

    if !config.show_position {
        return LineLayout {
            char_column: Some(if panel_count == 1 { 36 } else { 53 }),
            line_width: if panel_count == 1 { 45 } else { 71 },
        };
    }

    if panel_count == 1 {
        return LineLayout {
            char_column: Some(36),
            line_width: 45,
        };
    }

    match config.base {
        Base::Hexadecimal => {
            let gs = config.group_size.max(1);
            let char_column = 48 + 2 * (BYTES_PER_PANEL / gs - 1);
            LineLayout {
                char_column: Some(char_column),
                line_width: char_column + 18,
            }
        }
        Base::Binary => {
            let char_column = 11 + chunk_len * 9 + 1;
            LineLayout {
                char_column: Some(char_column),
                line_width: char_column + 9,
            }
        }
        Base::Octal | Base::Decimal => LineLayout {
            char_column: Some(11 + chunk_len * 4 + 1),
            line_width: 11 + chunk_len * 4 + 10,
        },
    }
}

fn apply_squeezing(lines: Vec<String>, config: &RenderConfig, bytes_per_line: usize) -> Vec<String> {
    if lines.is_empty() {
        return lines;
    }

    let mut result = Vec::new();
    let mut i = 0;

    while i < lines.len() {
        let current = &lines[i];
        let mut j = i + 1;
        while j < lines.len() && line_content_key(current) == line_content_key(&lines[j]) {
            j += 1;
        }

        result.push(current.clone());

        if j > i + 1 {
            if config.border == BorderStyle::None {
                let width = strip_ansi(current).len();
                result.push(format!(" *{}", " ".repeat(width.saturating_sub(2))));
                let end_offset = extract_offset(current, config) + (j - i) as u64 * bytes_per_line as u64;
                result.push(format_offset_only(end_offset, config, width));
            } else {
                result.push(border_star_line(config));
                let end_offset = extract_offset(current, config) + (j - i) as u64 * bytes_per_line as u64;
                result.push(border_offset_only_line(end_offset, config));
            }
            i = j;
        } else {
            i += 1;
        }
    }

    result
}

fn line_content_key(line: &str) -> String {
    let s = strip_ansi(line);
    if s.contains('|') || s.contains('│') {
        // Compare hex and character payload, ignoring offset column.
        let parts: Vec<&str> = s.split(|c| c == '|' || c == '│').collect();
        if parts.len() >= 4 {
            return parts[2..].join("|");
        }
        s.to_string()
    } else if s.len() > 11 {
        s[11..].trim_end().to_string()
    } else {
        s.trim_end().to_string()
    }
}

fn strip_ansi(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '\x1b' {
            while let Some(&nc) = chars.peek() {
                chars.next();
                if nc == 'm' {
                    break;
                }
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn extract_offset(line: &str, config: &RenderConfig) -> u64 {
    let stripped = strip_ansi(line);
    if config.border != BorderStyle::None {
        stripped
            .trim_start_matches('|')
            .chars()
            .take(8)
            .collect::<String>()
            .parse()
            .unwrap_or(0)
    } else if config.show_position {
        stripped.chars().skip(1).take(8).collect::<String>().parse().unwrap_or(0)
    } else {
        0
    }
}

fn format_offset_only(offset: u64, config: &RenderConfig, line_width: usize) -> String {
    if config.show_position {
        format!(" {:08x}{}", offset, " ".repeat(line_width.saturating_sub(9)))
    } else {
        " ".repeat(line_width)
    }
}

fn border_star_line(config: &RenderConfig) -> String {
    let ch = border_char(config);
    format!(
        "{0}*       {0}                         {0}                         {0}        {0}        {0}",
        ch
    )
}

fn border_offset_only_line(offset: u64, config: &RenderConfig) -> String {
    let ch = border_char(config);
    format!(
        "{0}{1:08x}{0}                         {0}                         {0}        {0}        {0}",
        ch, offset
    )
}

fn border_char(config: &RenderConfig) -> char {
    match config.border {
        BorderStyle::Unicode => '│',
        BorderStyle::Ascii => '|',
        BorderStyle::None => '|',
    }
}

fn format_data_line(chunk: &[u8], offset: u64, panel_count: usize, config: &RenderConfig) -> String {
    match config.border {
        BorderStyle::None => format_plain_line(chunk, offset, panel_count, config),
        BorderStyle::Unicode | BorderStyle::Ascii => format_bordered_line(chunk, offset, panel_count, config),
    }
}

fn format_plain_line(chunk: &[u8], offset: u64, panel_count: usize, config: &RenderConfig) -> String {
    let layout = compute_layout(config, chunk.len(), panel_count);
    let mut line = String::new();

    if config.show_position {
        line.push_str(&config.colors.offset.wrap(&format!(" {:08x}", offset), config.colors.enabled));
        line.push_str("  ");
    } else {
        line.push_str("  ");
    }

    line.push_str(&format_hex_section(chunk, panel_count, config));

    if let Some(char_col) = layout.char_column {
        let current = strip_ansi(&line).len();
        line.push_str(&" ".repeat(char_col.saturating_sub(current)));
        line.push_str(&format_char_section(chunk, panel_count, config));
        line.push(' ');
    }

    let current = strip_ansi(&line).len();
    if current < layout.line_width {
        line.push_str(&" ".repeat(layout.line_width - current));
    }

    line
}

fn format_hex_section(chunk: &[u8], panel_count: usize, config: &RenderConfig) -> String {
    let mut out = String::new();
    let effective_panels = if matches!(config.base, Base::Octal | Base::Decimal | Base::Binary)
        && chunk.len() <= BYTES_PER_PANEL
    {
        1
    } else {
        panel_count
    };

    for p in 0..effective_panels {
        if p > 0 {
            out.push_str("   ");
        }
        let start = p * BYTES_PER_PANEL;
        if start >= chunk.len() {
            continue;
        }
        let end = ((p + 1) * BYTES_PER_PANEL).min(chunk.len());
        out.push_str(&format_hex_panel(&chunk[start..end], config));
    }
    out
}

fn format_hex_panel(bytes: &[u8], config: &RenderConfig) -> String {
    let gs = config.group_size.max(1);
    let mut out = String::new();
    let mut i = 0;
    while i < bytes.len() {
        if i > 0 {
            out.push(' ');
        }
        let end = (i + gs).min(bytes.len());
        let group = &bytes[i..end];
        let text = format_group(group, config);
        out.push_str(&color_hex_group(group, &text, config));
        i += gs;
    }
    out
}

fn format_group(group: &[u8], config: &RenderConfig) -> String {
    if group.is_empty() {
        return String::new();
    }

    if config.group_size == 1 {
        return group
            .iter()
            .map(|b| format_single_value(*b, config.base))
            .collect::<Vec<_>>()
            .join(" ");
    }

    let mut val: u64 = 0;
    match config.endianness {
        Endianness::Big => {
            for &b in group {
                val = (val << 8) | b as u64;
            }
        }
        Endianness::Little => {
            for (idx, &b) in group.iter().enumerate() {
                val |= (b as u64) << (8 * idx);
            }
        }
    }
    let width = group.len() * 2;
    format!("{:0width$x}", val, width = width)
}

fn format_single_value(byte: u8, base: Base) -> String {
    match base {
        Base::Hexadecimal => format!("{:02x}", byte),
        Base::Binary => format!("{:08b}", byte),
        Base::Octal => format!("{:03o}", byte),
        Base::Decimal => format!("{:03}", byte),
    }
}

fn color_hex_group(group: &[u8], text: &str, config: &RenderConfig) -> String {
    if group.len() == 1 {
        config.colors.byte_color(group[0]).wrap(text, config.colors.enabled)
    } else {
        config.colors.byte_color(group[0]).wrap(text, config.colors.enabled)
    }
}

fn format_char_section(chunk: &[u8], panel_count: usize, config: &RenderConfig) -> String {
    let effective_panels = if matches!(config.base, Base::Octal | Base::Decimal | Base::Binary)
        && chunk.len() <= BYTES_PER_PANEL
    {
        1
    } else {
        panel_count
    };

    let mut out = String::new();
    for p in 0..effective_panels {
        if p > 0 {
            out.push(' ');
        }
        let start = p * BYTES_PER_PANEL;
        let end = ((p + 1) * BYTES_PER_PANEL).min(chunk.len());
        if start >= chunk.len() {
            out.push_str(&" ".repeat(BYTES_PER_PANEL));
            continue;
        }
        for &b in &chunk[start..end] {
            let ch = map_character(b, config.character_table);
            out.push_str(&config.colors.byte_color(b).wrap(&ch.to_string(), config.colors.enabled));
        }
        let visible = end - start;
        out.push_str(&" ".repeat(BYTES_PER_PANEL - visible));
    }
    out
}

fn map_character(byte: u8, table: CharacterTable) -> char {
    match table {
        CharacterTable::Default => {
            if byte == 0 {
                '⋄'
            } else if (0x21..=0x7e).contains(&byte) {
                byte as char
            } else if byte == 0x20 || matches!(byte, 0x09 | 0x0a | 0x0c | 0x0d) {
                if byte == 0x20 {
                    ' '
                } else {
                    '_'
                }
            } else if byte < 0x80 {
                '•'
            } else {
                '×'
            }
        }
        CharacterTable::Ascii => {
            if (0x20..=0x7e).contains(&byte) {
                byte as char
            } else if byte == b' ' {
                ' '
            } else {
                '.'
            }
        }
        CharacterTable::Codepage437 => {
            if byte == 0 {
                '⋄'
            } else {
                cp437_char(byte)
            }
        }
        CharacterTable::Codepage1047 => {
            if (0x20..=0x7e).contains(&byte) {
                byte as char
            } else if byte == b' ' {
                ' '
            } else {
                '.'
            }
        }
        CharacterTable::Braille => braille_char(byte),
    }
}

fn cp437_char(byte: u8) -> char {
    const TABLE: [char; 256] = [
        '\0', '☺', '☻', '♥', '♦', '♣', '♠', '•', '◘', '○', '◙', '♂', '♀', '♪', '♫', '☼',
        '▶', '◀', '↕', '‼', '¶', '§', '▬', '↨', '↑', '↓', '→', '←', '∟', '↔', '▲', '▼',
        ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/',
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?',
        '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
        'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_',
        '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '⌂',
        'Ç', 'ü', 'é', 'â', 'ä', 'à', 'å', 'ç', 'ê', 'ë', 'è', 'ï', 'î', 'ì', 'Ä', 'Å',
        'É', 'æ', 'Æ', 'ô', 'ö', 'ò', 'û', 'ù', 'ÿ', 'Ö', 'Ü', '¢', '£', '¥', '₧', 'ƒ',
        'á', 'í', 'ó', 'ú', 'ñ', 'Ñ', 'ª', 'º', '¿', '⌐', '¬', '½', '¼', '¡', '«', '»',
        '░', '▒', '▓', '│', '┤', '╡', '╢', '╖', '╕', '╣', '║', '╗', '╝', '╜', '╛', '┐',
        '└', '┴', '┬', '├', '─', '┼', '╞', '╟', '╚', '╔', '╩', '╦', '╠', '═', '╬', '╧',
        '╨', '╤', '╥', '╙', '╘', '╒', '╓', '╫', '╪', '┘', '┌', '█', '▄', '▌', '▐', '▀',
        'α', 'ß', 'Γ', 'π', 'Σ', 'σ', 'µ', 'τ', 'Φ', 'Θ', 'Ω', 'δ', '∞', 'φ', 'ε', '∩',
        '≡', '±', '≥', '≤', '⌠', '⌡', '÷', '≈', '°', '∙', '·', '√', 'ⁿ', '²', '■', ' ',
    ];
    TABLE[byte as usize]
}

fn braille_char(byte: u8) -> char {
    if byte == 0 {
        '⋄'
    } else if (0x20..=0x7e).contains(&byte) {
        byte as char
    } else if byte == b' ' {
        ' '
    } else if matches!(byte, 0x09 | 0x0a | 0x0c | 0x0d) {
        '_'
    } else {
        char::from_u32(0x2800 + (byte as u32 % 256)).unwrap_or('•')
    }
}

fn pad_visible(text: &str, width: usize) -> String {
    let visible = strip_ansi(text).len();
    if visible >= width {
        text.to_string()
    } else {
        format!("{}{}", text, " ".repeat(width - visible))
    }
}

fn format_bordered_line(chunk: &[u8], offset: u64, panel_count: usize, config: &RenderConfig) -> String {
    let border = border_char(config);

    let offset_str = config.colors.offset.wrap(&format!("{:08x}", offset), config.colors.enabled);

    let p0_end = BYTES_PER_PANEL.min(chunk.len());
    let hex1 = if p0_end > 0 {
        format!(" {}", format_hex_panel(&chunk[..p0_end], config))
    } else {
        String::new()
    };

    let hex2 = if panel_count > 1 && chunk.len() > BYTES_PER_PANEL {
        let end = (2 * BYTES_PER_PANEL).min(chunk.len());
        format!(" {}", format_hex_panel(&chunk[BYTES_PER_PANEL..end], config))
    } else {
        String::new()
    };

    let (c1, c2) = if config.show_characters {
        let mut chars = vec![String::new(), String::new()];
        for p in 0..2 {
            let start = p * BYTES_PER_PANEL;
            let end = ((p + 1) * BYTES_PER_PANEL).min(chunk.len());
            if start < chunk.len() {
                for &b in &chunk[start..end] {
                    chars[p].push_str(&config.colors.byte_color(b).wrap(
                        &map_character(b, config.character_table).to_string(),
                        config.colors.enabled,
                    ));
                }
            }
            let visible = if start < chunk.len() { end - start } else { 0 };
            chars[p].push_str(&" ".repeat(BYTES_PER_PANEL - visible));
        }
        (chars[0].clone(), chars[1].clone())
    } else {
        (" ".repeat(8), " ".repeat(8))
    };

    match config.border {
        BorderStyle::Unicode => {
            let hex = pad_visible(
                &format!(
                    "{}┊ {}",
                    pad_visible(&hex1, 25),
                    hex2.trim_start()
                ),
                53,
            );
            let chars = pad_visible(&format!("{}┊{}", c1, c2), 17);
            format!("{border}{offset}{border}{hex}{border}{chars}{border}", border = border, offset = offset_str, hex = hex, chars = chars)
        }
        _ => format!(
            "{border}{offset}{border}{hex1p}{border}{hex2p}{border}{c1p}{border}{c2p}{border}",
            border = border,
            offset = offset_str,
            hex1p = pad_visible(&hex1, 25),
            hex2p = pad_visible(&hex2, 25),
            c1p = pad_visible(&c1, 8),
            c2p = pad_visible(&c2, 8),
        ),
    }
}

fn wrap_with_border(lines: &[String], config: &RenderConfig) -> String {
    let (tl, th, tr, _ml, _mr, bl, bh, br) = match config.border {
        BorderStyle::Unicode => ('┌', '─', '┐', '│', '│', '└', '─', '┘'),
        BorderStyle::Ascii => ('+', '-', '+', '|', '|', '+', '-', '+'),
        BorderStyle::None => return lines.join("\n") + "\n",
    };

    let junction = if config.border == BorderStyle::Unicode {
        ('┬', '┴')
    } else {
        ('+', '+')
    };

    let repeat = |ch: char, n: usize| ch.to_string().repeat(n);
    let top = format!(
        "{}{}{}{}{}{}{}{}{}{}{}",
        tl,
        repeat(th, 8),
        junction.0,
        repeat(th, 25),
        junction.0,
        repeat(th, 25),
        junction.0,
        repeat(th, 8),
        junction.0,
        repeat(th, 8),
        tr
    );
    let bottom = format!(
        "{}{}{}{}{}{}{}{}{}{}{}",
        bl,
        repeat(bh, 8),
        junction.1,
        repeat(bh, 25),
        junction.1,
        repeat(bh, 25),
        junction.1,
        repeat(bh, 8),
        junction.1,
        repeat(bh, 8),
        br
    );

    let mut out = top + "\n";
    for line in lines {
        out.push_str(line);
        out.push('\n');
    }
    out.push_str(&bottom);
    out.push('\n');
    out
}

pub fn render_include(data: &[u8], filename: &str) -> String {
    let name = filename
        .rsplit('/')
        .next()
        .unwrap_or(filename)
        .replace('.', "_")
        .replace('-', "_");
    let mut out = format!("unsigned char {}[] = {{\n", name);
    for (i, chunk) in data.chunks(12).enumerate() {
        out.push_str("  ");
        for (j, b) in chunk.iter().enumerate() {
            if i > 0 || j > 0 {
                out.push_str(", ");
            }
            out.push_str(&format!("0x{:02x}", b));
        }
        out.push('\n');
    }
    out.push_str("};\n");
    out.push_str(&format!("unsigned int {}_len = {};\n", name, data.len()));
    out
}
