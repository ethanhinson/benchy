mod colors;
mod parse;
mod render;

use anyhow::{Context, Result};
use clap::{ArgAction, CommandFactory, Parser, ValueEnum};
use clap_complete::{generate, Shell};
use colors::{ColorScheme, ColorWhen, Colors};
use parse::{parse_byte_count, ParseContext};
use render::{Base, BorderStyle, CharacterTable, Endianness, PanelCount, RenderConfig};
use std::fs;
use std::io::{self, IsTerminal, Read};
use std::path::PathBuf;

#[derive(Parser, Debug)]
#[command(
    name = "hexyl",
    version = "0.16.0",
    about = "A command-line hex viewer",
    disable_help_flag = false
)]
struct Args {
    /// The file to display. If no FILE argument is given, read from STDIN
    #[arg(value_name = "FILE")]
    file: Option<PathBuf>,

    /// Only read N bytes from the input. The N argument can also include a unit with a
    /// decimal prefix (kB, MB, ..) or binary prefix (kiB, MiB, ..), or can be specified
    /// using a hex number. The short option '-l' can be used as an alias.
    /// Examples: --length=64, --length=4KiB, --length=0xff
    #[arg(short = 'n', long, alias = "bytes", visible_short_aliases = ['c', 'l'], value_name = "N")]
    length: Option<String>,

    /// Skip the first N bytes of the input. The N argument can also include a unit (see
    /// `--length` for details).
    /// A negative value is valid and will seek from the end of the file.
    #[arg(short = 's', long, value_name = "N")]
    skip: Option<String>,

    /// Sets the size of the `block` unit to SIZE.
    /// Examples: --block-size=1024, --block-size=4kB
    #[arg(long, value_name = "SIZE", default_value = "512")]
    block_size: String,

    /// Displays all input data. Otherwise any number of groups of output lines which
    /// would be identical to the preceding group of lines, are replaced with a line
    /// comprised of a single asterisk
    #[arg(short = 'v', long = "no-squeezing")]
    no_squeezing: bool,

    /// When to use colors
    #[arg(long, value_enum, default_value = "always")]
    color: ColorMode,

    /// Whether to draw a border
    #[arg(long, value_enum, default_value = "unicode")]
    border: BorderMode,

    /// Display output with --no-characters, --no-position, --border=none, and
    /// --color=never
    #[arg(short = 'p', long)]
    plain: bool,

    /// Do not show the character panel on the right
    #[arg(long)]
    no_characters: bool,

    /// Show the character panel on the right. This is the default, unless
    /// --no-characters has been specified
    #[arg(short = 'C', long = "characters", action = ArgAction::SetTrue)]
    characters: bool,

    /// Defines how bytes are mapped to characters
    #[arg(long, value_enum, default_value = "default")]
    character_table: CharacterTableMode,

    /// Defines the color scheme for the characters
    #[arg(long, value_enum, default_value = "default")]
    color_scheme: ColorSchemeMode,

    /// Whether to display the position panel on the left
    #[arg(short = 'P', long = "no-position")]
    no_position: bool,

    /// Add N bytes to the displayed file position. The N argument can also include a
    /// unit (see `--length` for details).
    /// A negative value is valid and calculates an offset relative to the end of the
    /// file.
    #[arg(short = 'o', long, value_name = "N", default_value = "0")]
    display_offset: String,

    /// Sets the number of hex data panels to be displayed. `--panels=auto` will display
    /// the maximum number of hex data panels based on the current terminal width. By
    /// default, hexyl will show two panels, unless the terminal is not wide enough for
    /// that
    #[arg(long, value_name = "N", default_value = "2")]
    panels: String,

    /// Number of bytes/octets that should be grouped together. You can use the
    /// '--endianness' option to control the ordering of the bytes within a group.
    /// '--groupsize' can be used as an alias (xxd-compatibility)
    #[arg(short = 'g', long = "group-size", alias = "groupsize", value_enum, default_value = "1")]
    group_size: GroupSize,

    /// Whether to print out groups in little-endian or big-endian format. This option
    /// only has an effect if the '--group-size' is larger than 1. '-e' can be used as
    /// an alias for '--endianness=little'
    #[arg(long, value_enum, default_value = "big")]
    endianness: EndiannessMode,

    #[arg(short = 'e', long, action = ArgAction::SetTrue, hide = true)]
    little_endian: bool,

    /// Sets the base used for the bytes. The possible options are binary, octal,
    /// decimal, and hexadecimal
    #[arg(short = 'b', long, value_enum, default_value = "hexadecimal")]
    base: BaseMode,

    /// Sets the number of terminal columns to be displayed.
    /// Since the terminal width may not be an evenly divisible by the width per hex
    /// data column, this will use the greatest number of hex data panels that can fit
    /// in the requested width but still leave some space to the right.
    /// Cannot be used with other width-setting options.
    #[arg(long, value_name = "N")]
    terminal_width: Option<usize>,

    /// Print a table showing how different types of bytes are colored
    #[arg(long)]
    print_color_table: bool,

    /// Output in C include file style
    #[arg(short = 'i', long = "include")]
    include: bool,

    /// Show shell completion for a certain shell
    #[arg(long, value_enum)]
    completion: Option<Shell>,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum ColorMode {
    /// Always use colorized output
    Always,
    /// Only displays colors if the output goes to an interactive terminal
    Auto,
    /// Do not use colorized output
    Never,
    /// Override the NO_COLOR environment variable
    Force,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum BorderMode {
    /// Draw a border with Unicode characters
    Unicode,
    /// Draw a border with ASCII characters
    Ascii,
    /// Do not draw a border at all
    None,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum CharacterTableMode {
    #[value(
        name = "default",
        help = "Show printable ASCII characters as-is, '⋄' for NULL bytes, ' ' for space, '_' for other ASCII whitespace, '•' for other ASCII characters, and '×' for non-ASCII bytes"
    )]
    Default,
    #[value(name = "ascii", help = "Show printable ASCII as-is, ' ' for space, '.' for everything else")]
    Ascii,
    #[value(name = "codepage-1047", help = "Show printable EBCDIC as-is, ' ' for space, '.' for everything else")]
    Codepage1047,
    #[value(name = "codepage-437", help = "Uses code page 437 (for non-ASCII bytes)")]
    Codepage437,
    #[value(name = "braille", help = "Uses braille characters for non-printable bytes")]
    Braille,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum ColorSchemeMode {
    #[value(
        name = "default",
        help = "Show the default colors: bright black for NULL bytes, green for ASCII space characters and non-printable ASCII, cyan for printable ASCII characters, and yellow for non-ASCII bytes"
    )]
    Default,
    #[value(
        name = "gradient",
        help = "Show bright black for NULL bytes, cyan for printable ASCII characters, a gradient from pink to violet for non-printable ASCII characters and a heatmap-like gradient from red to yellow to white for non-ASCII bytes"
    )]
    Gradient,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum GroupSize {
    #[value(name = "1", help = "Grouped together every byte/octet")]
    One,
    #[value(name = "2", help = "Grouped together every 2 bytes/octets")]
    Two,
    #[value(name = "4", help = "Grouped together every 4 bytes/octets")]
    Four,
    #[value(name = "8", help = "Grouped together every 8 bytes/octets")]
    Eight,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum EndiannessMode {
    #[value(name = "little", help = "Print out groups in little-endian format")]
    Little,
    #[value(name = "big", help = "Print out groups in big-endian format")]
    Big,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum BaseMode {
    Binary,
    Octal,
    Decimal,
    Hexadecimal,
}

fn main() -> Result<()> {
    let args = Args::parse();

    if let Some(shell) = args.completion {
        let mut cmd = Args::command();
        generate(shell, &mut cmd, "hexyl", &mut io::stdout());
        return Ok(());
    }

    let block_size: u64 = args
        .block_size
        .parse()
        .context("failed to parse --block-size")?;

    let color_when = match args.color {
        ColorMode::Always => ColorWhen::Always,
        ColorMode::Auto => ColorWhen::Auto,
        ColorMode::Never => ColorWhen::Never,
        ColorMode::Force => ColorWhen::Force,
    };

    let color_scheme = match args.color_scheme {
        ColorSchemeMode::Default => ColorScheme::Default,
        ColorSchemeMode::Gradient => ColorScheme::Gradient,
    };

    let colors = Colors::resolve(color_when, color_scheme, io::stdout().is_terminal());

    if args.print_color_table {
        colors.print_color_table();
        return Ok(());
    }

    let data = read_input(&args, block_size)?;

    if args.include {
        let filename = args
            .file
            .as_ref()
            .and_then(|p| p.file_name())
            .and_then(|n| n.to_str())
            .unwrap_or("stdin");
        print!("{}", render::render_include(&data, filename));
        return Ok(());
    }

    let plain = args.plain;
    let show_characters = if plain {
        false
    } else if args.no_characters {
        false
    } else {
        true
    };

    let show_position = !plain && !args.no_position;

    let border = if plain {
        BorderStyle::None
    } else {
        match args.border {
            BorderMode::Unicode => BorderStyle::Unicode,
            BorderMode::Ascii => BorderStyle::Ascii,
            BorderMode::None => BorderStyle::None,
        }
    };

    let color = if plain {
        Colors::resolve(ColorWhen::Never, color_scheme, false)
    } else {
        colors
    };

    let display_offset =
        parse_byte_count(&args.display_offset, block_size, ParseContext::DisplayOffset)? as u64;

    let panels = if args.panels.eq_ignore_ascii_case("auto") {
        PanelCount::Auto
    } else {
        PanelCount::Fixed(args.panels.parse().context("failed to parse --panels")?)
    };

    let group_size = match args.group_size {
        GroupSize::One => 1,
        GroupSize::Two => 2,
        GroupSize::Four => 4,
        GroupSize::Eight => 8,
    };

    let endianness = if args.little_endian {
        Endianness::Little
    } else {
        match args.endianness {
            EndiannessMode::Little => Endianness::Little,
            EndiannessMode::Big => Endianness::Big,
        }
    };

    let base = match args.base {
        BaseMode::Binary => Base::Binary,
        BaseMode::Octal => Base::Octal,
        BaseMode::Decimal => Base::Decimal,
        BaseMode::Hexadecimal => Base::Hexadecimal,
    };

    let character_table = match args.character_table {
        CharacterTableMode::Default => CharacterTable::Default,
        CharacterTableMode::Ascii => CharacterTable::Ascii,
        CharacterTableMode::Codepage1047 => CharacterTable::Codepage1047,
        CharacterTableMode::Codepage437 => CharacterTable::Codepage437,
        CharacterTableMode::Braille => CharacterTable::Braille,
    };

    let config = RenderConfig {
        show_position,
        show_characters,
        border,
        panels,
        group_size,
        endianness,
        base,
        display_offset,
        no_squeezing: args.no_squeezing,
        character_table,
        colors: color,
    };

    print!("{}", render::render(&data, &config));
    Ok(())
}

fn read_input(args: &Args, block_size: u64) -> Result<Vec<u8>> {
    let mut data = if let Some(path) = &args.file {
        fs::read(path).map_err(|_| anyhow::anyhow!("No such file or directory (os error 2)"))?
    } else {
        let mut buf = Vec::new();
        io::stdin().read_to_end(&mut buf)?;
        buf
    };

    if let Some(skip) = &args.skip {
        let skip_n = parse_byte_count(skip, block_size, ParseContext::Skip)?;
        if skip_n < 0 {
            let abs = (-skip_n) as u64;
            if abs as usize >= data.len() {
                data.clear();
            } else {
                let start = data.len() - abs as usize;
                data = data[start..].to_vec();
            }
        } else if skip_n > 0 {
            let start = (skip_n as usize).min(data.len());
            data = data[start..].to_vec();
        }
    }

    if let Some(len) = &args.length {
        let n = parse_byte_count(len, block_size, ParseContext::Length)?;
        if n >= 0 {
            data.truncate(n as usize);
        }
    }

    Ok(data)
}
