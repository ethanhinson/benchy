use std::env;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorWhen {
    Always,
    Auto,
    Never,
    Force,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColorScheme {
    Default,
    Gradient,
}

#[derive(Debug, Clone)]
pub struct Colors {
    pub enabled: bool,
    pub offset: AnsiColor,
    pub null: AnsiColor,
    pub ascii_printable: AnsiColor,
    pub ascii_whitespace: AnsiColor,
    pub ascii_other: AnsiColor,
    pub non_ascii: AnsiColor,
    pub scheme: ColorScheme,
}

#[derive(Debug, Clone)]
pub struct AnsiColor {
    pub code: String,
}

impl AnsiColor {
    pub fn from_name(name: &str) -> Option<Self> {
        let code = match name.trim().to_ascii_lowercase().as_str() {
            "black" => "30".to_string(),
            "red" => "31".to_string(),
            "green" => "32".to_string(),
            "yellow" => "33".to_string(),
            "blue" => "34".to_string(),
            "magenta" => "35".to_string(),
            "cyan" => "36".to_string(),
            "white" => "37".to_string(),
            "bright black" | "brightblack" => "90".to_string(),
            "bright red" | "brightred" => "91".to_string(),
            "bright green" | "brightgreen" => "92".to_string(),
            "bright yellow" | "brightyellow" => "93".to_string(),
            "bright blue" | "brightblue" => "94".to_string(),
            "bright magenta" | "brightmagenta" => "95".to_string(),
            "bright cyan" | "brightcyan" => "96".to_string(),
            "bright white" | "brightwhite" => "97".to_string(),
            s if s.starts_with('#') && s.len() == 7 => {
                format!("38;2;{};{};{}", u8::from_str_radix(&s[1..3], 16).ok()?, u8::from_str_radix(&s[3..5], 16).ok()?, u8::from_str_radix(&s[5..7], 16).ok()?)
            }
            _ => return None,
        };
        Some(Self { code })
    }

    pub fn wrap(&self, text: &str, enabled: bool) -> String {
        if enabled {
            format!("\x1b[{}m{}\x1b[39m", self.code, text)
        } else {
            text.to_string()
        }
    }
}

impl Colors {
    pub fn resolve(when: ColorWhen, scheme: ColorScheme, stdout_is_tty: bool) -> Self {
        let no_color = env::var_os("NO_COLOR").is_some();
        let enabled = match when {
            ColorWhen::Always => !no_color,
            ColorWhen::Auto => stdout_is_tty && !no_color,
            ColorWhen::Never => false,
            ColorWhen::Force => true,
        };

        let env_color = |key: &str, default: &str| -> AnsiColor {
            env::var(key)
                .ok()
                .and_then(|v| AnsiColor::from_name(&v))
                .unwrap_or_else(|| AnsiColor::from_name(default).unwrap())
        };

        Self {
            enabled,
            offset: env_color("HEXYL_COLOR_OFFSET", "white"),
            null: env_color("HEXYL_COLOR_NULL", "bright black"),
            ascii_printable: env_color("HEXYL_COLOR_ASCII_PRINTABLE", "cyan"),
            ascii_whitespace: env_color("HEXYL_COLOR_ASCII_WHITESPACE", "green"),
            ascii_other: env_color("HEXYL_COLOR_ASCII_OTHER", "green"),
            non_ascii: env_color("HEXYL_COLOR_NONASCII", "yellow"),
            scheme,
        }
    }

    pub fn byte_color(&self, byte: u8) -> &AnsiColor {
        match self.scheme {
            ColorScheme::Default => self.default_byte_color(byte),
            ColorScheme::Gradient => self.gradient_byte_color(byte),
        }
    }

    fn default_byte_color(&self, byte: u8) -> &AnsiColor {
        if byte == 0 {
            return &self.null;
        }
        if byte >= 0x80 {
            return &self.non_ascii;
        }
        if (0x20..=0x7e).contains(&byte) {
            if byte == b' ' {
                return &self.ascii_whitespace;
            }
            return &self.ascii_printable;
        }
        if matches!(byte, 0x09 | 0x0a | 0x0b | 0x0c | 0x0d) {
            return &self.ascii_whitespace;
        }
        &self.ascii_other
    }

    fn gradient_byte_color(&self, byte: u8) -> &AnsiColor {
        self.default_byte_color(byte)
    }

    pub fn print_color_table(&self) {
        let lines = [
            (self.null.clone(), "⋄ NULL bytes (0x00)"),
            (
                self.ascii_printable.clone(),
                "a ASCII printable characters (0x20 - 0x7E)",
            ),
            (
                self.ascii_whitespace.clone(),
                "_ ASCII whitespace (0x09 - 0x0D, 0x20)",
            ),
            (
                self.ascii_other.clone(),
                "• ASCII control characters (except NULL and whitespace)",
            ),
            (self.non_ascii.clone(), "× Non-ASCII bytes (0x80 - 0xFF)"),
        ];

        print!("hexyl color reference:\n\n");
        for (color, text) in lines {
            print!("\x1b[{}m{}\n\x1b[39m", color.code, text);
        }
    }
}
