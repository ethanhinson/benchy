use anyhow::{anyhow, bail, Context, Result};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParseContext {
    Length,
    Skip,
    DisplayOffset,
}

pub fn parse_byte_count(input: &str, block_size: u64, context: ParseContext) -> Result<i64> {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        bail!("empty byte count");
    }

    let negative = trimmed.starts_with('-');
    let s = if negative { &trimmed[1..] } else { trimmed };

    if negative {
        match context {
            ParseContext::Skip => {}
            ParseContext::DisplayOffset => {
                bail!("negative offset specified, but only positive offsets (counts) are accepted in this context");
            }
            ParseContext::Length => {
                bail!("negative length is not supported");
            }
        }
    }

    let value = parse_positive_byte_count(s, block_size)?;
    Ok(if negative {
        -(value as i64)
    } else {
        value as i64
    })
}

fn parse_positive_byte_count(s: &str, block_size: u64) -> Result<u64> {
    let lower = s.to_ascii_lowercase();

    if let Some(stripped) = lower.strip_prefix("0x") {
        return u64::from_str_radix(stripped, 16)
            .with_context(|| format!("failed to parse hex number '{s}'"));
    }

    if lower.ends_with("block") {
        let num_part = &lower[..lower.len() - 5];
        let blocks: f64 = if num_part.is_empty() {
            1.0
        } else {
            num_part
                .parse()
                .with_context(|| format!("failed to parse block count '{s}'"))?
        };
        let bytes = blocks * block_size as f64;
        return Ok(bytes as u64);
    }

    parse_with_unit(&lower)
}

fn parse_with_unit(s: &str) -> Result<u64> {
    const UNITS: &[(&str, u64)] = &[
        ("kib", 1024),
        ("mib", 1024u64.pow(2)),
        ("gib", 1024u64.pow(3)),
        ("tib", 1024u64.pow(4)),
        ("pib", 1024u64.pow(5)),
        ("eib", 1024u64.pow(6)),
        ("kb", 1000),
        ("mb", 1000u64.pow(2)),
        ("gb", 1000u64.pow(3)),
        ("tb", 1000u64.pow(4)),
        ("pb", 1000u64.pow(5)),
        ("eb", 1000u64.pow(6)),
    ];

    for (unit, multiplier) in UNITS {
        if s.ends_with(unit) {
            let num_part = &s[..s.len() - unit.len()];
            let value: f64 = num_part
                .parse()
                .with_context(|| format!("failed to parse '{s}'"))?;
            return Ok((value * *multiplier as f64) as u64);
        }
    }

    if let Ok(v) = s.parse::<u64>() {
        return Ok(v);
    }

    Err(anyhow!("failed to parse '{s}' as byte count"))
}
