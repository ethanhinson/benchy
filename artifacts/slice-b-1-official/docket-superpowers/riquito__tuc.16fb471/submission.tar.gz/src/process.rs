use crate::bounds::{
    self, BoundItem, BoundsSpec, complement_item, expand_items, is_single_range, parse_bounds,
    resolve_index_or_fallback,
};
use regex::Regex;
use std::io::{self, Write};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CutMode {
    Fields,
    Bytes,
    Characters,
    Lines,
}

#[derive(Debug, Clone)]
pub struct Options {
    pub mode: CutMode,
    pub bounds_spec: String,
    pub delimiter: String,
    pub regex: Option<String>,
    pub greedy: bool,
    pub compress: bool,
    pub only_delimited: bool,
    pub zero_terminated: bool,
    pub complement: bool,
    pub join: bool,
    pub no_join: bool,
    pub json: bool,
    pub replace_delimiter: Option<String>,
    pub trim: Option<String>,
    pub fallback_oob: Option<String>,
    pub _no_mmap: bool,
    pub _fixed_memory: Option<usize>,
}

pub fn run(opts: &Options, input: &[u8]) -> Result<(), String> {
    let bounds = parse_bounds(&opts.bounds_spec).map_err(|e| e.to_string())?;

    match opts.mode {
        CutMode::Fields => process_field_lines(opts, input, &bounds),
        CutMode::Bytes => process_bytes(opts, input, &bounds),
        CutMode::Characters => process_char_lines(opts, input, &bounds),
        CutMode::Lines => process_lines(opts, input, &bounds),
    }
}

fn process_field_lines(opts: &Options, input: &[u8], bounds: &BoundsSpec) -> Result<(), String> {
    let line_terminator = if opts.zero_terminated { b'\0' } else { b'\n' };
    let lines = split_lines(input, line_terminator);
    let mut out = Vec::new();

    for (idx, line) in lines.iter().enumerate() {
        let line_str = std::str::from_utf8(line).map_err(|_| "invalid UTF-8 input".to_string())?;
        if opts.only_delimited && !line_contains_delimiter(opts, line_str)? {
            continue;
        }
        let processed = process_single_fields(opts, line_str, bounds)?;
        out.extend_from_slice(processed.as_bytes());
        if idx + 1 < lines.len() || input.last() == Some(&line_terminator) {
            out.push(line_terminator);
        }
    }
    stdout_write(&out)
}

fn process_char_lines(opts: &Options, input: &[u8], bounds: &BoundsSpec) -> Result<(), String> {
    let line_terminator = if opts.zero_terminated { b'\0' } else { b'\n' };
    let lines = split_lines(input, line_terminator);
    let mut out = Vec::new();

    for (idx, line) in lines.iter().enumerate() {
        let line_str = std::str::from_utf8(line).map_err(|_| "invalid UTF-8 input".to_string())?;
        let chars: Vec<String> = line_str.chars().map(|c| c.to_string()).collect();
        let processed = process_parts(opts, &chars, bounds, "")?;
        out.extend_from_slice(processed.as_bytes());
        if idx + 1 < lines.len() || input.last() == Some(&line_terminator) {
            out.push(line_terminator);
        }
    }
    stdout_write(&out)
}

fn process_bytes(opts: &Options, input: &[u8], bounds: &BoundsSpec) -> Result<(), String> {
    let processed = select_bytes(opts, input, bounds)?;
    stdout_write(&processed)
}

fn select_bytes(opts: &Options, input: &[u8], bounds: &BoundsSpec) -> Result<Vec<u8>, String> {
    if let BoundsSpec::Format(fmt) = bounds {
        let parts: Vec<String> = input
            .iter()
            .map(|b| String::from_utf8_lossy(std::slice::from_ref(b)).into_owned())
            .collect();
        return Ok(format_output(fmt, &parts, opts.fallback_oob.as_deref())?.into_bytes());
    }

    let items = match bounds {
        BoundsSpec::Items(items) => items,
        BoundsSpec::Format(_) => unreachable!(),
    };

    let count = input.len() as i64;
    if opts.complement {
        let mut out = Vec::new();
        for item in items {
            let complemented = complement_item(item, count).map_err(|e| e.to_string())?;
            out.extend(select_byte_ranges(
                input,
                &complemented,
                opts,
                count,
            )?);
        }
        return Ok(out);
    }

    select_byte_ranges(input, items, opts, count)
}

fn select_byte_ranges(
    input: &[u8],
    items: &[BoundItem],
    opts: &Options,
    count: i64,
) -> Result<Vec<u8>, String> {
    let generic = opts.fallback_oob.as_deref();
    let mut out = Vec::new();

    for item in items {
        match item {
            BoundItem::Single { index, fallback } => {
                let specific = fallback.as_deref();
                match resolve_index_or_fallback(*index, count, specific, generic)
                    .map_err(|e| e.to_string())?
                {
                    Some(i) => out.push(input[i as usize - 1]),
                    None => out.extend(specific.or(generic).unwrap_or_default().bytes()),
                }
            }
            BoundItem::Range {
                start,
                end,
                fallback,
            } => {
                let s = normalize_range_start(*start, count)?;
                let e = normalize_range_end(*end, count)?;
                let (lo, hi) = (s.min(e), s.max(e));
                for i in lo..=hi {
                    if (1..=count).contains(&i) {
                        out.push(input[i as usize - 1]);
                    } else if fallback.is_some() || generic.is_some() {
                        out.extend(fallback.as_deref().or(generic).unwrap_or_default().bytes());
                    } else {
                        return Err(format!("Out of bounds: {i}"));
                    }
                }
            }
        }
    }
    Ok(out)
}

fn process_lines(opts: &Options, input: &[u8], bounds: &BoundsSpec) -> Result<(), String> {
    let line_terminator = if opts.zero_terminated { b'\0' } else { b'\n' };
    let lines: Vec<String> = split_lines(input, line_terminator)
        .into_iter()
        .map(|l| {
            std::str::from_utf8(l)
                .map_err(|_| "invalid UTF-8 input".to_string())
                .map(|s| s.to_string())
        })
        .collect::<Result<_, _>>()?;

    let line_delim = if opts.zero_terminated { "\0" } else { "\n" };
    let join = opts.join && !opts.no_join;
    let processed = process_parts(opts, &lines, bounds, line_delim)?;
    stdout_write(processed.as_bytes())?;
    if join && !input.is_empty() && input.last() == Some(&line_terminator) && !processed.is_empty()
    {
        stdout_write(&[line_terminator])?;
    }
    Ok(())
}

fn process_single_fields(opts: &Options, line: &str, bounds: &BoundsSpec) -> Result<String, String> {
    let parts = split_fields(opts, line)?;
    process_parts(opts, &parts, bounds, &effective_delimiter(opts))
}

fn split_fields(opts: &Options, line: &str) -> Result<Vec<String>, String> {
    let mut working = line.to_string();

    if let Some(trim) = &opts.trim {
        working = apply_trim(&working, opts, trim)?;
    }

    if opts.compress {
        working = compress_delimiters(&working, opts)?;
    }

    if opts.greedy {
        return Ok(split_greedy(&working, opts));
    }

    if let Some(re) = &opts.regex {
        let regex = Regex::new(re).map_err(|e| e.to_string())?;
        return Ok(regex.split(&working).map(|s| s.to_string()).collect());
    }

    Ok(split_literal(&working, &opts.delimiter))
}

fn effective_delimiter(opts: &Options) -> String {
    opts.replace_delimiter
        .clone()
        .unwrap_or_else(|| opts.delimiter.clone())
}

fn split_literal(text: &str, delim: &str) -> Vec<String> {
    if delim.is_empty() {
        return text.chars().map(|c| c.to_string()).collect();
    }
    text.split(delim).map(|s| s.to_string()).collect()
}

fn split_greedy(text: &str, opts: &Options) -> Vec<String> {
    if let Some(re) = &opts.regex {
        if let Ok(regex) = Regex::new(re) {
            return split_greedy_regex(text, &regex);
        }
    }
    split_greedy_literal(text, &opts.delimiter)
}

fn split_greedy_literal(text: &str, delim: &str) -> Vec<String> {
    if delim.is_empty() {
        return vec![text.to_string()];
    }
    let mut parts = Vec::new();
    let mut current = String::new();
    let mut i = 0;
    while i < text.len() {
        if text[i..].starts_with(delim) {
            parts.push(current.clone());
            current.clear();
            while i < text.len() && text[i..].starts_with(delim) {
                i += delim.len();
            }
        } else {
            let ch = text[i..].chars().next().unwrap();
            current.push(ch);
            i += ch.len_utf8();
        }
    }
    parts.push(current);
    parts
}

fn split_greedy_regex(text: &str, regex: &Regex) -> Vec<String> {
    let mut parts = Vec::new();
    let mut last = 0;
    let mut matches = regex.find_iter(text).peekable();
    while let Some(m) = matches.next() {
        parts.push(text[last..m.start()].to_string());
        last = m.end();
        while matches.peek().is_some_and(|next| next.start() == last) {
            last = matches.next().unwrap().end();
        }
    }
    parts.push(text[last..].to_string());
    parts
}

fn compress_delimiters(text: &str, opts: &Options) -> Result<String, String> {
    if let Some(re) = &opts.regex {
        let regex = Regex::new(re).map_err(|e| e.to_string())?;
        let mut out = String::new();
        let mut last = 0;
        let mut in_run = false;
        for m in regex.find_iter(text) {
            out.push_str(&text[last..m.start()]);
            if !in_run {
                out.push_str(m.as_str());
                in_run = true;
            }
            last = m.end();
        }
        out.push_str(&text[last..]);
        return Ok(out);
    }

    let delim = &opts.delimiter;
    if delim.is_empty() {
        return Ok(text.to_string());
    }
    let mut out = String::new();
    let mut i = 0;
    let mut in_run = false;
    while i < text.len() {
        if text[i..].starts_with(delim) {
            if !in_run {
                out.push_str(delim);
                in_run = true;
            }
            i += delim.len();
        } else {
            in_run = false;
            let ch = text[i..].chars().next().unwrap();
            out.push(ch);
            i += ch.len_utf8();
        }
    }
    Ok(out)
}

fn apply_trim(text: &str, opts: &Options, trim: &str) -> Result<String, String> {
    let mode = trim.to_ascii_lowercase();
    if let Some(re) = &opts.regex {
        let regex = Regex::new(re).map_err(|e| e.to_string())?;
        return Ok(trim_regex(text, &regex, &mode));
    }
    Ok(trim_literal(text, &opts.delimiter, &mode))
}

fn trim_literal(text: &str, delim: &str, mode: &str) -> String {
    if delim.is_empty() {
        return text.to_string();
    }
    let parts: Vec<&str> = text.split(delim).collect();
    let mut out_parts = Vec::new();
    for (idx, part) in parts.iter().enumerate() {
        let mut p = part.to_string();
        if idx > 0 && (mode == "l" || mode == "b") {
            p = p.trim_start().to_string();
        }
        if idx + 1 < parts.len() && (mode == "r" || mode == "b") {
            p = p.trim_end().to_string();
        }
        out_parts.push(p);
    }
    out_parts.join(delim)
}

fn trim_regex(text: &str, regex: &Regex, mode: &str) -> String {
    let mut result = text.to_string();
    if mode == "l" || mode == "b" {
        if let Some(m) = regex.find(&result) {
            let (start, end) = (m.start(), m.end());
            let trimmed = m.as_str().trim_start().to_string();
            result.replace_range(start..end, &trimmed);
        }
    }
    if mode == "r" || mode == "b" {
        if let Some(m) = regex.find_iter(&result).last() {
            let (start, end) = (m.start(), m.end());
            let trimmed = m.as_str().trim_end().to_string();
            result.replace_range(start..end, &trimmed);
        }
    }
    result
}

fn line_contains_delimiter(opts: &Options, line: &str) -> Result<bool, String> {
    if let Some(re) = &opts.regex {
        let regex = Regex::new(re).map_err(|e| e.to_string())?;
        return Ok(regex.is_match(line));
    }
    Ok(line.contains(&opts.delimiter))
}

fn process_parts(
    opts: &Options,
    parts: &[String],
    bounds: &BoundsSpec,
    join_delim: &str,
) -> Result<String, String> {
    if let BoundsSpec::Format(fmt) = bounds {
        return format_output(fmt, parts, opts.fallback_oob.as_deref());
    }

    if opts.complement {
        return process_complement(opts, parts, bounds, join_delim);
    }

    let items = match bounds {
        BoundsSpec::Items(items) => items.clone(),
        BoundsSpec::Format(_) => unreachable!(),
    };

    select_and_output(opts, parts, &items, join_delim)
}

fn process_complement(
    opts: &Options,
    parts: &[String],
    bounds: &BoundsSpec,
    join_delim: &str,
) -> Result<String, String> {
    let items = match bounds {
        BoundsSpec::Items(items) => items,
        BoundsSpec::Format(_) => {
            return Err("complement does not support format strings".into());
        }
    };

    let count = parts.len() as i64;
    let mut result = String::new();

    for item in items {
        let complemented = complement_item(item, count).map_err(|e| e.to_string())?;
        let segment = select_complement_segment(opts, parts, &complemented, join_delim)?;
        result.push_str(&segment);
    }
    Ok(result)
}

fn select_complement_segment(
    opts: &Options,
    parts: &[String],
    items: &[BoundItem],
    _join_delim: &str,
) -> Result<String, String> {
    let count = parts.len() as i64;
    let delim = effective_delimiter(opts);

    if opts.json {
        let selected = collect_with_fallbacks(parts, items, opts)?;
        return Ok(json_array(&selected));
    }

    if is_single_range(items) {
        let indices = expand_items(items, count).map_err(|e| e.to_string())?;
        let selected: Vec<String> = indices.iter().map(|&i| parts[i as usize - 1].clone()).collect();
        return Ok(selected.join(&delim));
    }

    let use_join = opts.join || opts.replace_delimiter.is_some();
    if use_join {
        let selected = collect_with_fallbacks(parts, items, opts)?;
        return Ok(selected.join(&delim));
    }

    let indices = expand_items(items, count).map_err(|e| e.to_string())?;
    if indices.is_empty() {
        return Ok(String::new());
    }

    let mut out = String::new();
    for (pos, &idx) in indices.iter().enumerate() {
        if pos > 0 {
            let prev = indices[pos - 1];
            if idx - prev == 1 {
                out.push_str(&delim);
            }
        }
        out.push_str(&parts[idx as usize - 1]);
    }
    Ok(out)
}

fn select_and_output(
    opts: &Options,
    parts: &[String],
    items: &[BoundItem],
    join_delim: &str,
) -> Result<String, String> {
    let delim = if opts.mode == CutMode::Lines && opts.join && !opts.no_join {
        join_delim.to_string()
    } else {
        effective_delimiter(opts)
    };

    if opts.json {
        let selected = collect_with_fallbacks(parts, items, opts)?;
        return Ok(json_array(&selected));
    }

    let use_join = opts.join
        || opts.replace_delimiter.is_some()
        || (opts.mode == CutMode::Lines && !opts.no_join);

    if use_join {
        let selected = collect_with_fallbacks(parts, items, opts)?;
        return Ok(selected.join(&delim));
    }

    Ok(collect_by_items(parts, items, opts, &delim)?.concat())
}

fn collect_by_items(
    parts: &[String],
    items: &[BoundItem],
    opts: &Options,
    delim: &str,
) -> Result<Vec<String>, String> {
    let count = parts.len() as i64;
    let generic = opts.fallback_oob.as_deref();
    let mut chunks = Vec::new();

    for item in items {
        match item {
            BoundItem::Single { index, fallback } => {
                let specific = fallback.as_deref();
                match resolve_index_or_fallback(*index, count, specific, generic)
                    .map_err(|e| e.to_string())?
                {
                    Some(i) => chunks.push(parts[i as usize - 1].clone()),
                    None => chunks.push(specific.or(generic).unwrap_or_default().to_string()),
                }
            }
            BoundItem::Range {
                start,
                end,
                fallback,
            } => {
                let mut range_parts = Vec::new();
                let s = normalize_range_start(*start, count)?;
                let e = normalize_range_end(*end, count)?;
                let (lo, hi) = (s.min(e), s.max(e));
                for i in lo..=hi {
                    if (1..=count).contains(&i) {
                        range_parts.push(parts[i as usize - 1].clone());
                    } else if fallback.is_some() || generic.is_some() {
                        range_parts.push(fallback.as_deref().or(generic).unwrap_or_default().to_string());
                    } else {
                        return Err(format!("Out of bounds: {i}"));
                    }
                }
                chunks.push(range_parts.join(delim));
            }
        }
    }
    Ok(chunks)
}

fn collect_with_fallbacks(
    parts: &[String],
    items: &[BoundItem],
    opts: &Options,
) -> Result<Vec<String>, String> {
    let count = parts.len() as i64;
    let generic = opts.fallback_oob.as_deref();
    let mut selected = Vec::new();

    for item in items {
        match item {
            BoundItem::Single { index, fallback } => {
                let specific = fallback.as_deref();
                match resolve_index_or_fallback(*index, count, specific, generic)
                    .map_err(|e| e.to_string())?
                {
                    Some(i) => selected.push(parts[i as usize - 1].clone()),
                    None => {
                        selected.push(specific.or(generic).unwrap_or_default().to_string());
                    }
                }
            }
            BoundItem::Range {
                start,
                end,
                fallback,
            } => {
                let s = normalize_range_start(*start, count)?;
                let e = normalize_range_end(*end, count)?;
                let (lo, hi) = (s.min(e), s.max(e));
                for i in lo..=hi {
                    if (1..=count).contains(&i) {
                        selected.push(parts[i as usize - 1].clone());
                    } else if fallback.is_some() || generic.is_some() {
                        selected.push(fallback.as_deref().or(generic).unwrap_or_default().to_string());
                    } else {
                        return Err(format!("Out of bounds: {i}"));
                    }
                }
            }
        }
    }
    Ok(selected)
}

fn normalize_range_start(start: i64, count: i64) -> Result<i64, String> {
    if start < 0 {
        bounds::resolve_index(start, count).map_err(|e| e.to_string())
    } else {
        Ok(start)
    }
}

fn normalize_range_end(end: i64, count: i64) -> Result<i64, String> {
    if end == i64::MAX {
        Ok(count)
    } else if end < 0 {
        bounds::resolve_index(end, count).map_err(|e| e.to_string())
    } else {
        Ok(end)
    }
}

fn format_output(fmt: &str, parts: &[String], fallback: Option<&str>) -> Result<String, String> {
    let mut out = String::new();
    let chars: Vec<char> = fmt.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '{' && i + 1 < chars.len() && chars[i + 1] == '{' {
            out.push('{');
            i += 2;
        } else if chars[i] == '}' && i + 1 < chars.len() && chars[i + 1] == '}' {
            out.push('}');
            i += 2;
        } else if chars[i] == '{' {
            let j = (i + 1..chars.len())
                .find(|&k| chars[k] == '}')
                .ok_or_else(|| format!("failed to parse '{fmt}': unclosed brace"))?;
            let num_str: String = chars[i + 1..j].iter().collect();
            let idx: i64 = num_str
                .parse()
                .map_err(|_| format!("failed to parse '{fmt}': Not a number `{num_str}`"))?;
            let count = parts.len() as i64;
            let resolved = if idx < 0 { count + idx + 1 } else { idx };
            if (1..=count).contains(&resolved) {
                out.push_str(&parts[resolved as usize - 1]);
            } else if let Some(fb) = fallback {
                out.push_str(fb);
            } else {
                return Err(format!("Out of bounds: {idx}"));
            }
            i = j + 1;
        } else if chars[i] == '\\' && i + 1 < chars.len() && chars[i + 1] == 'n' {
            out.push('\n');
            i += 2;
        } else {
            out.push(chars[i]);
            i += 1;
        }
    }
    Ok(out)
}

fn json_array(parts: &[String]) -> String {
    let items: Vec<String> = parts
        .iter()
        .map(|p| format!("\"{}\"", escape_json(p)))
        .collect();
    format!("[{}]", items.join(","))
}

fn escape_json(s: &str) -> String {
    s.replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
        .replace('\r', "\\r")
        .replace('\t', "\\t")
}

fn split_lines(input: &[u8], terminator: u8) -> Vec<&[u8]> {
    if input.is_empty() {
        return vec![];
    }
    let mut lines: Vec<&[u8]> = input
        .split(|&b| b == terminator)
        .collect();
    if input.last() == Some(&terminator) {
        if let Some(last) = lines.last() {
            if last.is_empty() {
                lines.pop();
            }
        }
    }
    lines
}

fn stdout_write(data: &[u8]) -> Result<(), String> {
    io::stdout().write_all(data).map_err(|e| e.to_string())
}
