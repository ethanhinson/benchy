mod bounds;
mod process;

use clap::{Parser, ValueHint};
use process::{CutMode, Options, run};
use std::fs::File;
use std::io::{self, Read, stdin};
use std::path::PathBuf;

#[derive(Parser, Debug)]
#[command(name = "tuc", version = "1.3.0", disable_version_flag = true)]
struct Cli {
    /// Match consecutive delimiters as if it was one
    #[arg(short = 'g', long = "greedy-delimiter")]
    greedy_delimiter: bool,

    /// Merge consecutive delimiters, then cut
    #[arg(short = 'p', long = "compress-delimiter")]
    compress_delimiter: bool,

    /// Print only lines containing the delimiter
    #[arg(short = 's', long = "only-delimited")]
    only_delimited: bool,

    /// Print version information
    #[arg(short = 'V', long = "version")]
    version: bool,

    /// Line delimiter is NUL (\0), not LF (\n)
    #[arg(short = 'z', long = "zero-terminated")]
    zero_terminated: bool,

    /// Invert fields (e.g. '2' becomes '1,3:')
    #[arg(short = 'm', long = "complement")]
    complement: bool,

    /// Print selected parts with delimiter in between
    #[arg(short = 'j', long = "join", action = clap::ArgAction::SetTrue)]
    join: bool,

    /// Disable join (merge lines without delimiter)
    #[arg(long = "no-join", action = clap::ArgAction::SetTrue)]
    no_join: bool,

    /// Print fields as a JSON array of strings
    #[arg(long = "json")]
    json: bool,

    /// Disable memory mapping
    #[arg(long = "no-mmap")]
    no_mmap: bool,

    /// Fields to keep, 1-indexed, comma separated.
    #[arg(short = 'f', long = "fields", allow_hyphen_values = true)]
    fields: Option<String>,

    /// Same as --fields, but it keeps bytes
    #[arg(short = 'b', long = "bytes", allow_hyphen_values = true)]
    bytes: Option<String>,

    /// Same as --fields, but it keeps characters
    #[arg(short = 'c', long = "characters", allow_hyphen_values = true)]
    characters: Option<String>,

    /// Same as --fields, but it keeps lines
    #[arg(short = 'l', long = "lines", allow_hyphen_values = true)]
    lines: Option<String>,

    /// Delimiter used by --fields to cut the text
    #[arg(short = 'd', long = "delimiter", default_value = "\t")]
    delimiter: String,

    /// Use a regular expression as delimiter
    #[arg(short = 'e', long = "regex")]
    regex: Option<String>,

    /// Replace the delimiter with the provided text. Implies --join
    #[arg(short = 'r', long = "replace-delimiter")]
    replace_delimiter: Option<String>,

    /// Trim the delimiter (greedy). Valid values are (l|L)eft, (r|R)ight, (b|B)oth
    #[arg(short = 't', long = "trim")]
    trim: Option<String>,

    /// Generic fallback output for any field that cannot be found
    #[arg(long = "fallback-oob")]
    fallback_oob: Option<String>,

    /// Read the input in chunks of <size> kilobytes
    #[arg(short = 'M', long = "fixed-memory")]
    fixed_memory: Option<usize>,

    #[arg(value_hint = ValueHint::FilePath)]
    filepath: Option<PathBuf>,
}

fn main() {
    let cli = Cli::parse();

    if cli.version {
        println!("tuc 1.3.0");
        return;
    }

    let (mode, bounds_spec) = if let Some(v) = cli.lines {
        (CutMode::Lines, v)
    } else if let Some(v) = cli.bytes {
        (CutMode::Bytes, v)
    } else if let Some(v) = cli.characters {
        (CutMode::Characters, v)
    } else {
        (
            CutMode::Fields,
            cli.fields.unwrap_or_else(|| "1:".to_string()),
        )
    };

    let mut join = cli.join;
    if cli.replace_delimiter.is_some() {
        join = true;
    }
    if matches!(mode, CutMode::Lines) && !cli.no_join {
        join = true;
    }

    let opts = Options {
        mode,
        bounds_spec,
        delimiter: cli.delimiter,
        regex: cli.regex,
        greedy: cli.greedy_delimiter,
        compress: cli.compress_delimiter,
        only_delimited: cli.only_delimited,
        zero_terminated: cli.zero_terminated,
        complement: cli.complement,
        join,
        no_join: cli.no_join,
        json: cli.json,
        replace_delimiter: cli.replace_delimiter,
        trim: cli.trim,
        fallback_oob: cli.fallback_oob,
        _no_mmap: cli.no_mmap,
        _fixed_memory: cli.fixed_memory,
    };

    let input = read_input(cli.filepath.as_ref());
    match input {
        Ok(data) => {
            if let Err(e) = run(&opts, &data) {
                eprintln!("Error: {e}");
                std::process::exit(1);
            }
        }
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    }
}

fn read_input(filepath: Option<&PathBuf>) -> io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    if let Some(path) = filepath {
        let mut file = File::open(path)?;
        file.read_to_end(&mut buf)?;
    } else {
        stdin().read_to_end(&mut buf)?;
    }
    Ok(buf)
}
