use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BoundItem {
    Single {
        index: i64,
        fallback: Option<String>,
    },
    Range {
        start: i64,
        end: i64,
        fallback: Option<String>,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BoundsSpec {
    Items(Vec<BoundItem>),
    Format(String),
}

#[derive(Debug)]
pub enum ParseError {
    Invalid(String),
}

impl fmt::Display for ParseError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ParseError::Invalid(msg) => write!(f, "{msg}"),
        }
    }
}

pub fn parse_bounds(input: &str) -> Result<BoundsSpec, ParseError> {
    if input.contains('{') {
        return Ok(BoundsSpec::Format(input.to_string()));
    }

    let mut items = Vec::new();
    for part in split_bound_parts(input) {
        if part.is_empty() {
            continue;
        }
        items.push(parse_bound_item(&part)?);
    }
    if items.is_empty() {
        return Err(ParseError::Invalid(
            "bounds must contain at least one item".into(),
        ));
    }
    Ok(BoundsSpec::Items(items))
}

fn split_bound_parts(input: &str) -> Vec<String> {
    let mut parts = Vec::new();
    let mut current = String::new();
    for ch in input.chars() {
        if ch == ',' {
            parts.push(current.clone());
            current.clear();
        } else {
            current.push(ch);
        }
    }
    parts.push(current);
    parts
}

fn parse_bound_item(part: &str) -> Result<BoundItem, ParseError> {
    let (spec, fallback) = if let Some((left, right)) = part.split_once('=') {
        (left, Some(right.to_string()))
    } else {
        (part, None)
    };

    if let Some((start, end)) = spec.split_once(':') {
        let start = parse_index(start)?;
        let end = if end.is_empty() {
            i64::MAX
        } else {
            parse_index(end)?
        };
        Ok(BoundItem::Range {
            start,
            end,
            fallback,
        })
    } else {
        Ok(BoundItem::Single {
            index: parse_index(spec)?,
            fallback,
        })
    }
}

fn parse_index(s: &str) -> Result<i64, ParseError> {
    s.parse::<i64>()
        .map_err(|_| ParseError::Invalid(format!("Not a number `{s}`")))
}

pub fn resolve_index(index: i64, count: i64) -> Result<i64, ParseError> {
    let resolved = if index < 0 {
        count + index + 1
    } else {
        index
    };
    if resolved < 1 || resolved > count {
        Err(ParseError::Invalid(format!("Out of bounds: {index}")))
    } else {
        Ok(resolved)
    }
}

pub fn resolve_index_or_fallback(
    index: i64,
    count: i64,
    specific: Option<&str>,
    generic: Option<&str>,
) -> Result<Option<i64>, ParseError> {
    match resolve_index(index, count) {
        Ok(v) => Ok(Some(v)),
        Err(_) => {
            if specific.is_some() || generic.is_some() {
                Ok(None)
            } else {
                Err(ParseError::Invalid(format!("Out of bounds: {index}")))
            }
        }
    }
}

pub fn complement_item(item: &BoundItem, count: i64) -> Result<Vec<BoundItem>, ParseError> {
    if count == 0 {
        return Err(ParseError::Invalid("the complement is empty".into()));
    }

    let (start, end) = match item {
        BoundItem::Single { index, .. } => {
            let idx = resolve_index(*index, count)?;
            (idx, idx)
        }
        BoundItem::Range {
            start,
            end,
            fallback: _,
        } => {
            let s = if *start < 0 {
                resolve_index(*start, count)?
            } else if *start == i64::MAX {
                count
            } else {
                *start
            };
            let e = if *end == i64::MAX {
                count
            } else if *end < 0 {
                resolve_index(*end, count)?
            } else {
                *end
            };
            (s.min(e), s.max(e))
        }
    };

    if start > count || end < 1 {
        return Err(ParseError::Invalid("the complement is empty".into()));
    }

    let mut result = Vec::new();
    let start = start.max(1);
    let end = end.min(count);

    if start > 1 {
        if start - 1 == 1 {
            result.push(BoundItem::Single {
                index: 1,
                fallback: None,
            });
        } else {
            result.push(BoundItem::Range {
                start: 1,
                end: start - 1,
                fallback: None,
            });
        }
    }
    if end < count {
        if end + 1 == count {
            result.push(BoundItem::Single {
                index: count,
                fallback: None,
            });
        } else {
            result.push(BoundItem::Range {
                start: end + 1,
                end: i64::MAX,
                fallback: None,
            });
        }
    }

    if result.is_empty() {
        return Err(ParseError::Invalid("the complement is empty".into()));
    }
    Ok(result)
}

pub fn expand_items(items: &[BoundItem], count: i64) -> Result<Vec<i64>, ParseError> {
    let mut indices = Vec::new();
    for item in items {
        match item {
            BoundItem::Single { index, .. } => {
                indices.push(resolve_index(*index, count)?);
            }
            BoundItem::Range { start, end, .. } => {
                let s = if *start < 0 {
                    resolve_index(*start, count)?
                } else {
                    *start
                };
                let e = if *end == i64::MAX {
                    count
                } else if *end < 0 {
                    resolve_index(*end, count)?
                } else {
                    *end
                };
                let (lo, hi) = (s.min(e), s.max(e));
                for i in lo..=hi {
                    if i >= 1 && i <= count {
                        indices.push(i);
                    }
                }
            }
        }
    }
    Ok(indices)
}

pub fn is_single_range(items: &[BoundItem]) -> bool {
    items.len() == 1 && matches!(items[0], BoundItem::Range { .. })
}
