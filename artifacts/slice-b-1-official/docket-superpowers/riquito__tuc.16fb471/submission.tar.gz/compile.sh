#!/bin/sh
set -eu
cd "$(dirname "$0")"
cargo build --release --quiet
cp target/release/tuc ./candidate
cp -f ./candidate ./executable
