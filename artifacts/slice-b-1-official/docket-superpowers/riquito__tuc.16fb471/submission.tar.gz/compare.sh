#!/bin/bash
set -uo pipefail
cd "$(dirname "$0")"

pass=0
fail=0

run_test() {
    local name="$1"
    local input="$2"
    shift 2
    local exp_out act_out exp_code act_code

    exp_out=$(printf '%b' "$input" | ./executable "$@" 2>/dev/null; true)
    exp_code=$(printf '%b' "$input" | ./executable "$@" >/dev/null 2>&1; echo $?)
    act_out=$(printf '%b' "$input" | ./candidate "$@" 2>/dev/null; true)
    act_code=$(printf '%b' "$input" | ./candidate "$@" >/dev/null 2>&1; echo $?)

    if [[ "$exp_out" == "$act_out" && "$exp_code" -eq "$act_code" ]]; then
        echo "PASS: $name"
        pass=$((pass + 1))
    else
        echo "FAIL: $name"
        echo "  args: $*"
        echo "  expected ($(printf '%q' "$exp_out")) code=$exp_code"
        echo "  actual   ($(printf '%q' "$act_out")) code=$act_code"
        fail=$((fail + 1))
    fi
}

run_test "fields rearrange" 'foo bar baz\n' -d ' ' -f 3,2,1
run_test "fields join" 'foo bar baz\n' -d ' ' -f 3,2,1 -j
run_test "replace delimiter" 'foo bar baz\n' -d ' ' -r ' ➡ '
run_test "range open" 'foo bar    baz\n' -d ' ' -f 2:
run_test "negative fields" 'a b c\n' -d ' ' -f -1,-2,-3
run_test "regex delimiter" 'a,b, c\n' -e '[, ]+' -f 1,3
run_test "json output" 'foo bar baz\n' -d ' ' --json
run_test "multichar delim" 'a<sep>b<sep>c\n' -d '<sep>' -f 1,3
run_test "greedy delim" 'foo    bar\n' -d ' ' -f 1,2 -g
run_test "format output" 'foo bar baz\n' -d ' ' -f '{1}, {2} and lastly {3}'
run_test "compress" 'foo    bar   baz\n' -d ' ' -f 2: -p
run_test "compress replace" 'foo    bar   baz\n' -d ' ' -f 2: -p -r ' -> '
run_test "characters" '😁🤩😝😎\n' -c 4,3,2,1
run_test "bytes range" '😁🤩😝😎\n' -b 5:8
run_test "complement single" 'a b c\n' --complement -d ' ' -f 2
run_test "complement dash" 'a-b-c-d\n' -d '-' -m -f 2
run_test "complement multi" 'x y z\n' -m -d ' ' -f 1,3
run_test "fallback field" 'a-b-c-d\n' -d '-' -f 1,8=fallback
run_test "default tab" 'a\tb\tc\n' -f 1,3
run_test "only delimited" 'yes\tnope\nplain\n' -s -f 1
run_test "join dash" 'a-b-c-d\n' -d '-' -f 1,2 -j
run_test "lines no join" 'a\nb\nc\n' -l 1,2 --no-join
run_test "lines join" 'a\nb\nc\n' -l 1,2
run_test "version" '' -V

echo ""
echo "Results: $pass passed, $fail failed"
[[ $fail -eq 0 ]]
