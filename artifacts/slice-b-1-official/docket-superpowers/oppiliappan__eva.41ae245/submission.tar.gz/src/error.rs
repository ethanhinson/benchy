use std::fmt;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EvaError {
    Domain,
    Math,
    Parser,
    Syntax { func: String },
    UnknownFunction { func: String },
}

impl fmt::Display for EvaError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            EvaError::Domain => write!(f, "Domain Error: Out of bounds!"),
            EvaError::Math => write!(f, "Math Error: Divide by zero error!"),
            EvaError::Parser => write!(f, "Parser Error: Too many operators, too few operands"),
            EvaError::Syntax { func } => {
                write!(f, "Syntax Error: Function '{func}' expected parentheses")
            }
            EvaError::UnknownFunction { func } => {
                write!(f, "Syntax Error: Unknown function '{func}'")
            }
        }
    }
}

pub type EvaResult<T> = Result<T, EvaError>;
