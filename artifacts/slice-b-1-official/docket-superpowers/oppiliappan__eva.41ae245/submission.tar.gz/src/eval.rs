use crate::error::{EvaError, EvaResult};

#[derive(Clone, Copy, Debug)]
pub enum AngleUnit {
    Degree,
    Radian,
    Gradian,
}

impl From<crate::AngleUnit> for AngleUnit {
    fn from(u: crate::AngleUnit) -> Self {
        match u {
            crate::AngleUnit::Degree => AngleUnit::Degree,
            crate::AngleUnit::Radian => AngleUnit::Radian,
            crate::AngleUnit::Gradian => AngleUnit::Gradian,
        }
    }
}

fn to_radians(x: f64, angle: AngleUnit) -> f64 {
    match angle {
        AngleUnit::Radian => x,
        AngleUnit::Degree | AngleUnit::Gradian => x.to_radians(),
    }
}

pub fn eval_function(name: &str, args: &[f64], angle: AngleUnit) -> EvaResult<f64> {
    match name {
        "sin" => Ok(to_radians(args[0], angle).sin()),
        "cos" => Ok(to_radians(args[0], angle).cos()),
        "tan" => {
            let r = to_radians(args[0], angle);
            if r.cos().abs() < f64::EPSILON {
                return Err(EvaError::Math);
            }
            Ok(r.tan())
        }
        "csc" => {
            let s = to_radians(args[0], angle).sin();
            if s.abs() < f64::EPSILON {
                return Err(EvaError::Math);
            }
            Ok(1.0 / s)
        }
        "sec" => {
            let c = to_radians(args[0], angle).cos();
            if c.abs() < f64::EPSILON {
                return Err(EvaError::Math);
            }
            Ok(1.0 / c)
        }
        "cot" => {
            let r = to_radians(args[0], angle);
            if r.sin().abs() < f64::EPSILON {
                return Err(EvaError::Math);
            }
            Ok(r.cos() / r.sin())
        }
        "sinh" => Ok(args[0].sinh()),
        "cosh" => Ok(args[0].cosh()),
        "tanh" => Ok(args[0].tanh()),
        "asin" => {
            if args[0] < -1.0 || args[0] > 1.0 {
                return Err(EvaError::Domain);
            }
            Ok(args[0].asin())
        }
        "acos" => {
            if args[0] < -1.0 || args[0] > 1.0 {
                return Err(EvaError::Domain);
            }
            Ok(args[0].acos())
        }
        "atan" => Ok(args[0].atan()),
        "acsc" => {
            if args[0].abs() < 1.0 {
                return Err(EvaError::Domain);
            }
            Ok((1.0 / args[0]).asin())
        }
        "asec" => {
            if args[0].abs() < 1.0 {
                return Err(EvaError::Domain);
            }
            Ok((1.0 / args[0]).acos())
        }
        "acot" => Ok((1.0 / args[0]).atan()),
        "ln" => {
            if args[0] <= 0.0 {
                return Err(EvaError::Domain);
            }
            Ok(args[0].ln())
        }
        "log2" => {
            if args[0] <= 0.0 {
                return Err(EvaError::Domain);
            }
            Ok(args[0].log2())
        }
        "log10" => {
            if args[0] <= 0.0 {
                return Err(EvaError::Domain);
            }
            Ok(args[0].log10())
        }
        "sqrt" => {
            if args[0] < 0.0 {
                return Err(EvaError::Domain);
            }
            Ok(args[0].sqrt())
        }
        "ceil" => Ok(args[0].ceil()),
        "floor" => Ok(args[0].floor()),
        "abs" => Ok(args[0].abs()),
        "deg" => Ok(args[0].to_degrees()),
        "rad" => Ok(args[0].to_radians()),
        "log" => {
            let value = args[0];
            let base = args[1];
            if value <= 0.0 || base <= 0.0 || base == 1.0 {
                return Err(EvaError::Domain);
            }
            Ok(value.log(base))
        }
        "nroot" => {
            let value = args[0];
            let n = args[1];
            if n == 0.0 {
                return Err(EvaError::Domain);
            }
            if value < 0.0 && n.fract() != 0.0 {
                return Err(EvaError::Domain);
            }
            Ok(value.powf(1.0 / n))
        }
        _ => Err(EvaError::Parser),
    }
}
