mod error;
mod eval;
mod format;
mod lexer;
mod parser;

use clap::{Parser, ValueEnum};
use error::EvaError;
use format::format_value;
use lexer::prepare_input;
use parser::parse_and_eval;

#[derive(Clone, Copy, Debug, ValueEnum, Default)]
enum AngleUnit {
    #[default]
    Degree,
    Radian,
    Gradian,
}

#[derive(Parser, Debug)]
#[command(
    name = "eva",
    version = "0.3.1",
    about = "Calculator REPL similar to bc(1)"
)]
struct Cli {
    #[arg(short = 'f', long = "fix", default_value_t = 10, help = "Number of decimal places in output (1 - 64)")]
    fix: usize,

    #[arg(short = 'b', long = "base", default_value_t = 10, help = "Radix of calculation output (1 - 36)")]
    base: u32,

    #[arg(short = 'a', long = "angle_unit", default_value = "degree", help = "Angle unit")]
    angle_unit: AngleUnit,

    #[arg(help = "Optional expression string to run eva in command mode")]
    input: Option<String>,
}

struct Context {
    fix: usize,
    base: u32,
    angle_unit: AngleUnit,
    prev: f64,
}

fn main() {
    let cli = Cli::parse();

    if cli.fix == 0 || cli.fix > 64 {
        eprintln!("fix must be between 1 and 64");
        std::process::exit(2);
    }
    if cli.base == 0 || cli.base > 36 {
        eprintln!("base must be between 1 and 36");
        std::process::exit(2);
    }

    let mut ctx = Context {
        fix: cli.fix,
        base: cli.base,
        angle_unit: cli.angle_unit,
        prev: 0.0,
    };

    if let Some(expr) = cli.input {
        match eval_line(&mut ctx, &expr) {
            Ok(out) => println!("{out}"),
            Err(err) => println!("{err}"),
        }
        return;
    }

    let stdin = std::io::stdin();
    let mut handle = stdin.lock();
    use std::io::{BufRead, Write};

    loop {
        print!("> ");
        let _ = std::io::stdout().flush();
        let mut line = String::new();
        match handle.read_line(&mut line) {
            Ok(0) => break,
            Ok(_) => match eval_line(&mut ctx, line.trim_end()) {
                Ok(out) => println!("{out}"),
                Err(err) => println!("{err}"),
            },
            Err(_) => break,
        }
    }
}

fn eval_line(ctx: &mut Context, raw: &str) -> Result<String, EvaError> {
    let prepared = prepare_input(raw)?;
    let value = parse_and_eval(&prepared, ctx.prev, ctx.angle_unit.into())?;
    ctx.prev = value;
    Ok(format_value(value, ctx.base, ctx.fix))
}
