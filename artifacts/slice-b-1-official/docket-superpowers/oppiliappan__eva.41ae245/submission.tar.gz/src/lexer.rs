use crate::error::{EvaError, EvaResult};

#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    Number(f64),
    Ident(String),
    Plus,
    Minus,
    Star,
    Slash,
    Caret,
    LParen,
    RParen,
    Comma,
}

const FUNCTIONS: &[&str] = &[
    "sin", "cos", "tan", "csc", "sec", "cot", "sinh", "cosh", "tanh", "asin", "acos", "atan",
    "acsc", "asec", "acot", "ln", "log2", "log10", "sqrt", "ceil", "floor", "abs", "deg", "rad",
    "log", "nroot",
];

pub fn prepare_input(raw: &str) -> EvaResult<Vec<Token>> {
    if raw.is_empty() {
        return Ok(vec![Token::Number(0.0)]);
    }

    let mut s = raw.to_string();
    let open = s.chars().filter(|&c| c == '(').count();
    let close = s.chars().filter(|&c| c == ')').count();
    if open > close {
        s.push_str(&")".repeat(open - close));
    }

    let bytes = s.as_bytes();
    let mut i = 0usize;
    let mut tokens = Vec::new();

    while i < bytes.len() {
        let c = bytes[i] as char;
        if c.is_ascii_whitespace() {
            i += 1;
            continue;
        }

        if c.is_ascii_digit() || (c == '.' && i + 1 < bytes.len() && bytes[i + 1].is_ascii_digit()) {
            let start = i;
            i += 1;
            while i < bytes.len() {
                let ch = bytes[i] as char;
                if ch.is_ascii_digit() || ch == '.' {
                    i += 1;
                } else {
                    break;
                }
            }
            let num_str = &s[start..i];
            let num: f64 = num_str.parse().map_err(|_| EvaError::Parser)?;
            tokens.push(Token::Number(num));
            continue;
        }

        if c.is_ascii_alphabetic() || c == '_' {
            let start = i;
            let name = if s[start..].starts_with("pi")
                && s.as_bytes()
                    .get(start + 2)
                    .map(|b| !b.is_ascii_alphabetic())
                    .unwrap_or(true)
            {
                i = start + 2;
                "pi".to_string()
            } else if s.as_bytes()[start] == b'e'
                && s.as_bytes()
                    .get(start + 1)
                    .map(|b| !b.is_ascii_alphabetic())
                    .unwrap_or(true)
            {
                i = start + 1;
                "e".to_string()
            } else {
                i += 1;
                while i < bytes.len() {
                    let ch = bytes[i] as char;
                    if ch.is_ascii_alphanumeric() || ch == '_' {
                        i += 1;
                    } else {
                        break;
                    }
                }
                s[start..i].to_string()
            };
            if let Some(func) = function_prefix(&name) {
                return Err(EvaError::Syntax { func: func.to_string() });
            }
            if is_function(&name) {
                skip_ws(&s, &mut i);
                if i < bytes.len() && bytes[i] != b'(' {
                    return Err(EvaError::Syntax { func: name });
                }
            } else if i < bytes.len() && bytes[i] == b'(' {
                return Err(EvaError::UnknownFunction { func: name });
            }
            tokens.push(Token::Ident(name));
            continue;
        }

        match c {
            '+' => tokens.push(Token::Plus),
            '-' => tokens.push(Token::Minus),
            '*' => {
                if i + 1 < bytes.len() && bytes[i + 1] == b'*' {
                    i += 1;
                    tokens.push(Token::Caret);
                } else {
                    tokens.push(Token::Star);
                }
            }
            '/' => tokens.push(Token::Slash),
            '^' => tokens.push(Token::Caret),
            '(' => tokens.push(Token::LParen),
            ')' => tokens.push(Token::RParen),
            ',' => tokens.push(Token::Comma),
            _ => return Err(EvaError::Parser),
        }
        i += 1;
    }

    insert_implicit_mul(&mut tokens);
    Ok(tokens)
}

fn is_function(name: &str) -> bool {
    FUNCTIONS.contains(&name)
}

fn function_prefix(name: &str) -> Option<&'static str> {
    if is_function(name) {
        return None;
    }
    let mut funcs: Vec<&str> = FUNCTIONS.to_vec();
    funcs.sort_by_key(|f| std::cmp::Reverse(f.len()));
    for func in funcs {
        if name.len() > func.len() && name.starts_with(func) {
            return Some(func);
        }
    }
    None
}

fn skip_ws(s: &str, i: &mut usize) {
    while *i < s.len() && s.as_bytes()[*i].is_ascii_whitespace() {
        *i += 1;
    }
}

fn insert_implicit_mul(tokens: &mut Vec<Token>) {
    let mut out = Vec::with_capacity(tokens.len() * 2);
    for (idx, tok) in tokens.iter().enumerate() {
        if idx > 0 && needs_implicit_mul(tokens[idx - 1].clone(), tok.clone()) {
            out.push(Token::Star);
        }
        out.push(tok.clone());
    }
    *tokens = out;
}

fn needs_implicit_mul(left: Token, right: Token) -> bool {
    if matches!((&left, &right), (Token::Ident(name), Token::LParen) if is_function(name)) {
        return false;
    }
    let left_end = matches!(left, Token::Number(_) | Token::Ident(_) | Token::RParen);
    let right_start = matches!(right, Token::Number(_) | Token::Ident(_) | Token::LParen);
    left_end && right_start
}
