use crate::error::{EvaError, EvaResult};
use crate::eval::{eval_function, AngleUnit};
use crate::lexer::Token;

pub fn parse_and_eval(tokens: &[Token], prev: f64, angle: AngleUnit) -> EvaResult<f64> {
    let mut pos = 0;
    let value = parse_expr(tokens, &mut pos, prev, angle)?;
    if pos != tokens.len() {
        return Err(EvaError::Parser);
    }
    Ok(value)
}

fn parse_expr(tokens: &[Token], pos: &mut usize, prev: f64, angle: AngleUnit) -> EvaResult<f64> {
    let mut value = parse_term(tokens, pos, prev, angle)?;
    loop {
        match peek(tokens, *pos) {
            Some(Token::Plus) => {
                *pos += 1;
                value += parse_term(tokens, pos, prev, angle)?;
            }
            Some(Token::Minus) => {
                *pos += 1;
                value -= parse_term(tokens, pos, prev, angle)?;
            }
            _ => break,
        }
    }
    Ok(value)
}

fn parse_term(tokens: &[Token], pos: &mut usize, prev: f64, angle: AngleUnit) -> EvaResult<f64> {
    let mut value = parse_power(tokens, pos, prev, angle)?;
    loop {
        match peek(tokens, *pos) {
            Some(Token::Star) => {
                *pos += 1;
                value *= parse_power(tokens, pos, prev, angle)?;
            }
            Some(Token::Slash) => {
                *pos += 1;
                let rhs = parse_power(tokens, pos, prev, angle)?;
                if rhs == 0.0 {
                    return Err(EvaError::Math);
                }
                value /= rhs;
            }
            _ => break,
        }
    }
    Ok(value)
}

fn parse_power(tokens: &[Token], pos: &mut usize, prev: f64, angle: AngleUnit) -> EvaResult<f64> {
    let mut value = parse_unary(tokens, pos, prev, angle)?;
    if matches!(peek(tokens, *pos), Some(Token::Caret)) {
        *pos += 1;
        let rhs = parse_power(tokens, pos, prev, angle)?;
        value = value.powf(rhs);
    }
    Ok(value)
}

fn parse_unary(tokens: &[Token], pos: &mut usize, prev: f64, angle: AngleUnit) -> EvaResult<f64> {
    match peek(tokens, *pos) {
        Some(Token::Plus) => {
            *pos += 1;
            parse_unary(tokens, pos, prev, angle)
        }
        Some(Token::Minus) => {
            *pos += 1;
            Ok(-parse_unary(tokens, pos, prev, angle)?)
        }
        _ => parse_primary(tokens, pos, prev, angle),
    }
}

fn parse_primary(tokens: &[Token], pos: &mut usize, prev: f64, angle: AngleUnit) -> EvaResult<f64> {
    match bump(tokens, pos) {
        Some(Token::Number(n)) => Ok(n),
        Some(Token::Ident(name)) => {
            if is_function(&name) {
                if matches!(peek(tokens, *pos), Some(Token::LParen)) {
                    parse_call(tokens, pos, &name, prev, angle)
                } else {
                    Err(EvaError::Parser)
                }
            } else {
                Ok(resolve_const(&name, prev)?)
            }
        }
        Some(Token::LParen) => {
            let val = parse_expr(tokens, pos, prev, angle)?;
            if !matches!(bump(tokens, pos), Some(Token::RParen)) {
                return Err(EvaError::Parser);
            }
            Ok(val)
        }
        _ => Err(EvaError::Parser),
    }
}

fn parse_call(
    tokens: &[Token],
    pos: &mut usize,
    name: &str,
    prev: f64,
    angle: AngleUnit,
) -> EvaResult<f64> {
    if !matches!(bump(tokens, pos), Some(Token::LParen)) {
        return Err(EvaError::Parser);
    }

    let arity = if name == "log" || name == "nroot" { 2 } else { 1 };
    let mut args = Vec::new();

    if matches!(peek(tokens, *pos), Some(Token::RParen)) {
        return Err(EvaError::Parser);
    }

    args.push(parse_expr(tokens, pos, prev, angle)?);

    if arity == 2 {
        if !matches!(bump(tokens, pos), Some(Token::Comma)) {
            return Err(EvaError::Parser);
        }
        if matches!(peek(tokens, *pos), Some(Token::RParen)) {
            return Err(EvaError::Parser);
        }
        args.push(parse_expr(tokens, pos, prev, angle)?);
    }

    if !matches!(bump(tokens, pos), Some(Token::RParen)) {
        return Err(EvaError::Parser);
    }

    eval_function(name, &args, angle)
}

fn resolve_const(name: &str, prev: f64) -> EvaResult<f64> {
    match name {
        "pi" => Ok(std::f64::consts::PI),
        "e" => Ok(std::f64::consts::E),
        "_" => Ok(prev),
        _ => Err(EvaError::Parser),
    }
}

fn is_function(name: &str) -> bool {
    matches!(
        name,
        "sin" | "cos"
            | "tan"
            | "csc"
            | "sec"
            | "cot"
            | "sinh"
            | "cosh"
            | "tanh"
            | "asin"
            | "acos"
            | "atan"
            | "acsc"
            | "asec"
            | "acot"
            | "ln"
            | "log2"
            | "log10"
            | "sqrt"
            | "ceil"
            | "floor"
            | "abs"
            | "deg"
            | "rad"
            | "log"
            | "nroot"
    )
}

fn peek(tokens: &[Token], pos: usize) -> Option<&Token> {
    tokens.get(pos)
}

fn bump(tokens: &[Token], pos: &mut usize) -> Option<Token> {
    if *pos < tokens.len() {
        let t = tokens[*pos].clone();
        *pos += 1;
        Some(t)
    } else {
        None
    }
}
