const DIGITS: &[u8; 36] = b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

pub fn format_value(value: f64, base: u32, fix: usize) -> String {
    if base == 10 {
        format_decimal(value, fix)
    } else {
        format_radix(value, base, fix)
    }
}

fn format_decimal(value: f64, fix: usize) -> String {
    let sign = if value.is_sign_negative() { "-" } else { "" };
    let abs = value.abs();

    let factor = 10_f64.powi(fix as i32);
    let rounded = (abs * factor).round() / factor;

    let int_part = rounded.trunc() as u128;
    let frac = rounded.fract();
    let frac_int = (frac * factor).round() as u128;

    let int_str = add_commas(&int_part.to_string());
    let frac_str = format!("{:0width$}", frac_int, width = fix);
    format!("{sign}{int_str}.{frac_str}")
}

fn add_commas(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = String::new();
    for (i, ch) in bytes.iter().enumerate() {
        if i > 0 && (bytes.len() - i) % 3 == 0 {
            out.push(',');
        }
        out.push(*ch as char);
    }
    out
}

fn format_radix(value: f64, base: u32, fix: usize) -> String {
    let sign = if value.is_sign_negative() { "-" } else { "" };
    let factor = 10_f64.powi(fix as i32);
    let abs = (value.abs() * factor).round() / factor;

    let int_part = abs.trunc() as u128;
    let frac_val = abs.fract();

    let int_str = to_base(int_part, base);
    let mut chunks = split_groups(&int_str, 3);

    while chunks.len() < 4 {
        chunks.insert(0, String::new());
    }
    if chunks.len() > 4 {
        let excess = chunks.len() - 4;
        let merged = chunks[..excess].concat();
        chunks = {
            let mut rest = chunks[excess..].to_vec();
            rest.insert(0, merged);
            while rest.len() > 4 {
                let first = rest.remove(0);
                rest[0] = format!("{first}{}", rest[0]);
            }
            rest
        };
    }

    let mut frac_str = frac_to_base(frac_val, base, fix);
    if frac_str.chars().all(|c| c == '0') {
        frac_str = "0".to_string();
    } else {
        while frac_str.ends_with('0') {
            frac_str.pop();
        }
    }

    let mut parts = Vec::new();
    for (i, chunk) in chunks.iter().enumerate() {
        if i == chunks.len() - 1 {
            let body = if chunk.is_empty() {
                format!("  0.{frac_str}")
            } else {
                format!("{chunk:>3}.{frac_str}")
            };
            parts.push(body);
        } else if chunk.is_empty() {
            if i == 0 {
                parts.push(" ".to_string());
            } else {
                parts.push("   ".to_string());
            }
        } else {
            parts.push(format!("{chunk:>3}"));
        }
    }

    format!("{sign}{}", parts.join(","))
}

fn to_base(mut n: u128, base: u32) -> String {
    if n == 0 {
        return "0".to_string();
    }
    let mut out = Vec::new();
    let b = base as u128;
    while n > 0 {
        let d = (n % b) as usize;
        out.push(DIGITS[d] as char);
        n /= b;
    }
    out.into_iter().rev().collect()
}

fn split_groups(s: &str, size: usize) -> Vec<String> {
    if s.is_empty() {
        return vec!["0".to_string()];
    }
    let mut groups = Vec::new();
    let chars: Vec<char> = s.chars().collect();
    let mut i = chars.len();
    while i > 0 {
        let start = i.saturating_sub(size);
        groups.insert(0, chars[start..i].iter().collect());
        i = start;
    }
    groups
}

fn frac_to_base(mut frac: f64, base: u32, digits: usize) -> String {
    let mut out = String::new();
    let b = base as f64;
    for _ in 0..digits {
        frac *= b;
        let digit = frac.trunc() as u32;
        frac -= digit as f64;
        out.push(DIGITS[digit as usize] as char);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn decimal_commas() {
        assert_eq!(format_decimal(1_000_000.0, 10), "1,000,000.0000000000");
    }
}
