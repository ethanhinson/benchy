#!/bin/sh
set -eu

cd "$(dirname "$0")"
cargo build --release --quiet
cp -f target/release/eva ./candidate
chmod +x ./candidate
cp -f ./candidate ./executable
