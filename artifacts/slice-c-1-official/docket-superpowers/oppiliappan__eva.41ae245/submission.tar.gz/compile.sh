#!/bin/sh
set -eu

cd "$(dirname "$0")"
cargo build --release --offline
cp -f target/release/eva ./executable
chmod +x ./executable
