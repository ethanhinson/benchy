#!/bin/sh
set -eu

cd "$(dirname "$0")"

cargo build --release --offline
cp -f target/release/executable ./executable
chmod +x ./executable

echo "Built ./executable"
