#!/bin/sh
set -eu

cd "$(dirname "$0")"

cargo build --release --offline --quiet
cp -f target/release/hexyl ./executable
